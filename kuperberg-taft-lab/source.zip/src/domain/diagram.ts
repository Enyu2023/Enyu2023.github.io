/**
 * Finite, prepared input for the Chang--Cui special-diagram evaluator.
 *
 * The four-g coordinates describe a combing relative to a fixed reference
 * turn table.  B and A are the precomputed signed-intersection vectors from
 * that same reference.  Consequently the actual labels are
 *
 *   R(c) = R0(c) - 2 B(c).n,   N(p) = N0(p) - 2 A(p).n.
 *
 * This is deliberately a JSON-friendly format: no vector-field drawing is
 * needed once the reference data have been prepared.
 */

export interface DiagramPoint {
  x: number;
  y: number;
}

export interface CircleDrawing {
  /** Points in normalized canvas coordinates (normally 0--100). */
  points: DiagramPoint[];
  color?: string;
  dashed?: boolean;
}

export type CircleKind = "lower" | "upper";

export interface PreparedCircle {
  id: string;
  kind: CircleKind;
  /** Odd reference total-rotation label, equal to 2 theta_0(c). */
  R0: number;
  /** Signed intersections with the 4g reference phase fronts. */
  B: number[];
  /** Crossing ids, read just after the base point in positive orientation. */
  order: string[];
  /** False until a newly inserted row's R0/B data have been reviewed. */
  labelsPrepared?: boolean;
  drawing?: CircleDrawing;
}

export interface CrossingEndpoints {
  /** Id of the incident lower (alpha/eta) circle. */
  lower: string;
  /** Id of the incident upper (beta/mu) circle. */
  upper: string;
}

export interface PreparedCrossing {
  id: string;
  /** Reference antipode power. */
  N0: number;
  /** Difference of the two partial-path phase-front counters. */
  A: number[];
  endpoints: CrossingEndpoints;
  /**
   * False when a row came from the visual intersection suggester (or was
   * newly inserted) and its N0/A preparation has not yet been certified.
   * Omission means true so existing schema-v1 prepared diagrams remain valid.
   */
  labelsPrepared?: boolean;
  /** Optional normalized drawing position; algebra never depends on it. */
  point?: DiagramPoint;
}

export interface CombingCoordinates {
  /** Human-readable names for the chosen relative H_1 basis. */
  labels: string[];
  /** The freely chosen n_1,...,n_4g combing integers. */
  combing: number[];
}

export interface PreparedDiagram {
  schemaVersion: 1;
  name: string;
  genus: number;
  basis: CombingCoordinates;
  circles: PreparedCircle[];
  crossings: PreparedCrossing[];
  description?: string;
  source?: {
    label: string;
    url?: string;
    note?: string;
  };
}

export interface DerivedCircleLabel {
  id: string;
  kind: CircleKind;
  R: number;
  thetaNumerator: number;
  thetaDenominator: 2;
}

export interface DerivedCrossingLabel {
  id: string;
  N: number;
  lower: string;
  upper: string;
}

export interface DerivedDiagram {
  circles: DerivedCircleLabel[];
  crossings: DerivedCrossingLabel[];
}

export interface Diagnostic {
  severity: "error" | "warning";
  code: string;
  path: string;
  message: string;
}

export interface ValidationResult {
  valid: boolean;
  diagnostics: Diagnostic[];
}

export const PREPARED_DIAGRAM_SCHEMA_VERSION = 1 as const;

export function clonePreparedDiagram(diagram: PreparedDiagram): PreparedDiagram {
  return structuredClone(diagram);
}
