import type {
  DerivedDiagram,
  Diagnostic,
  PreparedCircle,
  PreparedCrossing,
  PreparedDiagram,
  ValidationResult,
} from "./diagram";

const integer = (value: unknown): value is number => Number.isSafeInteger(value);

/** Defensive limits for untrusted JSON. The evaluator's supported diagrams are
 * much smaller; these bounds mainly keep validation linear and responsive. */
export const PREPARED_DIAGRAM_LIMITS = {
  genus: 12,
  basisEntries: 48,
  circles: 24,
  crossings: 512,
  orderEntriesPerCircle: 512,
  drawingPointsPerCircle: 512,
} as const;

const record = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

function diagnostic(
  diagnostics: Diagnostic[],
  code: string,
  path: string,
  message: string,
): void {
  diagnostics.push({ severity: "error", code, path, message });
}

function validateIntegerVector(
  value: unknown,
  expectedLength: number,
  path: string,
  diagnostics: Diagnostic[],
): value is number[] {
  if (!Array.isArray(value)) {
    diagnostic(diagnostics, "VECTOR_REQUIRED", path, "Expected an integer vector.");
    return false;
  }
  if (value.length !== expectedLength) {
    diagnostic(
      diagnostics,
      "VECTOR_LENGTH",
      path,
      `Expected ${expectedLength} entries (4g), received ${value.length}.`,
    );
  }
  if (value.length > PREPARED_DIAGRAM_LIMITS.basisEntries) {
    diagnostic(
      diagnostics,
      "DATA_LIMIT",
      path,
      `Vectors are limited to ${PREPARED_DIAGRAM_LIMITS.basisEntries} entries (genus at most ${PREPARED_DIAGRAM_LIMITS.genus}).`,
    );
  }
  value.slice(0, PREPARED_DIAGRAM_LIMITS.basisEntries).forEach((entry, index) => {
    if (!integer(entry)) {
      diagnostic(
        diagnostics,
        "INTEGER_REQUIRED",
        `${path}[${index}]`,
        "Coordinates must be safe integers.",
      );
    }
  });
  return value.length === expectedLength && value.length <= PREPARED_DIAGRAM_LIMITS.basisEntries && value.every(integer);
}

function dotBigInt(left: number[], right: number[]): bigint {
  let total = 0n;
  for (let index = 0; index < left.length; index += 1) {
    total += BigInt(left[index]!) * BigInt(right[index]!);
  }
  return total;
}

function derivedInteger(reference: number, vector: number[], combing: number[]): number {
  const exact = BigInt(reference) - 2n * dotBigInt(vector, combing);
  const result = Number(exact);
  if (!Number.isSafeInteger(result)) {
    throw new RangeError(`Derived label ${exact.toString()} is outside the safe-integer range.`);
  }
  return result;
}

export function validatePreparedDiagram(input: unknown): ValidationResult {
  const diagnostics: Diagnostic[] = [];
  if (typeof input !== "object" || input === null || Array.isArray(input)) {
    return {
      valid: false,
      diagnostics: [
        {
          severity: "error",
          code: "DIAGRAM_REQUIRED",
          path: "$",
          message: "Expected a prepared-diagram object.",
        },
      ],
    };
  }

  const diagram = input as Partial<PreparedDiagram>;
  if (diagram.schemaVersion !== 1) {
    diagnostic(
      diagnostics,
      "SCHEMA_VERSION",
      "schemaVersion",
      "Only prepared-diagram schemaVersion 1 is supported.",
    );
  }
  if (typeof diagram.name !== "string" || diagram.name.trim().length === 0) {
    diagnostic(diagnostics, "NAME_REQUIRED", "name", "Give the diagram a non-empty name.");
  }
  if (!integer(diagram.genus) || (diagram.genus ?? 0) < 1) {
    diagnostic(diagnostics, "GENUS", "genus", "Genus must be a positive safe integer.");
  } else if (diagram.genus > PREPARED_DIAGRAM_LIMITS.genus) {
    diagnostic(
      diagnostics,
      "DATA_LIMIT",
      "genus",
      `Genus is limited to ${PREPARED_DIAGRAM_LIMITS.genus} in this browser implementation.`,
    );
  }

  const genus = integer(diagram.genus) && diagram.genus > 0 ? diagram.genus : 0;
  const coordinateCount = 4 * genus;
  const basis = diagram.basis;
  let combingValid = false;
  if (typeof basis !== "object" || basis === null) {
    diagnostic(diagnostics, "BASIS_REQUIRED", "basis", "The 4g basis and combing data are required.");
  } else {
    if (!Array.isArray(basis.labels)) {
      diagnostic(diagnostics, "LABELS_REQUIRED", "basis.labels", "Expected 4g basis labels.");
    } else {
      if (basis.labels.length !== coordinateCount) {
        diagnostic(
          diagnostics,
          "LABEL_COUNT",
          "basis.labels",
          `Expected ${coordinateCount} labels (4g), received ${basis.labels.length}.`,
        );
      }
      if (basis.labels.length > PREPARED_DIAGRAM_LIMITS.basisEntries) {
        diagnostic(
          diagnostics,
          "DATA_LIMIT",
          "basis.labels",
          `Basis data are limited to ${PREPARED_DIAGRAM_LIMITS.basisEntries} entries.`,
        );
      }
      const seen = new Set<string>();
      basis.labels.slice(0, PREPARED_DIAGRAM_LIMITS.basisEntries).forEach((label, index) => {
        if (typeof label !== "string" || label.trim().length === 0) {
          diagnostic(
            diagnostics,
            "BASIS_LABEL",
            `basis.labels[${index}]`,
            "Basis labels must be non-empty strings.",
          );
        } else if (seen.has(label)) {
          diagnostic(
            diagnostics,
            "DUPLICATE_BASIS_LABEL",
            `basis.labels[${index}]`,
            `Basis label “${label}” is repeated.`,
          );
        } else {
          seen.add(label);
        }
      });
    }
    combingValid = validateIntegerVector(
      basis.combing,
      coordinateCount,
      "basis.combing",
      diagnostics,
    );
  }

  if (!Array.isArray(diagram.circles)) {
    diagnostic(diagnostics, "CIRCLES_REQUIRED", "circles", "Expected an array of Heegaard circles.");
  }
  if (!Array.isArray(diagram.crossings)) {
    diagnostic(diagnostics, "CROSSINGS_REQUIRED", "crossings", "Expected an array of crossings.");
  }

  if (Array.isArray(diagram.circles) && diagram.circles.length > PREPARED_DIAGRAM_LIMITS.circles) {
    diagnostic(
      diagnostics,
      "DATA_LIMIT",
      "circles",
      `At most ${PREPARED_DIAGRAM_LIMITS.circles} circles can be validated at once.`,
    );
  }
  if (Array.isArray(diagram.crossings) && diagram.crossings.length > PREPARED_DIAGRAM_LIMITS.crossings) {
    diagnostic(
      diagnostics,
      "DATA_LIMIT",
      "crossings",
      `At most ${PREPARED_DIAGRAM_LIMITS.crossings} crossings can be validated at once.`,
    );
  }

  const circles = Array.isArray(diagram.circles)
    ? diagram.circles.slice(0, PREPARED_DIAGRAM_LIMITS.circles)
    : [];
  const crossings = Array.isArray(diagram.crossings)
    ? diagram.crossings.slice(0, PREPARED_DIAGRAM_LIMITS.crossings)
    : [];
  const circleById = new Map<string, PreparedCircle>();
  const crossingById = new Map<string, PreparedCrossing>();

  circles.forEach((candidate, index) => {
    const path = `circles[${index}]`;
    if (!record(candidate)) {
      diagnostic(diagnostics, "CIRCLE_OBJECT", path, "Expected a circle object.");
      return;
    }
    const circle = candidate as unknown as PreparedCircle;
    if (typeof circle.id !== "string" || circle.id.trim().length === 0) {
      diagnostic(diagnostics, "CIRCLE_ID", `${path}.id`, "Circle id must be a non-empty string.");
    } else if (circleById.has(circle.id)) {
      diagnostic(
        diagnostics,
        "DUPLICATE_CIRCLE",
        `${path}.id`,
        `Circle id “${circle.id}” is repeated.`,
      );
    } else {
      circleById.set(circle.id, circle);
    }
    if (circle.kind !== "lower" && circle.kind !== "upper") {
      diagnostic(diagnostics, "CIRCLE_KIND", `${path}.kind`, "Circle kind must be lower or upper.");
    }
    if (!integer(circle.R0) || circle.R0 % 2 === 0) {
      diagnostic(
        diagnostics,
        "ODD_ROTATION",
        `${path}.R0`,
        "R0 = 2 theta_0 must be an odd safe integer.",
      );
    }
    validateIntegerVector(circle.B, coordinateCount, `${path}.B`, diagnostics);
    if (circle.labelsPrepared !== undefined && typeof circle.labelsPrepared !== "boolean") {
      diagnostic(
        diagnostics,
        "BOOLEAN_REQUIRED",
        `${path}.labelsPrepared`,
        "labelsPrepared must be true or false when supplied.",
      );
    } else if (circle.labelsPrepared === false) {
      diagnostic(
        diagnostics,
        "UNPREPARED_CIRCLE_LABELS",
        `${path}.labelsPrepared`,
        "Review this circle's R0 and B data, then mark its numeric labels ready.",
      );
    }
    if (!Array.isArray(circle.order)) {
      diagnostic(diagnostics, "CIRCLE_ORDER", `${path}.order`, "Expected an ordered list of crossing ids.");
    } else {
      if (circle.order.length > PREPARED_DIAGRAM_LIMITS.orderEntriesPerCircle) {
        diagnostic(
          diagnostics,
          "DATA_LIMIT",
          `${path}.order`,
          `A circle order is limited to ${PREPARED_DIAGRAM_LIMITS.orderEntriesPerCircle} crossing references.`,
        );
      }
      const local = new Set<string>();
      circle.order.slice(0, PREPARED_DIAGRAM_LIMITS.orderEntriesPerCircle).forEach((id, orderIndex) => {
        if (typeof id !== "string" || id.trim().length === 0) {
          diagnostic(
            diagnostics,
            "CROSSING_REFERENCE",
            `${path}.order[${orderIndex}]`,
            "Crossing references must be non-empty strings.",
          );
        } else if (local.has(id)) {
          diagnostic(
            diagnostics,
            "DUPLICATE_IN_ORDER",
            `${path}.order[${orderIndex}]`,
            `Crossing “${id}” occurs twice on this circle.`,
          );
        } else {
          local.add(id);
        }
      });
    }
    if (circle.drawing !== undefined) {
      if (!record(circle.drawing)) {
        diagnostic(
          diagnostics,
          "DRAWING_OBJECT",
          `${path}.drawing`,
          "Drawing data must be an object when supplied.",
        );
      } else if (!Array.isArray(circle.drawing.points) || circle.drawing.points.length < 2) {
        diagnostic(
          diagnostics,
          "DRAWING_POINTS",
          `${path}.drawing.points`,
          "A drawn circle needs at least two finite points.",
        );
      } else {
        if (circle.drawing.points.length > PREPARED_DIAGRAM_LIMITS.drawingPointsPerCircle) {
          diagnostic(
            diagnostics,
            "DATA_LIMIT",
            `${path}.drawing.points`,
            `A circle drawing is limited to ${PREPARED_DIAGRAM_LIMITS.drawingPointsPerCircle} points.`,
          );
        }
        circle.drawing.points
          .slice(0, PREPARED_DIAGRAM_LIMITS.drawingPointsPerCircle)
          .forEach((point, pointIndex) => {
          if (!Number.isFinite(point?.x) || !Number.isFinite(point?.y)) {
            diagnostic(
              diagnostics,
              "DRAWING_POINT",
              `${path}.drawing.points[${pointIndex}]`,
              "Drawing coordinates must be finite numbers.",
            );
          }
          });
      }
    }
  });

  const lowerCount = circles.filter((circle) => circle?.kind === "lower").length;
  const upperCount = circles.filter((circle) => circle?.kind === "upper").length;
  if (lowerCount !== genus) {
    diagnostic(
      diagnostics,
      "LOWER_CIRCLE_COUNT",
      "circles",
      `A genus-${genus} diagram needs ${genus} lower circles; found ${lowerCount}.`,
    );
  }
  if (upperCount !== genus) {
    diagnostic(
      diagnostics,
      "UPPER_CIRCLE_COUNT",
      "circles",
      `A genus-${genus} diagram needs ${genus} upper circles; found ${upperCount}.`,
    );
  }

  crossings.forEach((candidate, index) => {
    const path = `crossings[${index}]`;
    if (!record(candidate)) {
      diagnostic(diagnostics, "CROSSING_OBJECT", path, "Expected a crossing object.");
      return;
    }
    const crossing = candidate as unknown as PreparedCrossing;
    if (typeof crossing.id !== "string" || crossing.id.trim().length === 0) {
      diagnostic(diagnostics, "CROSSING_ID", `${path}.id`, "Crossing id must be a non-empty string.");
    } else if (crossingById.has(crossing.id)) {
      diagnostic(
        diagnostics,
        "DUPLICATE_CROSSING",
        `${path}.id`,
        `Crossing id “${crossing.id}” is repeated.`,
      );
    } else {
      crossingById.set(crossing.id, crossing);
    }
    if (!integer(crossing.N0)) {
      diagnostic(diagnostics, "CROSSING_POWER", `${path}.N0`, "N0 must be a safe integer.");
    }
    validateIntegerVector(crossing.A, coordinateCount, `${path}.A`, diagnostics);
    if (crossing.labelsPrepared !== undefined && typeof crossing.labelsPrepared !== "boolean") {
      diagnostic(
        diagnostics,
        "BOOLEAN_REQUIRED",
        `${path}.labelsPrepared`,
        "labelsPrepared must be true or false when supplied.",
      );
    } else if (crossing.labelsPrepared === false) {
      diagnostic(
        diagnostics,
        "UNPREPARED_CROSSING_LABELS",
        `${path}.labelsPrepared`,
        "Review this crossing's N0 and A data, then mark its numeric labels ready.",
      );
    }
    if (!record(crossing.endpoints)) {
      diagnostic(
        diagnostics,
        "ENDPOINTS_REQUIRED",
        `${path}.endpoints`,
        "Every crossing needs lower and upper circle endpoints.",
      );
    } else {
      const lower = circleById.get(crossing.endpoints.lower);
      const upper = circleById.get(crossing.endpoints.upper);
      if (!lower || lower.kind !== "lower") {
        diagnostic(
          diagnostics,
          "LOWER_ENDPOINT",
          `${path}.endpoints.lower`,
          `“${String(crossing.endpoints.lower)}” is not a lower circle.`,
        );
      }
      if (!upper || upper.kind !== "upper") {
        diagnostic(
          diagnostics,
          "UPPER_ENDPOINT",
          `${path}.endpoints.upper`,
          `“${String(crossing.endpoints.upper)}” is not an upper circle.`,
        );
      }
    }
    if (crossing.point !== undefined) {
      if (!record(crossing.point)) {
        diagnostic(
          diagnostics,
          "CROSSING_POINT",
          `${path}.point`,
          "A crossing point must be an object with finite x and y coordinates.",
        );
      } else if (!Number.isFinite(crossing.point.x) || !Number.isFinite(crossing.point.y)) {
        diagnostic(
          diagnostics,
          "CROSSING_POINT",
          `${path}.point`,
          "Drawing coordinates must be finite numbers.",
        );
      }
    }
  });

  circles.forEach((circle, circleIndex) => {
    if (!Array.isArray(circle?.order)) return;
    circle.order
      .slice(0, PREPARED_DIAGRAM_LIMITS.orderEntriesPerCircle)
      .forEach((crossingId, orderIndex) => {
      const crossing = crossingById.get(crossingId);
      if (!crossing) {
        diagnostic(
          diagnostics,
          "UNKNOWN_CROSSING",
          `circles[${circleIndex}].order[${orderIndex}]`,
          `Crossing “${crossingId}” is not defined.`,
        );
      } else {
        const expected = circle.kind === "lower" ? crossing.endpoints?.lower : crossing.endpoints?.upper;
        if (expected !== circle.id) {
          diagnostic(
            diagnostics,
            "INCIDENCE_MISMATCH",
            `circles[${circleIndex}].order[${orderIndex}]`,
            `Crossing “${crossingId}” is not incident to circle “${circle.id}”.`,
          );
        }
      }
      });
  });

  crossings.forEach((crossing, crossingIndex) => {
    if (!record(crossing) || !record(crossing.endpoints)) return;
    for (const kind of ["lower", "upper"] as const) {
      const circleId = crossing.endpoints[kind];
      const circle = circleById.get(circleId);
      const occurrences = Array.isArray(circle?.order)
        ? circle.order
            .slice(0, PREPARED_DIAGRAM_LIMITS.orderEntriesPerCircle)
            .filter((id) => id === crossing.id).length
        : 0;
      if (occurrences !== 1) {
        diagnostic(
          diagnostics,
          "MISSING_FROM_ORDER",
          `crossings[${crossingIndex}].endpoints.${kind}`,
          `Crossing “${crossing.id}” must occur exactly once in circle “${circleId}”'s order.`,
        );
      }
    }
  });

  if (combingValid) {
    for (let index = 0; index < circles.length; index += 1) {
      const circle = circles[index]!;
      if (!record(circle)) continue;
      if (!integer(circle.R0) || !Array.isArray(circle.B) || circle.B.length !== coordinateCount) continue;
      try {
        derivedInteger(circle.R0, circle.B, basis!.combing);
      } catch (error) {
        diagnostic(
          diagnostics,
          "DERIVED_LABEL_OVERFLOW",
          `circles[${index}]`,
          error instanceof Error ? error.message : "Derived R label is too large.",
        );
      }
    }
    for (let index = 0; index < crossings.length; index += 1) {
      const crossing = crossings[index]!;
      if (!record(crossing)) continue;
      if (!integer(crossing.N0) || !Array.isArray(crossing.A) || crossing.A.length !== coordinateCount) continue;
      try {
        derivedInteger(crossing.N0, crossing.A, basis!.combing);
      } catch (error) {
        diagnostic(
          diagnostics,
          "DERIVED_LABEL_OVERFLOW",
          `crossings[${index}]`,
          error instanceof Error ? error.message : "Derived N label is too large.",
        );
      }
    }
  }

  return { valid: !diagnostics.some((entry) => entry.severity === "error"), diagnostics };
}

export function deriveLabels(diagram: PreparedDiagram): DerivedDiagram {
  const combing = diagram.basis.combing;
  return {
    circles: diagram.circles.map((circle) => {
      const R = derivedInteger(circle.R0, circle.B, combing);
      return {
        id: circle.id,
        kind: circle.kind,
        R,
        thetaNumerator: R,
        thetaDenominator: 2 as const,
      };
    }),
    crossings: diagram.crossings.map((crossing) => ({
      id: crossing.id,
      N: derivedInteger(crossing.N0, crossing.A, combing),
      lower: crossing.endpoints.lower,
      upper: crossing.endpoints.upper,
    })),
  };
}

export function changCuiSupportDiagnostics(derived: DerivedDiagram): Diagnostic[] {
  return derived.circles
    .filter((circle) => !Number.isSafeInteger(circle.R) || circle.R % 2 === 0)
    .map((circle) => ({
      severity: "error" as const,
      code: "UNSUPPORTED_ROTATION_TOTAL",
      path: `circles.${circle.id}.R`,
      message:
        `Derived R(${circle.id}) = ${circle.R}; total-rotation labels must be odd integers.`,
    }));
}
