/** Exact arithmetic in Z[zeta_l] = Z[t]/(Phi_l(t)). */

export interface CyclotomicJSON {
  level: number;
  /** Ascending coefficients in the canonical power basis, encoded as decimal bigints. */
  coefficients: string[];
}

export interface ComplexApproximation {
  re: number;
  im: number;
}

const phiCache = new Map<number, readonly bigint[]>([[1, [-1n, 1n]]]);

function trim(polynomial: bigint[]): bigint[] {
  while (polynomial.length > 0 && polynomial.at(-1) === 0n) polynomial.pop();
  return polynomial;
}

function positiveDivisors(value: number): number[] {
  const small: number[] = [];
  const large: number[] = [];
  for (let divisor = 1; divisor * divisor <= value; divisor += 1) {
    if (value % divisor !== 0) continue;
    small.push(divisor);
    if (divisor * divisor !== value) large.push(value / divisor);
  }
  return [...small, ...large.reverse()];
}

function divideMonicExact(dividend: readonly bigint[], divisor: readonly bigint[]): bigint[] {
  const remainder = trim([...dividend]);
  const divisorDegree = divisor.length - 1;
  if (divisorDegree < 0 || divisor.at(-1) !== 1n) {
    throw new Error("Internal cyclotomic division requires a nonzero monic divisor.");
  }
  const quotient = Array<bigint>(Math.max(0, remainder.length - divisorDegree)).fill(0n);
  while (remainder.length - 1 >= divisorDegree) {
    const shift = remainder.length - 1 - divisorDegree;
    const factor = remainder.at(-1)!;
    quotient[shift] += factor;
    for (let index = 0; index <= divisorDegree; index += 1) {
      remainder[index + shift] -= factor * divisor[index]!;
    }
    trim(remainder);
  }
  if (remainder.some((coefficient) => coefficient !== 0n)) {
    throw new Error("Internal cyclotomic polynomial division was not exact.");
  }
  return trim(quotient);
}

export function cyclotomicPolynomial(level: number): readonly bigint[] {
  if (!Number.isSafeInteger(level) || level < 1) {
    throw new RangeError("Cyclotomic level must be a positive safe integer.");
  }
  const cached = phiCache.get(level);
  if (cached) return cached;

  const xToNMinusOne = Array<bigint>(level + 1).fill(0n);
  xToNMinusOne[0] = -1n;
  xToNMinusOne[level] = 1n;
  let result = xToNMinusOne;
  for (const divisor of positiveDivisors(level)) {
    if (divisor === level) break;
    result = divideMonicExact(result, cyclotomicPolynomial(divisor));
  }
  const frozen = Object.freeze(trim(result));
  phiCache.set(level, frozen);
  return frozen;
}

function reduce(level: number, source: readonly bigint[]): bigint[] {
  const modulus = cyclotomicPolynomial(level);
  const degree = modulus.length - 1;
  const result = trim([...source]);
  while (result.length - 1 >= degree) {
    const shift = result.length - 1 - degree;
    const factor = result.at(-1)!;
    for (let index = 0; index <= degree; index += 1) {
      result[index + shift] -= factor * modulus[index]!;
    }
    trim(result);
  }
  return result;
}

function assertSameLevel(left: Cyclotomic, right: Cyclotomic): void {
  if (left.level !== right.level) {
    throw new Error(`Cannot mix zeta_${left.level} and zeta_${right.level}.`);
  }
}

export class Cyclotomic {
  readonly level: number;
  readonly coefficients: readonly bigint[];

  constructor(level: number, coefficients: readonly bigint[] = []) {
    if (!Number.isSafeInteger(level) || level < 2) {
      throw new RangeError("Cyclotomic level must be an integer at least 2.");
    }
    this.level = level;
    this.coefficients = Object.freeze(reduce(level, coefficients));
  }

  static zero(level: number): Cyclotomic {
    return new Cyclotomic(level);
  }

  static one(level: number): Cyclotomic {
    return new Cyclotomic(level, [1n]);
  }

  static integer(level: number, value: bigint | number): Cyclotomic {
    return new Cyclotomic(level, [typeof value === "bigint" ? value : BigInt(value)]);
  }

  static zetaPower(level: number, exponent: number): Cyclotomic {
    if (!Number.isSafeInteger(exponent)) throw new RangeError("Zeta exponent must be a safe integer.");
    const normalized = ((exponent % level) + level) % level;
    const coefficients = Array<bigint>(normalized + 1).fill(0n);
    coefficients[normalized] = 1n;
    return new Cyclotomic(level, coefficients);
  }

  static fromTerms(
    level: number,
    terms: Iterable<readonly [exponent: number, coefficient: bigint | number]>,
  ): Cyclotomic {
    const coefficients: bigint[] = [];
    for (const [exponent, coefficient] of terms) {
      if (!Number.isSafeInteger(exponent) || exponent < 0) {
        throw new RangeError("Polynomial exponents must be nonnegative safe integers.");
      }
      while (coefficients.length <= exponent) coefficients.push(0n);
      coefficients[exponent] += typeof coefficient === "bigint" ? coefficient : BigInt(coefficient);
    }
    return new Cyclotomic(level, coefficients);
  }

  static fromJSON(value: CyclotomicJSON): Cyclotomic {
    return new Cyclotomic(value.level, value.coefficients.map((coefficient) => BigInt(coefficient)));
  }

  add(other: Cyclotomic): Cyclotomic {
    assertSameLevel(this, other);
    const length = Math.max(this.coefficients.length, other.coefficients.length);
    const coefficients = Array<bigint>(length).fill(0n);
    for (let index = 0; index < length; index += 1) {
      coefficients[index] = (this.coefficients[index] ?? 0n) + (other.coefficients[index] ?? 0n);
    }
    return new Cyclotomic(this.level, coefficients);
  }

  subtract(other: Cyclotomic): Cyclotomic {
    return this.add(other.negate());
  }

  negate(): Cyclotomic {
    return new Cyclotomic(this.level, this.coefficients.map((coefficient) => -coefficient));
  }

  multiply(other: Cyclotomic): Cyclotomic {
    assertSameLevel(this, other);
    if (this.isZero() || other.isZero()) return Cyclotomic.zero(this.level);
    const coefficients = Array<bigint>(
      this.coefficients.length + other.coefficients.length - 1,
    ).fill(0n);
    for (let left = 0; left < this.coefficients.length; left += 1) {
      for (let right = 0; right < other.coefficients.length; right += 1) {
        coefficients[left + right] += this.coefficients[left]! * other.coefficients[right]!;
      }
    }
    return new Cyclotomic(this.level, coefficients);
  }

  scale(value: bigint | number): Cyclotomic {
    const scalar = typeof value === "bigint" ? value : BigInt(value);
    return new Cyclotomic(this.level, this.coefficients.map((coefficient) => scalar * coefficient));
  }

  timesZeta(exponent: number): Cyclotomic {
    return this.multiply(Cyclotomic.zetaPower(this.level, exponent));
  }

  pow(exponent: number): Cyclotomic {
    if (!Number.isSafeInteger(exponent) || exponent < 0) {
      throw new RangeError("Cyclotomic powers require a nonnegative safe integer.");
    }
    let result = Cyclotomic.one(this.level);
    let base: Cyclotomic = this;
    let remaining = exponent;
    while (remaining > 0) {
      if (remaining % 2 === 1) result = result.multiply(base);
      remaining = Math.floor(remaining / 2);
      if (remaining > 0) base = base.multiply(base);
    }
    return result;
  }

  equals(other: Cyclotomic): boolean {
    if (this.level !== other.level || this.coefficients.length !== other.coefficients.length) return false;
    return this.coefficients.every((coefficient, index) => coefficient === other.coefficients[index]);
  }

  isZero(): boolean {
    return this.coefficients.length === 0;
  }

  toJSON(): CyclotomicJSON {
    return { level: this.level, coefficients: this.coefficients.map(String) };
  }
}

export function formatCyclotomic(value: Cyclotomic, symbol = "ζ"): string {
  if (value.isZero()) return "0";
  const terms: string[] = [];
  for (let exponent = value.coefficients.length - 1; exponent >= 0; exponent -= 1) {
    const coefficient = value.coefficients[exponent] ?? 0n;
    if (coefficient === 0n) continue;
    const negative = coefficient < 0n;
    const magnitude = negative ? -coefficient : coefficient;
    const variable = exponent === 0 ? "" : exponent === 1 ? symbol : `${symbol}^${exponent}`;
    const magnitudeText = variable && magnitude === 1n ? "" : magnitude.toString();
    const body = `${magnitudeText}${variable}`;
    if (terms.length === 0) terms.push(negative ? `-${body}` : body);
    else terms.push(`${negative ? " − " : " + "}${body}`);
  }
  return terms.join("");
}

export function toComplexApprox(value: Cyclotomic): ComplexApproximation {
  let re = 0;
  let im = 0;
  const angle = (2 * Math.PI) / value.level;
  value.coefficients.forEach((coefficient, exponent) => {
    const numeric = Number(coefficient);
    re += numeric * Math.cos(angle * exponent);
    im += numeric * Math.sin(angle * exponent);
  });
  const epsilon = 1e-12;
  return {
    re: Math.abs(re) < epsilon ? 0 : re,
    im: Math.abs(im) < epsilon ? 0 : im,
  };
}
