import type {
  DerivedDiagram,
  Diagnostic,
  PreparedDiagram,
} from "../domain/diagram";
import {
  changCuiSupportDiagnostics,
  deriveLabels,
  validatePreparedDiagram,
} from "../domain/validation";
import {
  Cyclotomic,
  type CyclotomicJSON,
  type ComplexApproximation,
  formatCyclotomic,
  toComplexApprox,
} from "./cyclotomic";
import {
  TaftElement,
  antipodePower,
  iteratedCoproductOfShiftedIntegral,
  multiplyTaft,
  shiftedUpperCointegral,
} from "./taft";

export interface EvaluationOptions {
  signal?: AbortSignal;
  /** Early allocation guard for Phi_l; raise explicitly for larger intended levels. */
  maxLevel?: number;
  /** Maximum number of sparse terms in any one coproduct. */
  maxTensorTerms?: number;
  /** Maximum Cartesian-product states retained while wiring lower circles. */
  maxStates?: number;
  /** Maximum crossing assignments retained across all live contraction-state maps. */
  maxAssignmentCells?: number;
  /** Coarse operation budget, including sparse tensor products and contractions. */
  maxOperations?: number;
}

export interface EvaluationStats {
  level: number;
  lowerTensorTerms: Record<string, number>;
  contractionStates: number;
  peakStates: number;
  operations: number;
  elapsedMs: number;
}

interface EvaluationBase {
  derived?: DerivedDiagram;
  diagnostics: Diagnostic[];
  stats: EvaluationStats;
}

export interface EvaluationOk extends EvaluationBase {
  status: "ok";
  value: Cyclotomic;
  exact: CyclotomicJSON;
  formatted: string;
  approximation: ComplexApproximation;
}

export interface EvaluationFailure extends EvaluationBase {
  status: "invalid" | "unsupported" | "cancelled" | "limit";
}

export type EvaluationResult = EvaluationOk | EvaluationFailure;

type AbortKind = "cancelled" | "limit";

class ComputationAbort extends Error {
  readonly kind: AbortKind;
  readonly code: string;

  constructor(kind: AbortKind, code: string, message: string) {
    super(message);
    this.kind = kind;
    this.code = code;
  }
}

class ComputationBudget {
  readonly options: Required<Omit<EvaluationOptions, "signal">> & Pick<EvaluationOptions, "signal">;
  operations = 0;
  peakStates = 0;

  constructor(options: EvaluationOptions) {
    this.options = {
      signal: options.signal,
      maxLevel: options.maxLevel ?? 101,
      maxTensorTerms: options.maxTensorTerms ?? 250_000,
      maxStates: options.maxStates ?? 500_000,
      maxAssignmentCells: options.maxAssignmentCells ?? 2_000_000,
      maxOperations: options.maxOperations ?? 20_000_000,
    };
    for (const [name, value] of Object.entries(this.options)) {
      if (name === "signal") continue;
      if (!Number.isSafeInteger(value) || (value as number) < 1) {
        throw new RangeError(`${name} must be a positive safe integer.`);
      }
    }
  }

  checkpoint(increment = 1, liveTerms = 0): void {
    this.operations += increment;
    this.peakStates = Math.max(this.peakStates, liveTerms);
    if (this.options.signal?.aborted) {
      throw new ComputationAbort("cancelled", "COMPUTATION_CANCELLED", "The computation was cancelled.");
    }
    if (this.operations > this.options.maxOperations) {
      throw new ComputationAbort(
        "limit",
        "OPERATION_LIMIT",
        `Operation budget ${this.options.maxOperations.toLocaleString()} was exceeded.`,
      );
    }
    if (liveTerms > this.options.maxTensorTerms) {
      throw new ComputationAbort(
        "limit",
        "TENSOR_TERM_LIMIT",
        `A sparse coproduct exceeded ${this.options.maxTensorTerms.toLocaleString()} terms.`,
      );
    }
  }

  states(count: number): void {
    this.peakStates = Math.max(this.peakStates, count);
    if (count > this.options.maxStates) {
      throw new ComputationAbort(
        "limit",
        "STATE_LIMIT",
        `The network contraction exceeded ${this.options.maxStates.toLocaleString()} states.`,
      );
    }
    this.checkpoint(1);
  }

  assignmentCells(count: number): void {
    if (count > this.options.maxAssignmentCells) {
      throw new ComputationAbort(
        "limit",
        "ASSIGNMENT_CELL_LIMIT",
        `The live crossing assignments exceeded ${this.options.maxAssignmentCells.toLocaleString()} cells.`,
      );
    }
  }
}

function binomialBigInt(n: number, k: number): bigint {
  let choose = Math.min(k, n - k);
  let result = 1n;
  for (let index = 1; index <= choose; index += 1) {
    result = (result * BigInt(n - choose + index)) / BigInt(index);
  }
  return result;
}

interface AssignedBasis {
  a: number;
  b: number;
}

interface ContractionState {
  coefficient: Cyclotomic;
  assignments: ReadonlyMap<string, AssignedBasis>;
}

function emptyStats(level: number, started: number): EvaluationStats {
  return {
    level,
    // Circle ids are user-controlled. A null-prototype record ensures a
    // circle named "__proto__" is recorded as data rather than invoking the
    // legacy Object.prototype setter.
    lowerTensorTerms: Object.create(null) as Record<string, number>,
    contractionStates: 0,
    peakStates: 0,
    operations: 0,
    elapsedMs: performance.now() - started,
  };
}

function makeDiagnostic(code: string, path: string, message: string): Diagnostic {
  return { severity: "error", code, path, message };
}

/**
 * Evaluate the verified Chang--Cui prepared network.
 *
 * Every odd total rotation is supported through the explicit canonical shifted
 * Taft tensors e_h and mu_h.  The balanced Taft algebra has identity tilt.
 */
export function evaluatePreparedDiagram(
  diagram: PreparedDiagram,
  level: number,
  options: EvaluationOptions = {},
): EvaluationResult {
  const started = performance.now();
  const stats = emptyStats(level, started);
  const validation = validatePreparedDiagram(diagram);
  if (!validation.valid) {
    return { status: "invalid", diagnostics: validation.diagnostics, stats };
  }
  if (!Number.isSafeInteger(level) || level < 3 || level % 2 === 0) {
    return {
      status: "invalid",
      diagnostics: [
        makeDiagnostic(
          "ODD_TAFT_LEVEL",
          "level",
          "The Taft level l must be an odd integer at least 3.",
        ),
      ],
      stats,
    };
  }

  const derived = deriveLabels(diagram);
  const supportDiagnostics = changCuiSupportDiagnostics(derived);
  if (supportDiagnostics.length > 0) {
    return { status: "unsupported", diagnostics: supportDiagnostics, derived, stats };
  }

  let budget: ComputationBudget;
  try {
    budget = new ComputationBudget(options);
  } catch (error) {
    return {
      status: "invalid",
      diagnostics: [
        makeDiagnostic(
          "EVALUATION_OPTIONS",
          "options",
          error instanceof Error ? error.message : "Invalid evaluation options.",
        ),
      ],
      derived,
      stats,
    };
  }

  try {
    if (level > budget.options.maxLevel) {
      throw new ComputationAbort(
        "limit",
        "LEVEL_LIMIT",
        `Taft level ${level} is above the allocation guard ${budget.options.maxLevel}; ` +
          "raise maxLevel explicitly if this cyclotomic allocation is intended.",
      );
    }
    if (diagram.circles.some((circle) => circle.order.length === 0)) {
      // epsilon(e_h)=0 for a detached lower circle and mu_h(1)=0 for a
      // detached upper circle, so either case kills the entire contraction.
      const value = Cyclotomic.zero(level);
      stats.elapsedMs = performance.now() - started;
      return {
        status: "ok",
        value,
        exact: value.toJSON(),
        formatted: "0",
        approximation: { re: 0, im: 0 },
        diagnostics: [],
        derived,
        stats,
      };
    }
    const crossingPower = new Map(derived.crossings.map((crossing) => [crossing.id, crossing.N]));
    const circleRotation = new Map(derived.circles.map((circle) => [circle.id, circle.R]));
    const lowerCircles = diagram.circles.filter((circle) => circle.kind === "lower");
    const upperCircles = diagram.circles.filter((circle) => circle.kind === "upper");
    let estimatedStates = 1n;
    let estimatedTensorCells = 0n;
    let assignedCrossings = 0n;
    for (const lower of lowerCircles) {
      const termEstimate =
        BigInt(level) * binomialBigInt(level + lower.order.length - 2, lower.order.length - 1);
      if (termEstimate > BigInt(budget.options.maxTensorTerms)) {
        throw new ComputationAbort(
          "limit",
          "TENSOR_TERM_LIMIT",
          `The ${lower.id} coproduct is estimated at ${termEstimate.toLocaleString()} terms, ` +
            `above the guard ${budget.options.maxTensorTerms.toLocaleString()}.`,
        );
      }
      estimatedTensorCells += termEstimate * BigInt(lower.order.length);
      if (estimatedTensorCells > BigInt(budget.options.maxOperations)) {
        throw new ComputationAbort(
          "limit",
          "TENSOR_CELL_LIMIT",
          `The lower coproducts need about ${estimatedTensorCells.toLocaleString()} stored tensor cells, ` +
            `above the operation/allocation guard ${budget.options.maxOperations.toLocaleString()}.`,
        );
      }
      estimatedStates *= termEstimate;
      if (estimatedStates > BigInt(budget.options.maxStates)) {
        throw new ComputationAbort(
          "limit",
          "STATE_LIMIT",
          `The network is estimated at ${estimatedStates.toLocaleString()} states, ` +
            `above the guard ${budget.options.maxStates.toLocaleString()}.`,
        );
      }
      assignedCrossings += BigInt(lower.order.length);
      const estimatedAssignmentCells = assignedCrossings * estimatedStates;
      if (estimatedAssignmentCells > BigInt(budget.options.maxAssignmentCells)) {
        throw new ComputationAbort(
          "limit",
          "ASSIGNMENT_CELL_LIMIT",
          `The contraction is estimated to retain ${estimatedAssignmentCells.toLocaleString()} live crossing assignments, ` +
            `above the guard ${budget.options.maxAssignmentCells.toLocaleString()}.`,
        );
      }
    }
    const estimatedContractionWork = estimatedStates * BigInt(diagram.crossings.length);
    if (estimatedContractionWork > BigInt(budget.options.maxOperations)) {
      throw new ComputationAbort(
        "limit",
        "OPERATION_LIMIT",
        `The contraction needs about ${estimatedContractionWork.toLocaleString()} crossing-state visits, ` +
          `above the operation guard ${budget.options.maxOperations.toLocaleString()}.`,
      );
    }
    let states: ContractionState[] = [
      { coefficient: Cyclotomic.one(level), assignments: new Map() },
    ];
    let assignedCrossingCount = 0;

    for (const lower of lowerCircles) {
      assignedCrossingCount += lower.order.length;
      const tensor = iteratedCoproductOfShiftedIntegral(
        level,
        lower.order.length,
        circleRotation.get(lower.id)!,
        (operations, liveTerms) => budget.checkpoint(operations, liveTerms),
      );
      stats.lowerTensorTerms[lower.id] = tensor.size;
      const next: ContractionState[] = [];
      let wiringOperations = 0;
      for (const state of states) {
        for (const term of tensor.entries()) {
          const assignments = new Map(state.assignments);
          for (let index = 0; index < lower.order.length; index += 1) {
            assignments.set(lower.order[index]!, term.factors[index]!);
          }
          next.push({
            coefficient: state.coefficient.multiply(term.coefficient),
            assignments,
          });
          wiringOperations += lower.order.length;
          if (wiringOperations >= 1_024) {
            budget.checkpoint(wiringOperations, tensor.size);
            wiringOperations = 0;
          }
          if (next.length % 512 === 0) budget.states(next.length);
          if (next.length % 512 === 0) {
            budget.assignmentCells(next.length * assignedCrossingCount);
          }
        }
      }
      budget.checkpoint(wiringOperations, tensor.size);
      budget.states(next.length);
      budget.assignmentCells(next.length * assignedCrossingCount);
      states = next;
    }

    let value = Cyclotomic.zero(level);
    let stateIndex = 0;
    let contractionOperations = 0;
    for (const state of states) {
      let contribution = state.coefficient;
      for (const upper of upperCircles) {
        let product = TaftElement.one(level);
        for (const crossingId of upper.order) {
          const assigned = state.assignments.get(crossingId);
          if (!assigned) {
            throw new Error(`Internal network error: crossing “${crossingId}” has no lower factor.`);
          }
          const factor = antipodePower(
            TaftElement.basis(level, assigned.a, assigned.b),
            crossingPower.get(crossingId)!,
          );
          product = multiplyTaft(product, factor);
          contractionOperations += 1;
          if (contractionOperations >= 256) {
            budget.checkpoint(contractionOperations);
            contractionOperations = 0;
          }
          if (product.isZero()) break;
        }
        contribution = contribution.multiply(
          shiftedUpperCointegral(product, circleRotation.get(upper.id)!),
        );
        if (contribution.isZero()) break;
      }
      value = value.add(contribution);
      stateIndex += 1;
    }
    budget.checkpoint(contractionOperations + stateIndex);

    stats.contractionStates = states.length;
    stats.peakStates = budget.peakStates;
    stats.operations = budget.operations;
    stats.elapsedMs = performance.now() - started;
    return {
      status: "ok",
      value,
      exact: value.toJSON(),
      formatted: formatCyclotomic(value),
      approximation: toComplexApprox(value),
      diagnostics: [],
      derived,
      stats,
    };
  } catch (error) {
    stats.peakStates = budget.peakStates;
    stats.operations = budget.operations;
    stats.elapsedMs = performance.now() - started;
    if (error instanceof ComputationAbort) {
      return {
        status: error.kind,
        diagnostics: [makeDiagnostic(error.code, "computation", error.message)],
        derived,
        stats,
      };
    }
    return {
      status: "invalid",
      diagnostics: [
        makeDiagnostic(
          "INTERNAL_EVALUATION",
          "computation",
          error instanceof Error ? error.message : "Unknown evaluation error.",
        ),
      ],
      derived,
      stats,
    };
  }
}

export interface EvaluationTicket {
  readonly id: number;
  readonly signal: AbortSignal;
}

/** Guards UI state against stale/cancelled computation results. */
export class EvaluationStateGuard {
  #generation = 0;
  #controller: AbortController | undefined;

  begin(): EvaluationTicket {
    this.#controller?.abort();
    this.#controller = new AbortController();
    this.#generation += 1;
    return { id: this.#generation, signal: this.#controller.signal };
  }

  isCurrent(ticket: EvaluationTicket): boolean {
    return ticket.id === this.#generation && !ticket.signal.aborted;
  }

  cancel(): void {
    this.#controller?.abort();
    this.#generation += 1;
  }
}

export function createEvaluationGuard(): EvaluationStateGuard {
  return new EvaluationStateGuard();
}
