import { Cyclotomic } from "./cyclotomic";
import {
  TaftElement,
  antipodePower,
  iteratedCoproductOfIntegral,
  multiplyTaft,
  rightCointegral,
} from "./taft";

/** Direct evaluation of CNW Example 4.18: lambda(Lambda_(7)...Lambda_(1)). */
export function lensL71PublishedFormulaOracle(): Cyclotomic {
  const level = 7;
  const coproduct = iteratedCoproductOfIntegral(level, 7);
  let value = Cyclotomic.zero(level);
  for (const term of coproduct.entries()) {
    let product = TaftElement.one(level);
    for (let index = 6; index >= 0; index -= 1) {
      const factor = term.factors[index]!;
      product = multiplyTaft(product, TaftElement.basis(level, factor.a, factor.b));
    }
    value = value.add(term.coefficient.multiply(rightCointegral(product)));
  }
  return value;
}

/** The exact polynomial printed in CNW Example 4.18, reduced modulo Phi_7. */
export function lensL71PublishedValue(): Cyclotomic {
  return Cyclotomic.fromTerms(7, [
    [1, -42n],
    [2, -35n],
    [3, -28n],
    [4, -21n],
    [5, -14n],
    [6, -7n],
  ]);
}

/**
 * Direct independent transcription of Chang--Wang--Zhai's simplified T^3
 * formula (Section 5), rather than routing the twelve crossing records.
 */
export function threeTorusPublishedFormulaOracle(level = 3): Cyclotomic {
  if (!Number.isSafeInteger(level) || level < 3 || level % 2 === 0) {
    throw new RangeError("The Taft level must be an odd integer at least 3.");
  }
  const tensor = [...iteratedCoproductOfIntegral(level, 4).entries()];
  let value = Cyclotomic.zero(level);
  for (const lambda1 of tensor) {
    for (const lambda2 of tensor) {
      for (const lambda3 of tensor) {
        let first = TaftElement.one(level);
        for (const [source, index, power] of [
          [lambda3, 1, 2],
          [lambda1, 2, 1],
          [lambda3, 3, 1],
          [lambda1, 0, 0],
        ] as const) {
          const factor = source.factors[index]!;
          first = multiplyTaft(
            first,
            antipodePower(TaftElement.basis(level, factor.a, factor.b), power),
          );
        }

        let second = TaftElement.one(level);
        for (const [source, index, power] of [
          [lambda1, 3, 0],
          [lambda2, 2, 1],
          [lambda1, 1, 1],
          [lambda2, 0, 0],
        ] as const) {
          const factor = source.factors[index]!;
          second = multiplyTaft(
            second,
            antipodePower(TaftElement.basis(level, factor.a, factor.b), power),
          );
        }

        let third = TaftElement.one(level);
        for (const [source, index, power] of [
          [lambda2, 3, 1],
          [lambda3, 2, 1],
          [lambda2, 1, 0],
          [lambda3, 0, 0],
        ] as const) {
          const factor = source.factors[index]!;
          third = multiplyTaft(
            third,
            antipodePower(TaftElement.basis(level, factor.a, factor.b), power),
          );
        }

        const coefficient = lambda1.coefficient
          .multiply(lambda2.coefficient)
          .multiply(lambda3.coefficient)
          .multiply(rightCointegral(first))
          .multiply(rightCointegral(second))
          .multiply(rightCointegral(third));
        value = value.add(coefficient);
      }
    }
  }
  return value;
}
