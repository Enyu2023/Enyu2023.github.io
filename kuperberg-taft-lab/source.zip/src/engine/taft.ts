import { Cyclotomic } from "./cyclotomic";

export interface TaftBasisTerm {
  a: number;
  b: number;
  coefficient: Cyclotomic;
}

export interface TaftTensorTerm {
  factors: readonly { a: number; b: number }[];
  coefficient: Cyclotomic;
}

export type AlgebraCheckpoint = (operations: number, liveTerms: number) => void;

const mod = (value: number, modulus: number): number => ((value % modulus) + modulus) % modulus;

function basisKey(level: number, a: number, b: number): number {
  return a * level + mod(b, level);
}

function decodeBasisKey(level: number, key: number): { a: number; b: number } {
  return { a: Math.floor(key / level), b: key % level };
}

function addCoefficient(
  target: Map<number, Cyclotomic>,
  key: number,
  coefficient: Cyclotomic,
): void {
  if (coefficient.isZero()) return;
  const combined = target.get(key)?.add(coefficient) ?? coefficient;
  if (combined.isZero()) target.delete(key);
  else target.set(key, combined);
}

export class TaftElement {
  readonly level: number;
  readonly #terms: ReadonlyMap<number, Cyclotomic>;

  constructor(level: number, terms: Iterable<readonly [number, Cyclotomic]> = []) {
    if (!Number.isSafeInteger(level) || level < 2) throw new RangeError("Taft level must be at least 2.");
    const normalized = new Map<number, Cyclotomic>();
    for (const [key, coefficient] of terms) {
      if (coefficient.level !== level) throw new Error("Taft coefficients use the wrong root of unity.");
      const { a, b } = decodeBasisKey(level, key);
      if (!Number.isSafeInteger(a) || a < 0 || a >= level) continue;
      addCoefficient(normalized, basisKey(level, a, b), coefficient);
    }
    this.level = level;
    this.#terms = normalized;
  }

  static zero(level: number): TaftElement {
    return new TaftElement(level);
  }

  static one(level: number): TaftElement {
    return TaftElement.basis(level, 0, 0);
  }

  static basis(
    level: number,
    a: number,
    b: number,
    coefficient: Cyclotomic = Cyclotomic.one(level),
  ): TaftElement {
    if (!Number.isSafeInteger(a) || a < 0 || a >= level) return TaftElement.zero(level);
    return new TaftElement(level, [[basisKey(level, a, b), coefficient]]);
  }

  *entries(): IterableIterator<TaftBasisTerm> {
    for (const [key, coefficient] of this.#terms) {
      const { a, b } = decodeBasisKey(this.level, key);
      yield { a, b, coefficient };
    }
  }

  coefficient(a: number, b: number): Cyclotomic {
    return this.#terms.get(basisKey(this.level, a, b)) ?? Cyclotomic.zero(this.level);
  }

  get size(): number {
    return this.#terms.size;
  }

  isZero(): boolean {
    return this.#terms.size === 0;
  }

  add(other: TaftElement): TaftElement {
    if (this.level !== other.level) throw new Error("Cannot mix Taft algebras with different levels.");
    const terms = new Map<number, Cyclotomic>();
    for (const term of this.entries()) {
      addCoefficient(terms, basisKey(this.level, term.a, term.b), term.coefficient);
    }
    for (const term of other.entries()) {
      addCoefficient(terms, basisKey(this.level, term.a, term.b), term.coefficient);
    }
    return new TaftElement(this.level, terms);
  }

  scale(coefficient: Cyclotomic): TaftElement {
    if (coefficient.level !== this.level) throw new Error("Taft scalar uses the wrong root of unity.");
    return new TaftElement(
      this.level,
      [...this.entries()].map((term) => [
        basisKey(this.level, term.a, term.b),
        term.coefficient.multiply(coefficient),
      ] as const),
    );
  }
}

/** Multiplication in the x^a g^b basis, with g x = zeta x g. */
export function multiplyTaft(left: TaftElement, right: TaftElement): TaftElement {
  if (left.level !== right.level) throw new Error("Cannot mix Taft algebras with different levels.");
  const level = left.level;
  const terms = new Map<number, Cyclotomic>();
  for (const first of left.entries()) {
    for (const second of right.entries()) {
      const a = first.a + second.a;
      if (a >= level) continue;
      const coefficient = first.coefficient
        .multiply(second.coefficient)
        .timesZeta(first.b * second.a);
      addCoefficient(terms, basisKey(level, a, first.b + second.b), coefficient);
    }
  }
  return new TaftElement(level, terms);
}

export function powerTaft(base: TaftElement, exponent: number): TaftElement {
  if (!Number.isSafeInteger(exponent) || exponent < 0) {
    throw new RangeError("Taft powers require a nonnegative safe integer.");
  }
  let result = TaftElement.one(base.level);
  let factor = base;
  let remaining = exponent;
  while (remaining > 0) {
    if (remaining % 2 === 1) result = multiplyTaft(result, factor);
    remaining = Math.floor(remaining / 2);
    if (remaining > 0) factor = multiplyTaft(factor, factor);
  }
  return result;
}

export function normalizedLeftIntegral(level: number): TaftElement {
  let result = TaftElement.zero(level);
  const xTop = TaftElement.basis(level, level - 1, 0);
  for (let exponent = 0; exponent < level; exponent += 1) {
    // The paper writes Lambda = (sum_i g^i) x^(l-1); keep that order.
    result = result.add(
      multiplyTaft(TaftElement.basis(level, 0, exponent), xTop),
    );
  }
  return result;
}

function halfIntegerIndexFromR(R: number, sign: "lower" | "upper"): number {
  if (!Number.isSafeInteger(R) || R % 2 === 0) {
    throw new RangeError("A total-rotation label R=2 theta must be an odd safe integer.");
  }
  // lower: h=theta=n-1/2; upper: h=-theta=n-1/2.
  return sign === "lower" ? (R + 1) / 2 : (1 - R) / 2;
}

/**
 * Chang--Cui's canonical shifted lower tensor
 *   e_(n-1/2) = zeta^n sum_b zeta^(-nb) x^(l-1) g^b,
 * where n=(R+1)/2.  The Taft algebra is balanced, so its tilt T is identity.
 */
export function shiftedLowerIntegral(level: number, R: number): TaftElement {
  const n = mod(halfIntegerIndexFromR(R, "lower"), level);
  let result = TaftElement.zero(level);
  for (let b = 0; b < level; b += 1) {
    result = result.add(
      TaftElement.basis(
        level,
        level - 1,
        b,
        Cyclotomic.zetaPower(level, n * (1 - b)),
      ),
    );
  }
  return result;
}

/**
 * The normalized right cointegral for the displayed coproduct convention:
 *   lambda(x^a g^b) = zeta delta_(a,l-1) delta_(b,1).
 *
 * This satisfies (lambda tensor id)Delta(h)=lambda(h)1 and lambda(Lambda)=1.
 * CNW Example 4.18 prints delta_{x^(l-1)} in the x^a g^b basis, but that
 * literal functional does not satisfy the right-cointegral identity here.
 */
export function rightCointegral(element: TaftElement): Cyclotomic {
  return element.coefficient(element.level - 1, 1).timesZeta(1);
}

/**
 * Chang--Cui's shifted upper functional for h=-theta=n-1/2:
 *   mu_(n-1/2)(x^a g^b)=delta_(a,l-1) delta_(b,1-n).
 */
export function shiftedUpperCointegral(element: TaftElement, R: number): Cyclotomic {
  const n = mod(halfIntegerIndexFromR(R, "upper"), element.level);
  return element.coefficient(element.level - 1, 1 - n);
}

function antipodeOnce(element: TaftElement, inverse: boolean): TaftElement {
  const level = element.level;
  let result = TaftElement.zero(level);
  const gInverse = TaftElement.basis(level, 0, -1);
  const x = TaftElement.basis(level, 1, 0);
  // S(x)=-xg^-1; S^-1(x)=-g^-1x.
  const imageOfX = (inverse
    ? multiplyTaft(gInverse, x)
    : multiplyTaft(x, gInverse)
  ).scale(Cyclotomic.integer(level, -1n));
  for (const term of element.entries()) {
    const image = multiplyTaft(
      TaftElement.basis(level, 0, -term.b),
      powerTaft(imageOfX, term.a),
    ).scale(term.coefficient);
    result = result.add(image);
  }
  return result;
}

export function antipode(element: TaftElement): TaftElement {
  return antipodeOnce(element, false);
}

export function inverseAntipode(element: TaftElement): TaftElement {
  return antipodeOnce(element, true);
}

export function antipodePower(element: TaftElement, exponent: number): TaftElement {
  if (!Number.isSafeInteger(exponent)) throw new RangeError("Antipode power must be a safe integer.");
  const order = 2 * element.level;
  const forward = mod(exponent, order);
  const backward = order - forward;
  let result = element;
  if (forward <= backward) {
    for (let step = 0; step < forward; step += 1) result = antipode(result);
  } else {
    for (let step = 0; step < backward; step += 1) result = inverseAntipode(result);
  }
  return result;
}

function tensorKey(level: number, factors: readonly { a: number; b: number }[]): string {
  return factors.map(({ a, b }) => basisKey(level, a, b).toString(36)).join(".");
}

function decodeTensorKey(level: number, key: string): { a: number; b: number }[] {
  if (key === "") return [];
  return key.split(".").map((part) => decodeBasisKey(level, Number.parseInt(part, 36)));
}

function addTensorCoefficient(
  target: Map<string, Cyclotomic>,
  key: string,
  coefficient: Cyclotomic,
): void {
  if (coefficient.isZero()) return;
  const combined = target.get(key)?.add(coefficient) ?? coefficient;
  if (combined.isZero()) target.delete(key);
  else target.set(key, combined);
}

export class TaftTensor {
  readonly level: number;
  readonly arity: number;
  readonly #terms: ReadonlyMap<string, Cyclotomic>;

  constructor(
    level: number,
    arity: number,
    terms: Iterable<readonly [string, Cyclotomic]> = [],
  ) {
    this.level = level;
    this.arity = arity;
    const normalized = new Map<string, Cyclotomic>();
    for (const [key, coefficient] of terms) addTensorCoefficient(normalized, key, coefficient);
    this.#terms = normalized;
  }

  static one(level: number, arity: number): TaftTensor {
    return TaftTensor.single(
      level,
      Array.from({ length: arity }, () => ({ a: 0, b: 0 })),
    );
  }

  static single(
    level: number,
    factors: readonly { a: number; b: number }[],
    coefficient: Cyclotomic = Cyclotomic.one(level),
  ): TaftTensor {
    return new TaftTensor(level, factors.length, [[tensorKey(level, factors), coefficient]]);
  }

  *entries(): IterableIterator<TaftTensorTerm> {
    for (const [key, coefficient] of this.#terms) {
      yield { factors: decodeTensorKey(this.level, key), coefficient };
    }
  }

  get size(): number {
    return this.#terms.size;
  }
}

export function multiplyTensors(
  left: TaftTensor,
  right: TaftTensor,
  checkpoint?: AlgebraCheckpoint,
): TaftTensor {
  if (left.level !== right.level || left.arity !== right.arity) {
    throw new Error("Tensor multiplication needs matching Taft levels and arities.");
  }
  const level = left.level;
  const terms = new Map<string, Cyclotomic>();
  let operations = 0;
  for (const first of left.entries()) {
    for (const second of right.entries()) {
      operations += 1;
      let coefficient = first.coefficient.multiply(second.coefficient);
      const factors: { a: number; b: number }[] = [];
      let zero = false;
      for (let index = 0; index < left.arity; index += 1) {
        const l = first.factors[index]!;
        const r = second.factors[index]!;
        if (l.a + r.a >= level) {
          zero = true;
          break;
        }
        coefficient = coefficient.timesZeta(l.b * r.a);
        factors.push({ a: l.a + r.a, b: mod(l.b + r.b, level) });
      }
      if (!zero) addTensorCoefficient(terms, tensorKey(level, factors), coefficient);
      if (operations % 256 === 0) checkpoint?.(256, terms.size);
    }
  }
  checkpoint?.(operations % 256, terms.size);
  return new TaftTensor(level, left.arity, terms);
}

export function powerTensor(
  base: TaftTensor,
  exponent: number,
  checkpoint?: AlgebraCheckpoint,
): TaftTensor {
  if (!Number.isSafeInteger(exponent) || exponent < 0) {
    throw new RangeError("Tensor powers require a nonnegative safe integer.");
  }
  let result = TaftTensor.one(base.level, base.arity);
  let factor = base;
  let remaining = exponent;
  while (remaining > 0) {
    if (remaining % 2 === 1) result = multiplyTensors(result, factor, checkpoint);
    remaining = Math.floor(remaining / 2);
    if (remaining > 0) factor = multiplyTensors(factor, factor, checkpoint);
  }
  return result;
}

/** Sparse Delta^(arity)(Lambda), in the circle's positive crossing order. */
export function iteratedCoproductOfIntegral(
  level: number,
  arity: number,
  checkpoint?: AlgebraCheckpoint,
): TaftTensor {
  if (!Number.isSafeInteger(arity) || arity < 1) {
    throw new RangeError("An iterated coproduct needs positive arity.");
  }
  const deltaXTerms: Array<readonly [string, Cyclotomic]> = [];
  for (let position = 0; position < arity; position += 1) {
    const factors = Array.from({ length: arity }, (_, index) => ({
      a: index === position ? 1 : 0,
      b: index > position ? 1 : 0,
    }));
    deltaXTerms.push([tensorKey(level, factors), Cyclotomic.one(level)]);
  }
  const deltaX = new TaftTensor(level, arity, deltaXTerms);
  const xTop = powerTensor(deltaX, level - 1, checkpoint);

  const result = new Map<string, Cyclotomic>();
  for (let groupPower = 0; groupPower < level; groupPower += 1) {
    const deltaG = TaftTensor.single(
      level,
      Array.from({ length: arity }, () => ({ a: 0, b: groupPower })),
    );
    const summand = multiplyTensors(deltaG, xTop, checkpoint);
    for (const term of summand.entries()) {
      addTensorCoefficient(result, tensorKey(level, term.factors), term.coefficient);
    }
    checkpoint?.(1, result.size);
  }
  return new TaftTensor(level, arity, result);
}

/** Sparse iterated coproduct of the canonical shifted lower tensor e_theta. */
export function iteratedCoproductOfShiftedIntegral(
  level: number,
  arity: number,
  R: number,
  checkpoint?: AlgebraCheckpoint,
): TaftTensor {
  if (!Number.isSafeInteger(arity) || arity < 1) {
    throw new RangeError("An iterated coproduct needs positive arity.");
  }
  const n = mod(halfIntegerIndexFromR(R, "lower"), level);
  const deltaXTerms: Array<readonly [string, Cyclotomic]> = [];
  for (let position = 0; position < arity; position += 1) {
    const factors = Array.from({ length: arity }, (_, index) => ({
      a: index === position ? 1 : 0,
      b: index > position ? 1 : 0,
    }));
    deltaXTerms.push([tensorKey(level, factors), Cyclotomic.one(level)]);
  }
  const xTop = powerTensor(new TaftTensor(level, arity, deltaXTerms), level - 1, checkpoint);
  const result = new Map<string, Cyclotomic>();
  for (let b = 0; b < level; b += 1) {
    const deltaG = TaftTensor.single(
      level,
      Array.from({ length: arity }, () => ({ a: 0, b })),
    );
    // E_(l-1,b)=x^(l-1)g^b, so Delta(g^b) is multiplied on the right.
    const summand = multiplyTensors(xTop, deltaG, checkpoint);
    const scalar = Cyclotomic.zetaPower(level, n * (1 - b));
    for (const term of summand.entries()) {
      addTensorCoefficient(
        result,
        tensorKey(level, term.factors),
        term.coefficient.multiply(scalar),
      );
    }
    checkpoint?.(1, result.size);
  }
  return new TaftTensor(level, arity, result);
}

/** Generic binary coproduct, useful for algebra law tests. */
export function coproduct(element: TaftElement, checkpoint?: AlgebraCheckpoint): TaftTensor {
  const level = element.level;
  const deltaX = new TaftTensor(level, 2, [
    [tensorKey(level, [{ a: 1, b: 0 }, { a: 0, b: 1 }]), Cyclotomic.one(level)],
    [tensorKey(level, [{ a: 0, b: 0 }, { a: 1, b: 0 }]), Cyclotomic.one(level)],
  ]);
  const result = new Map<string, Cyclotomic>();
  for (const term of element.entries()) {
    const xPower = powerTensor(deltaX, term.a, checkpoint);
    const deltaG = TaftTensor.single(level, [
      { a: 0, b: term.b },
      { a: 0, b: term.b },
    ]);
    const image = multiplyTensors(xPower, deltaG, checkpoint);
    for (const tensorTerm of image.entries()) {
      addTensorCoefficient(
        result,
        tensorKey(level, tensorTerm.factors),
        tensorTerm.coefficient.multiply(term.coefficient),
      );
    }
  }
  return new TaftTensor(level, 2, result);
}
