import { clonePreparedDiagram, type PreparedDiagram } from "../domain/diagram";

export interface ExampleExpectation {
  canonicalCoefficients: string[];
  display: string;
  sourceNote: string;
}

export interface ExampleDefinition {
  id: string;
  label: string;
  level: number;
  diagram: PreparedDiagram;
  expected?: ExampleExpectation;
  note: string;
}

const zeros = (length: number): number[] => Array.from({ length }, () => 0);

const lensCrossingIds = Array.from({ length: 7 }, (_, index) => `p${index + 1}`);

export const lensSpaceL71: ExampleDefinition = {
  id: "lens-l71",
  label: "Lens space L(7,1)",
  level: 7,
  note:
    "Prepared Chang–Cui-normalized version of the CNW L(7,1) reference network. " +
    "The separate oracle makes CNW Example 4.18's right-cointegral sidedness correction explicit.",
  expected: {
    // The printed degree-six expression is reduced modulo Phi_7 here.
    canonicalCoefficients: ["7", "-35", "-28", "-21", "-14", "-7"],
    display: "−42ζ₇ − 35ζ₇² − 28ζ₇³ − 21ζ₇⁴ − 14ζ₇⁵ − 7ζ₇⁶",
    sourceNote: "Chang–Ng–Wang, Example 4.18 (arXiv:2506.07409).",
  },
  diagram: {
    schemaVersion: 1,
    name: "L(7,1), CNW left framing",
    genus: 1,
    description:
      "Prepared genus-one network for the published f_L formula. Coordinates are zero at the reference combing.",
    source: {
      label: "Chang–Ng–Wang, Generalizations of Frobenius–Schur indicators, Example 4.18",
      url: "https://arxiv.org/abs/2506.07409",
      note: "Formula λ(Λ_(7)Λ_(6)⋯Λ_(1)) and its Taft T(ζ₇) value.",
    },
    basis: {
      labels: ["x₁", "y₁", "ν₁", "μ₁"],
      combing: zeros(4),
    },
    circles: [
      {
        id: "eta1",
        kind: "lower",
        R0: 1,
        B: zeros(4),
        order: lensCrossingIds,
        drawing: {
          color: "#3f8c74",
          points: [
            { x: 8, y: 52 },
            { x: 92, y: 52 },
          ],
        },
      },
      {
        id: "mu1",
        kind: "upper",
        R0: -1,
        B: zeros(4),
        order: lensCrossingIds,
        drawing: {
          color: "#5766ba",
          points: [
            { x: 14, y: 18 },
            { x: 24, y: 84 },
            { x: 38, y: 18 },
            { x: 50, y: 84 },
            { x: 62, y: 18 },
            { x: 76, y: 84 },
            { x: 88, y: 18 },
          ],
        },
      },
    ],
    crossings: lensCrossingIds.map((id, index) => ({
      id,
      N0: 1,
      A: zeros(4),
      endpoints: { lower: "eta1", upper: "mu1" },
      point: { x: 14 + index * 12, y: 52 },
    })),
  },
};

const lensL72UpperOrder = ["p7", "p2", "p4", "p6", "p1", "p3", "p5"];
const lensL72Powers: Record<string, number> = {
  p1: 1,
  p2: 1,
  p3: 3,
  p4: 3,
  p5: 1,
  p6: 1,
  p7: 1,
};

export const lensSpaceL72: ExampleDefinition = {
  id: "lens-l72",
  label: "Lens space L(7,2)",
  level: 7,
  note:
    "Chang–Ng–Wang's f_R prepared genus-one network. Its exact Taft value is the " +
    "published zero comparison for L(7,1).",
  expected: {
    canonicalCoefficients: [],
    display: "0",
    sourceNote: "Chang–Ng–Wang, Example 4.18 (arXiv:2506.07409).",
  },
  diagram: {
    schemaVersion: 1,
    name: "L(7,2), CNW right framing",
    genus: 1,
    description:
      "Prepared f_R genus-one network with the published cyclic upper order and antipode powers.",
    source: {
      label: "Chang–Ng–Wang, Generalizations of Frobenius–Schur indicators, Example 4.18",
      url: "https://arxiv.org/abs/2506.07409",
      note: "Published L(7,2) f_R contraction and zero Taft value.",
    },
    basis: {
      labels: ["x₁", "y₁", "ν₁", "μ₁"],
      combing: zeros(4),
    },
    circles: [
      {
        id: "eta1",
        kind: "lower",
        R0: 1,
        B: zeros(4),
        order: lensCrossingIds,
        drawing: {
          color: "#3f8c74",
          points: [
            { x: 8, y: 52 },
            { x: 92, y: 52 },
          ],
        },
      },
      {
        id: "mu1",
        kind: "upper",
        R0: 1,
        B: zeros(4),
        order: lensL72UpperOrder,
        drawing: {
          color: "#5766ba",
          points: [
            { x: 14, y: 18 },
            { x: 24, y: 84 },
            { x: 38, y: 18 },
            { x: 50, y: 84 },
            { x: 62, y: 18 },
            { x: 76, y: 84 },
            { x: 88, y: 18 },
          ],
        },
      },
    ],
    crossings: lensCrossingIds.map((id, index) => ({
      id,
      N0: lensL72Powers[id]!,
      A: zeros(4),
      endpoints: { lower: "eta1", upper: "mu1" },
      point: { x: 14 + index * 12, y: 52 },
    })),
  },
};

const p = ["p1", "p2", "p3", "p4"];
const q = ["q1", "q2", "q3", "q4"];
const r = ["r1", "r2", "r3", "r4"];
const t3Power: Record<string, number> = {
  p1: 1,
  p2: 2,
  p3: 2,
  p4: 1,
  q1: 1,
  q2: 1,
  q3: 2,
  q4: 2,
  r1: 1,
  r2: 3,
  r3: 2,
  r4: 2,
};
const t3Upper: Record<string, string> = {
  p1: "mu1",
  r4: "mu1",
  p3: "mu1",
  r2: "mu1",
  q1: "mu2",
  p2: "mu2",
  q3: "mu2",
  p4: "mu2",
  r1: "mu3",
  q2: "mu3",
  r3: "mu3",
  q4: "mu3",
};
const t3Lower: Record<string, string> = Object.fromEntries([
  ...p.map((id) => [id, "eta1"]),
  ...q.map((id) => [id, "eta2"]),
  ...r.map((id) => [id, "eta3"]),
]);
const t3Point: Record<string, { x: number; y: number }> = {
  p1: { x: 18, y: 25 },
  p2: { x: 39, y: 25 },
  p3: { x: 61, y: 25 },
  p4: { x: 82, y: 25 },
  q1: { x: 18, y: 50 },
  q2: { x: 39, y: 50 },
  q3: { x: 61, y: 50 },
  q4: { x: 82, y: 50 },
  r1: { x: 18, y: 75 },
  r2: { x: 39, y: 75 },
  r3: { x: 61, y: 75 },
  r4: { x: 82, y: 75 },
};

export const threeTorus: ExampleDefinition = {
  id: "three-torus",
  label: "3-torus T³",
  level: 3,
  note:
    "The twelve published crossing powers and the three published upper-circle orders from " +
    "Chang–Wang–Zhai Section 5. All upper totals are R=-1, hence λ∘S⁻¹.",
  expected: {
    canonicalCoefficients: [],
    display: "0",
    sourceNote: "Independent evaluation of the Section 5 simplified formula at T(ζ₃).",
  },
  diagram: {
    schemaVersion: 1,
    name: "T³, Chang–Wang–Zhai framing f₁",
    genus: 3,
    description:
      "Prepared genus-three crossing network. Geometry is a schematic input view; orders and exponents are the published algebraic data.",
    source: {
      label: "Chang–Wang–Zhai, On gauge invariance …, Section 5",
      url: "https://arxiv.org/abs/2601.19485",
      note: "Published crossing orders and antipode powers for the framed 3-torus.",
    },
    basis: {
      labels: [
        "x₁", "y₁", "x₂", "y₂", "x₃", "y₃",
        "ν₁", "ν₂", "ν₃",
        "μ₁", "μ₂", "μ₃",
      ],
      combing: zeros(12),
    },
    circles: [
      ...[
        ["eta1", p, 25, "#34866f"],
        ["eta2", q, 50, "#8a62ac"],
        ["eta3", r, 75, "#df8b3e"],
      ].map(([id, order, y, color]) => ({
        id: id as string,
        kind: "lower" as const,
        R0: 1,
        B: zeros(12),
        order: order as string[],
        drawing: {
          color: color as string,
          points: [
            { x: 7, y: y as number },
            { x: 93, y: y as number },
          ],
        },
      })),
      ...[
        ["mu1", ["p1", "r4", "p3", "r2"], "#4672bd"],
        ["mu2", ["q1", "p2", "q3", "p4"], "#252b38"],
        ["mu3", ["r1", "q2", "r3", "q4"], "#c94f56"],
      ].map(([id, order, color], index) => ({
        id: id as string,
        kind: "upper" as const,
        R0: -1,
        B: zeros(12),
        order: order as string[],
        drawing: {
          color: color as string,
          points: [
            { x: 15 + index * 7, y: 12 },
            { x: 84 - index * 4, y: 88 },
          ],
        },
      })),
    ],
    crossings: [...p, ...q, ...r].map((id) => ({
      id,
      N0: t3Power[id]!,
      A: zeros(12),
      endpoints: { lower: t3Lower[id]!, upper: t3Upper[id]! },
      point: t3Point[id],
    })),
  },
};

export const EXAMPLES: readonly ExampleDefinition[] = [lensSpaceL71, lensSpaceL72, threeTorus];

export const EXAMPLE_DIAGRAMS: readonly PreparedDiagram[] = EXAMPLES.map((example) => example.diagram);

export function getExample(id: string): ExampleDefinition | undefined {
  const example = EXAMPLES.find((candidate) => candidate.id === id);
  return example
    ? { ...example, diagram: clonePreparedDiagram(example.diagram) }
    : undefined;
}
