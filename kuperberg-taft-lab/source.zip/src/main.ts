import "./style.css";
import * as EngineModule from "./engine/index";
import * as ExampleModule from "./examples/index";
import {
  DiagramEditor,
  type SketchCurve,
  type SketchData,
  type TrustedCrossingPin,
  type VisualIntersection,
} from "./ui/diagram-editor";

type CircleKind = "lower" | "upper";

interface PreparedCircle {
  id: string;
  kind: CircleKind;
  R0: number;
  B: number[];
  order: string[];
  labelsPrepared?: boolean;
}

interface PreparedCrossing {
  id: string;
  N0: number;
  A: number[];
  endpoints: { lower: string; upper: string };
  labelsPrepared?: boolean;
  point?: { x: number; y: number };
}

interface PreparedDiagram {
  schemaVersion: 1;
  name: string;
  genus: number;
  basis: { labels: string[]; combing: number[] };
  circles: PreparedCircle[];
  crossings: PreparedCrossing[];
}

interface WorkspaceFile {
  format: "kuperberg-taft-workspace";
  version: 1;
  level: number;
  sourceExample?: string;
  diagram: PreparedDiagram;
  drawing: SketchData;
}

interface UiIssue {
  severity: "error" | "warning";
  message: string;
  path?: string;
}

interface ExampleDefinition {
  id: string;
  label: string;
  level: number;
  diagram: PreparedDiagram;
  note?: string;
  drawing?: SketchData;
}

type LooseRecord = Record<string, unknown>;

const engine = EngineModule as unknown as LooseRecord;
const exampleLibrary = ExampleModule as unknown as LooseRecord;
const STORAGE_KEY = "kuperberg-taft-lab.workspace.v1";
const INPUT_LIMITS = {
  fileBytes: 2 * 1024 * 1024,
  genus: 12,
  basisEntries: 48,
  circles: 24,
  crossings: 512,
  orderEntriesPerCircle: 512,
  drawingCurves: 48,
  drawingPointsPerCurve: 256,
  drawingPointsTotal: 4096,
} as const;

let workspace = loadInitialWorkspace();
let activeExampleId = workspace.sourceExample ?? "custom";
let derived: unknown = null;
let evaluation: unknown = null;
let evaluationIsStale = false;
let isComputing = false;
let saveTimer: number | undefined;
let toastTimer: number | undefined;

const app = document.querySelector<HTMLElement>("#app");
if (!app) throw new Error("The application mount point is missing.");

app.innerHTML = shellTemplate();

const diagramEditor = new DiagramEditor(requiredElement("#diagram-editor"), {
  onChange: (drawing) => {
    workspace.drawing = drawing;
    markChanged({ refreshDerived: false });
  },
  onUseSuggestions: useVisualSuggestions,
  onStatus: (message) => showToast(message),
});

app.addEventListener("click", handleClick);
app.addEventListener("input", handleInput);
app.addEventListener("change", handleChange);
app.addEventListener("keydown", handleTableKeyboard);
window.addEventListener("beforeunload", saveImmediately);

refreshAll();
if (localStorage.getItem(STORAGE_KEY)) {
  showToast("Your last local draft was restored.", "saved");
}

function shellTemplate(): string {
  return `
    <header class="site-header">
      <a class="brand" href="#top" aria-label="Kuperberg Taft Lab home">
        <span class="brand-mark" aria-hidden="true"><i></i><i></i><i></i></span>
        <span><strong>Kuperberg</strong><small>Taft Lab</small></span>
      </a>
      <nav class="header-nav" aria-label="Page sections">
        <a href="#numbered-data">Numbered data</a>
        <a href="#drawing">Drawing</a>
        <a href="#about">Method</a>
      </nav>
      <div class="save-state" id="save-state" aria-live="polite">
        <span class="save-dot"></span><span>Saved locally</span>
      </div>
    </header>

    <main id="workspace">
      <section class="hero" id="top">
        <div class="hero-copy">
          <div class="eyebrow"><span></span> Odd Taft algebras · exact finite state sum</div>
          <h1>From a numbered diagram<br />to an exact invariant.</h1>
          <p>Describe a combed Heegaard diagram with integers, check its labels, and evaluate the Kuperberg invariant entirely in your browser.</p>
        </div>
        <div class="orbit-graphic" aria-hidden="true">
          <svg viewBox="0 0 400 250">
            <ellipse class="orbit orbit--one" cx="200" cy="125" rx="154" ry="57" transform="rotate(13 200 125)" />
            <ellipse class="orbit orbit--two" cx="200" cy="125" rx="126" ry="85" transform="rotate(-29 200 125)" />
            <path class="orbit orbit--three" d="M58 153c45-80 91-104 145-56 62 56 103 23 139-28" />
            <circle class="orbit-point p1" cx="100" cy="80" r="6" />
            <circle class="orbit-point p2" cx="270" cy="181" r="6" />
            <circle class="orbit-center" cx="200" cy="125" r="12" />
          </svg>
          <span class="orbit-label orbit-label--a">α</span>
          <span class="orbit-label orbit-label--b">β</span>
          <span class="orbit-label orbit-label--k">K<sub>l</sub></span>
        </div>
      </section>

      <section class="control-deck" aria-label="Calculator controls">
        <label class="control-field example-control">
          <span>Start with</span>
          <select id="example-select" aria-describedby="example-note">
            ${exampleOptions()}
          </select>
        </label>
        <div class="control-divider" aria-hidden="true"></div>
        <label class="control-field level-control">
          <span>Odd Taft level <i>ℓ</i></span>
          <input id="level-input" type="number" inputmode="numeric" min="3" step="2" value="${workspace.level}" aria-describedby="level-help" />
        </label>
        <button class="primary-button compute-button" type="button" data-action="compute">
          <span class="button-label">Compute invariant</span>
          <span class="button-spinner" aria-hidden="true"></span>
          ${iconArrow()}
        </button>
        <button class="icon-button more-button" type="button" data-action="toggle-file-menu" aria-label="Import and export options" aria-expanded="false">
          ${iconDots()}
        </button>
        <div class="file-menu" id="file-menu" hidden>
          <button type="button" data-action="import">${iconUpload()} Import JSON</button>
          <button type="button" data-action="export">${iconDownload()} Export workspace</button>
          <button type="button" data-action="clear">${iconReset()} New blank workspace</button>
        </div>
        <input id="import-file" type="file" accept="application/json,.json" hidden />
      </section>
      <p class="control-help"><span id="example-note"></span><span id="level-help">ℓ must be an odd integer, at least 3.</span></p>

      <section id="result-region" class="result-region" aria-live="polite"></section>
      <section id="validation-region" aria-live="assertive"></section>

      <section class="workspace-section intro-section" id="numbered-data">
        <div class="section-heading">
          <div>
            <span class="step-number">01</span>
            <div>
              <p class="section-kicker">Trusted input</p>
              <h2>Number the diagram</h2>
              <p>These values—not the drawing—are passed to the invariant engine.</p>
            </div>
          </div>
          <span class="trust-badge">${iconShield()} Used in computation</span>
        </div>

        <div class="identity-card panel-card">
          <label class="field grow-field">
            <span>Manifold / diagram name</span>
            <input id="diagram-name" type="text" maxlength="100" value="${escapeAttr(workspace.diagram.name)}" placeholder="Untitled combed diagram" />
          </label>
          <label class="field genus-field">
            <span>Genus <i>g</i></span>
            <input id="genus-input" type="number" min="1" max="12" step="1" value="${workspace.diagram.genus}" />
          </label>
          <div class="identity-summary" id="identity-summary"></div>
        </div>

        <div class="subsection-heading">
          <div>
            <h3>Combing data</h3>
            <p>Enter the <strong>4g</strong> numbered coefficients in the chosen Heegaard–spider basis.</p>
          </div>
          <button class="text-button" type="button" data-action="zero-combing">Set all to zero</button>
        </div>
        <div class="combing-grid" id="combing-grid"></div>

        <div class="subsection-heading table-heading">
          <div>
            <h3>Circle inspector</h3>
            <p><i>R</i><sub>0</sub> is the starting rotation; <i>B</i> is an integer vector; order lists crossing IDs from the basepoint.</p>
          </div>
          <div class="button-pair">
            <button class="small-button lower-button" type="button" data-action="add-circle" data-kind="lower">+ Lower circle</button>
            <button class="small-button upper-button" type="button" data-action="add-circle" data-kind="upper">+ Upper circle</button>
          </div>
        </div>
        <div class="table-card" id="circle-table"></div>

        <div class="subsection-heading table-heading">
          <div>
            <h3>Crossing inspector</h3>
            <p>Set each crossing’s endpoints, <i>N</i><sub>0</sub>, and antipode exponent vector <i>A</i>.</p>
          </div>
          <button class="small-button" type="button" data-action="add-crossing">+ Add crossing</button>
        </div>
        <div class="table-card" id="crossing-table"></div>
      </section>

      <section class="workspace-section drawing-section" id="drawing">
        <div class="section-heading">
          <div>
            <span class="step-number">02</span>
            <div>
              <p class="section-kicker">Optional canvas</p>
              <h2>Sketch the geometry</h2>
              <p>Draw polylines, drag their points, and compare visual intersections with the trusted table.</p>
            </div>
          </div>
          <span class="visual-badge">${iconEye()} Visual aid only</span>
        </div>
        <div class="diagram-editor panel-card" id="diagram-editor"></div>
      </section>

      <section class="method-section" id="about">
        <div>
          <p class="section-kicker">What happens when you compute</p>
          <h2>Transparent by design.</h2>
        </div>
        <ol class="method-steps">
          <li><span>1</span><div><strong>Validate</strong><p>Check genus, endpoints, orders, and the 4g combing coefficients.</p></div></li>
          <li><span>2</span><div><strong>Derive labels</strong><p>Propagate circle rotations <i>R</i> (with θ = <i>R</i>/2) and crossing exponents <i>N</i>.</p></div></li>
          <li><span>3</span><div><strong>Contract exactly</strong><p>Evaluate the finite Taft-algebra state sum in a cyclotomic basis.</p></div></li>
        </ol>
      </section>
    </main>

    <footer class="site-footer">
      <div class="brand footer-brand"><span class="brand-mark" aria-hidden="true"><i></i><i></i><i></i></span><span><strong>Kuperberg</strong><small>Taft Lab</small></span></div>
      <p>Research software for reproducible computations. Verify conventions before citing a result.</p>
      <a href="./source.zip" download>Download source ↓</a>
    </footer>
    <div class="toast" id="toast" role="status" aria-live="polite"></div>
  `;
}

function refreshAll(): void {
  derived = tryDerive(workspace.diagram);
  syncTopControls();
  renderIdentitySummary();
  renderCombing();
  renderCircleTable();
  renderCrossingTable();
  renderValidation();
  renderResult();
  updateExampleNote();
  diagramEditor.setData(workspace.drawing, workspace.diagram.circles.map((circle) => circle.id), trustedPins());
}

function syncTopControls(): void {
  const exampleSelect = requiredElement<HTMLSelectElement>("#example-select");
  exampleSelect.value = [...exampleSelect.options].some((option) => option.value === activeExampleId)
    ? activeExampleId
    : "custom";
  requiredElement<HTMLInputElement>("#level-input").value = String(workspace.level);
  requiredElement<HTMLInputElement>("#diagram-name").value = workspace.diagram.name;
  requiredElement<HTMLInputElement>("#genus-input").value = String(workspace.diagram.genus);
}

function renderIdentitySummary(): void {
  const lowerCount = workspace.diagram.circles.filter((circle) => circle.kind === "lower").length;
  const upperCount = workspace.diagram.circles.filter((circle) => circle.kind === "upper").length;
  requiredElement("#identity-summary").innerHTML = `
    <span><strong>${lowerCount}</strong> lower</span>
    <span><strong>${upperCount}</strong> upper</span>
    <span><strong>${workspace.diagram.crossings.length}</strong> crossings</span>`;
}

function renderCombing(): void {
  const expected = 4 * workspace.diagram.genus;
  const html = Array.from({ length: expected }, (_, index) => {
    const label = workspace.diagram.basis.labels[index] ?? defaultBasisLabel(index, workspace.diagram.genus);
    const value = finiteNumber(workspace.diagram.basis.combing[index], 0);
    return `
      <div class="combing-field">
        <span class="field-index" aria-hidden="true">${index + 1}</span>
        <label>
          <span class="visually-hidden">Basis label ${index + 1}</span>
          <input class="basis-label-input" data-basis-label-index="${index}" type="text" maxlength="30" value="${escapeAttr(label)}" aria-label="Name of combing coefficient ${index + 1}" />
        </label>
        <label>
          <span class="visually-hidden">Combing coefficient ${index + 1}</span>
          <input class="coefficient-input" data-combing-index="${index}" type="number" step="1" value="${value}" aria-label="Value of combing coefficient ${index + 1}, ${escapeAttr(label)}" />
        </label>
      </div>`;
  }).join("");
  requiredElement("#combing-grid").innerHTML = html;
}

function renderCircleTable(): void {
  const rows = workspace.diagram.circles
    .map((circle, index) => {
      const R = derivedCircleValue(circle.id, "R");
      const theta = derivedCircleTheta(circle.id);
      return `
        <tr data-circle-row="${index}" tabindex="0">
          <td data-label="Family"><span class="family-pill family-pill--${circle.kind}"><i></i>${capitalise(circle.kind)}</span></td>
          <td data-label="ID"><input class="table-input id-input" data-circle-index="${index}" data-circle-field="id" data-original-id="${escapeAttr(circle.id)}" value="${escapeAttr(circle.id)}" aria-label="Circle ${index + 1} ID" /></td>
          <td data-label="R₀"><input class="table-input number-input" data-circle-index="${index}" data-circle-field="R0" type="number" step="1" value="${circle.R0}" aria-label="R zero for ${escapeAttr(circle.id)}" /></td>
          <td data-label="B vector"><input class="table-input vector-input" data-circle-index="${index}" data-circle-field="B" value="${escapeAttr(formatIntegerList(circle.B))}" placeholder="0, 1" aria-label="B vector for ${escapeAttr(circle.id)}" /></td>
          <td data-label="Crossing order"><input class="table-input order-input" data-circle-index="${index}" data-circle-field="order" value="${escapeAttr(circle.order.join(", "))}" placeholder="x0, x1, …" aria-label="Crossing order for ${escapeAttr(circle.id)}" /></td>
          <td data-label="Labels ready"><label class="ready-check"><input data-circle-index="${index}" data-circle-field="labelsPrepared" type="checkbox" ${circle.labelsPrepared === false ? "" : "checked"} aria-label="Numeric labels ready for ${escapeAttr(circle.id)}" /><span>Ready</span></label></td>
          <td data-label="Derived R"><output class="derived-value" title="Derived by the label propagation step">${formatDerived(R)}</output></td>
          <td data-label="Derived θ"><output class="derived-value" title="Half the derived total rotation">${formatDerived(theta)}</output></td>
          <td class="row-action"><button class="row-delete" type="button" data-action="delete-circle" data-index="${index}" aria-label="Delete circle ${escapeAttr(circle.id)}">${iconTrash()}</button></td>
        </tr>`;
    })
    .join("");

  requiredElement("#circle-table").innerHTML = `
    <div class="table-scroll">
      <table>
        <thead><tr><th>Family</th><th>ID</th><th><i>R</i><sub>0</sub></th><th><i>B</i> vector</th><th>Order from basepoint</th><th>Labels ready</th><th>Derived <i>R</i></th><th>θ</th><th><span class="visually-hidden">Actions</span></th></tr></thead>
        <tbody>${rows || `<tr><td class="empty-table" colspan="9">No circles yet. Add one above.</td></tr>`}</tbody>
      </table>
    </div>`;
}

function renderCrossingTable(): void {
  const lowerCircles = workspace.diagram.circles.filter((circle) => circle.kind === "lower");
  const upperCircles = workspace.diagram.circles.filter((circle) => circle.kind === "upper");
  const rows = workspace.diagram.crossings
    .map((crossing, index) => {
      const N = derivedCrossingValue(crossing.id, "N");
      return `
        <tr data-crossing-row="${index}" tabindex="0">
          <td data-label="ID"><input class="table-input id-input" data-crossing-index="${index}" data-crossing-field="id" data-original-id="${escapeAttr(crossing.id)}" value="${escapeAttr(crossing.id)}" aria-label="Crossing ${index + 1} ID" /></td>
          <td data-label="Lower endpoint"><select class="table-input endpoint-select lower-select" data-crossing-index="${index}" data-crossing-field="lower" aria-label="Lower endpoint of ${escapeAttr(crossing.id)}">${circleOptions(lowerCircles, crossing.endpoints.lower)}</select></td>
          <td data-label="Upper endpoint"><select class="table-input endpoint-select upper-select" data-crossing-index="${index}" data-crossing-field="upper" aria-label="Upper endpoint of ${escapeAttr(crossing.id)}">${circleOptions(upperCircles, crossing.endpoints.upper)}</select></td>
          <td data-label="N₀"><input class="table-input number-input" data-crossing-index="${index}" data-crossing-field="N0" type="number" step="1" value="${crossing.N0}" aria-label="N zero for ${escapeAttr(crossing.id)}" /></td>
          <td data-label="A vector"><input class="table-input vector-input" data-crossing-index="${index}" data-crossing-field="A" value="${escapeAttr(formatIntegerList(crossing.A))}" placeholder="1, −1" aria-label="A vector for ${escapeAttr(crossing.id)}" /></td>
          <td data-label="Labels ready"><label class="ready-check"><input data-crossing-index="${index}" data-crossing-field="labelsPrepared" type="checkbox" ${crossing.labelsPrepared === false ? "" : "checked"} aria-label="Numeric labels ready for ${escapeAttr(crossing.id)}" /><span>Ready</span></label></td>
          <td data-label="Derived N"><output class="derived-value">${formatDerived(N)}</output></td>
          <td class="row-action"><button class="row-delete" type="button" data-action="delete-crossing" data-index="${index}" aria-label="Delete crossing ${escapeAttr(crossing.id)}">${iconTrash()}</button></td>
        </tr>`;
    })
    .join("");

  requiredElement("#crossing-table").innerHTML = `
    <div class="table-scroll">
      <table>
        <thead><tr><th>ID</th><th>Lower endpoint</th><th>Upper endpoint</th><th><i>N</i><sub>0</sub></th><th><i>A</i> vector</th><th>Labels ready</th><th>Derived <i>N</i></th><th><span class="visually-hidden">Actions</span></th></tr></thead>
        <tbody>${rows || `<tr><td class="empty-table" colspan="8">No crossings yet. Add one above or review visual suggestions.</td></tr>`}</tbody>
      </table>
    </div>`;
}

function renderValidation(): void {
  const issues = collectIssues();
  const errors = issues.filter((issue) => issue.severity === "error");
  const warnings = issues.filter((issue) => issue.severity === "warning");
  const region = requiredElement("#validation-region");
  if (!issues.length) {
    region.innerHTML = "";
    return;
  }
  region.innerHTML = `
    <div class="validation-card ${errors.length ? "has-errors" : "has-warnings"}">
      <div class="validation-icon">${errors.length ? iconAlert() : iconInfo()}</div>
      <div>
        <h2>${errors.length ? `${errors.length} item${errors.length === 1 ? "" : "s"} need attention` : "A quick check before computing"}</h2>
        <ul>${issues.slice(0, 8).map((issue) => `<li class="${issue.severity}">${escapeText(issue.message)}${issue.path ? `<small>${escapeText(issue.path)}</small>` : ""}</li>`).join("")}</ul>
        ${issues.length > 8 ? `<p>${issues.length - 8} more issue${issues.length - 8 === 1 ? "" : "s"} will appear after these are fixed.</p>` : ""}
      </div>
      <span class="issue-count">${errors.length ? `${errors.length} error${errors.length === 1 ? "" : "s"}` : `${warnings.length} warning${warnings.length === 1 ? "" : "s"}`}</span>
    </div>`;
}

function renderResult(): void {
  const region = requiredElement("#result-region");
  if (isComputing) {
    region.innerHTML = `
      <div class="result-card result-card--loading">
        <div class="result-orbit" aria-hidden="true"><i></i><i></i><i></i></div>
        <div><p class="result-kicker">Evaluating finite state sum</p><h2>Contracting the diagram…</h2><p>This runs locally. Larger crossing sets can take longer.</p></div>
      </div>`;
    return;
  }
  if (evaluation === null) {
    region.innerHTML = `
      <div class="ready-strip">
        <span>${iconCalculator()}</span>
        <p><strong>Ready when your numbered data is.</strong> Derived labels update as you edit; press Compute invariant for the exact contraction.</p>
      </div>`;
    return;
  }

  const interpreted = interpretEvaluation(evaluation);
  if (!interpreted.ok) {
    region.innerHTML = `
      <div class="result-card result-card--failure">
        <div class="result-status-icon">${iconAlert()}</div>
        <div class="result-main">
          <p class="result-kicker">${escapeText(interpreted.statusLabel)}</p>
          <h2>${escapeText(interpreted.title)}</h2>
          <p>${escapeText(interpreted.message)}</p>
          ${interpreted.details.length ? `<ul>${interpreted.details.map((item) => `<li>${escapeText(item)}</li>`).join("")}</ul>` : ""}
        </div>
        <button type="button" class="small-button" data-action="focus-errors">Review input</button>
      </div>`;
    return;
  }

  const stats = interpreted.stats;
  region.innerHTML = `
    <div class="result-card result-card--success ${evaluationIsStale ? "is-stale" : ""}">
      <div class="result-main">
        <div class="result-heading-row">
          <div>
            <p class="result-kicker">Exact Kuperberg invariant · T<sub>${workspace.level}</sub></p>
            <h2>${escapeText(workspace.diagram.name || "Untitled diagram")}</h2>
          </div>
          <span class="result-status-pill">${evaluationIsStale ? "Input changed" : `${iconCheck()} Computed`}</span>
        </div>
        <div class="exact-value-wrap">
          <code class="exact-value">${escapeText(interpreted.formatted)}</code>
          <button class="copy-button" type="button" data-action="copy-result" data-copy-value="${escapeAttr(interpreted.formatted)}">${iconCopy()} Copy</button>
        </div>
        ${interpreted.approximation ? `<p class="approximation"><span>Numerical check</span><code>${escapeText(interpreted.approximation)}</code></p>` : ""}
        ${evaluationIsStale ? `<p class="stale-note">The numbered input changed after this result. Compute again to refresh it.</p>` : ""}
      </div>
      <dl class="result-stats">
        ${stats.length ? stats.slice(0, 5).map(([label, value]) => `<div><dt>${escapeText(label)}</dt><dd>${escapeText(value)}</dd></div>`).join("") : `<div><dt>Genus</dt><dd>${workspace.diagram.genus}</dd></div><div><dt>Crossings</dt><dd>${workspace.diagram.crossings.length}</dd></div><div><dt>Level ℓ</dt><dd>${workspace.level}</dd></div>`}
      </dl>
    </div>`;
}

async function computeInvariant(): Promise<void> {
  if (isComputing) return;
  const issues = collectIssues();
  const errors = issues.filter((issue) => issue.severity === "error");
  if (errors.length) {
    renderValidation();
    requiredElement("#validation-region").scrollIntoView({ behavior: "smooth", block: "center" });
    showToast("Fix the numbered input before computing.", "error");
    return;
  }

  isComputing = true;
  renderResult();
  syncComputingButton();
  await nextPaint();
  try {
    const fn = firstFunction(engine, ["evaluateKuperberg", "evaluatePreparedDiagram"]);
    if (!fn) throw new Error("The invariant evaluator is not available in this build.");
    evaluation = await Promise.resolve(fn(workspace.diagram, workspace.level));
    const maybeDerived = asRecord(evaluation)?.derived;
    if (maybeDerived) derived = maybeDerived;
    evaluationIsStale = false;
    showToast(interpretEvaluation(evaluation).ok ? "Exact evaluation complete." : "The evaluator could not complete this input.");
  } catch (error) {
    evaluation = { status: "invalid", message: errorMessage(error) };
    evaluationIsStale = false;
  } finally {
    isComputing = false;
    renderResult();
    renderCircleTable();
    renderCrossingTable();
    syncComputingButton();
    saveSoon();
  }
}

function handleClick(event: MouseEvent): void {
  const target = event.target as HTMLElement;
  const button = target.closest<HTMLElement>("[data-action]");
  if (!button) return;
  const action = button.dataset.action;
  if (action === "compute") void computeInvariant();
  else if (action === "toggle-file-menu") toggleFileMenu(button as HTMLButtonElement);
  else if (action === "import") {
    requiredElement<HTMLInputElement>("#import-file").click();
    closeFileMenu();
  } else if (action === "export") {
    exportWorkspace();
    closeFileMenu();
  } else if (action === "clear") {
    clearWorkspace();
    closeFileMenu();
  } else if (action === "zero-combing") {
    workspace.diagram.basis.combing = Array(4 * workspace.diagram.genus).fill(0);
    activeExampleId = "custom";
    markChanged();
  } else if (action === "add-circle") {
    addCircle(button.dataset.kind === "upper" ? "upper" : "lower");
  } else if (action === "delete-circle") {
    deleteCircle(Number(button.dataset.index));
  } else if (action === "add-crossing") {
    addCrossing();
  } else if (action === "delete-crossing") {
    deleteCrossing(Number(button.dataset.index));
  } else if (action === "copy-result") {
    void copyText(button.dataset.copyValue ?? "", button);
  } else if (action === "focus-errors") {
    requiredElement("#validation-region").scrollIntoView({ behavior: "smooth", block: "center" });
  }
}

function handleInput(event: Event): void {
  const input = event.target as HTMLInputElement | HTMLSelectElement;
  if (input.id === "diagram-name") {
    workspace.diagram.name = input.value;
    activeExampleId = "custom";
    markChanged({ refreshDerived: false, render: false });
    return;
  }
  if (input.id === "level-input") {
    workspace.level = parseIntegerInput(input.value);
    activeExampleId = "custom";
    markChanged({ refreshDerived: false, render: false });
    return;
  }
  if (input.dataset.combingIndex !== undefined) {
    const index = Number(input.dataset.combingIndex);
    workspace.diagram.basis.combing[index] = parseIntegerInput(input.value);
    activeExampleId = "custom";
    markChanged({ render: false });
    updateDerivedOutputs();
    return;
  }
  if (input.dataset.basisLabelIndex !== undefined) {
    workspace.diagram.basis.labels[Number(input.dataset.basisLabelIndex)] = input.value;
    activeExampleId = "custom";
    markChanged({ refreshDerived: false, render: false });
    return;
  }
  if (input.dataset.circleIndex !== undefined && input.dataset.circleField) {
    if (input.dataset.circleField === "id") return;
    updateCircleFromInput(input);
    return;
  }
  if (input.dataset.crossingIndex !== undefined && input.dataset.crossingField) {
    if (input.dataset.crossingField === "id") return;
    updateCrossingFromInput(input);
  }
}

function handleChange(event: Event): void {
  const input = event.target as HTMLInputElement | HTMLSelectElement;
  if (input.id === "example-select") {
    loadExample(input.value);
    return;
  }
  if (input.id === "import-file" && input instanceof HTMLInputElement) {
    void importWorkspace(input.files?.[0]);
    input.value = "";
    return;
  }
  if (input.id === "genus-input") {
    changeGenus(finiteInteger(Number(input.value), workspace.diagram.genus));
    return;
  }
  if (input.id === "level-input") {
    workspace.level = parseIntegerInput(input.value);
    activeExampleId = "custom";
    markChanged();
    return;
  }
  if (input.dataset.circleIndex !== undefined && input.dataset.circleField === "id") {
    renameCircle(Number(input.dataset.circleIndex), input.dataset.originalId ?? "", input.value);
    return;
  }
  if (input.dataset.crossingIndex !== undefined && input.dataset.crossingField === "id") {
    renameCrossing(Number(input.dataset.crossingIndex), input.dataset.originalId ?? "", input.value);
    return;
  }
  if (input.dataset.crossingField === "lower" || input.dataset.crossingField === "upper") {
    updateCrossingFromInput(input);
    renderValidation();
    diagramEditor.setData(workspace.drawing, workspace.diagram.circles.map((circle) => circle.id), trustedPins());
  }
}

function handleTableKeyboard(event: KeyboardEvent): void {
  const row = (event.target as HTMLElement).closest<HTMLElement>("[data-circle-row], [data-crossing-row]");
  if (!row || event.key !== "Enter" || (event.target as HTMLElement).matches("input, select, button")) return;
  row.querySelector<HTMLInputElement>("input")?.focus();
}

function updateCircleFromInput(input: HTMLInputElement | HTMLSelectElement): void {
  const circle = workspace.diagram.circles[Number(input.dataset.circleIndex)];
  if (!circle) return;
  const field = input.dataset.circleField;
  if (field === "R0") circle.R0 = parseIntegerInput(input.value);
  else if (field === "B") circle.B = parseNumberList(input.value);
  else if (field === "order") circle.order = parseIdList(input.value);
  else if (field === "labelsPrepared" && input instanceof HTMLInputElement) {
    circle.labelsPrepared = input.checked;
    activeExampleId = "custom";
    markChanged({ refreshDerived: false });
    return;
  }
  activeExampleId = "custom";
  markChanged({ render: false });
  updateDerivedOutputs();
}

function updateCrossingFromInput(input: HTMLInputElement | HTMLSelectElement): void {
  const crossing = workspace.diagram.crossings[Number(input.dataset.crossingIndex)];
  if (!crossing) return;
  const field = input.dataset.crossingField;
  if (field === "N0") crossing.N0 = parseIntegerInput(input.value);
  else if (field === "A") crossing.A = parseNumberList(input.value);
  else if (field === "lower") crossing.endpoints.lower = input.value;
  else if (field === "upper") crossing.endpoints.upper = input.value;
  else if (field === "labelsPrepared" && input instanceof HTMLInputElement) {
    crossing.labelsPrepared = input.checked;
    activeExampleId = "custom";
    markChanged({ refreshDerived: false });
    return;
  }
  activeExampleId = "custom";
  markChanged({ render: false });
  updateDerivedOutputs();
}

function changeGenus(nextGenus: number): void {
  const genus = Math.max(1, Math.min(12, nextGenus));
  const previousGenus = workspace.diagram.genus;
  remapCoordinateData(previousGenus, genus);
  workspace.diagram.genus = genus;
  for (const kind of ["lower", "upper"] as const) {
    while (workspace.diagram.circles.filter((circle) => circle.kind === kind).length < genus) {
      workspace.diagram.circles.push(newCircle(kind));
    }
  }
  activeExampleId = "custom";
  markChanged();
}

function addCircle(kind: CircleKind): void {
  workspace.diagram.circles.push(newCircle(kind));
  activeExampleId = "custom";
  markChanged();
}

function deleteCircle(index: number): void {
  const circle = workspace.diagram.circles[index];
  if (!circle) return;
  workspace.diagram.circles.splice(index, 1);
  const removedCrossingIds = new Set(
    workspace.diagram.crossings
      .filter((crossing) => crossing.endpoints.lower === circle.id || crossing.endpoints.upper === circle.id)
      .map((crossing) => crossing.id),
  );
  workspace.diagram.crossings = workspace.diagram.crossings.filter((crossing) => !removedCrossingIds.has(crossing.id));
  workspace.diagram.circles.forEach((item) => {
    item.order = item.order.filter((id) => !removedCrossingIds.has(id));
  });
  activeExampleId = "custom";
  markChanged();
  showToast(`Removed ${circle.id} and ${removedCrossingIds.size} incident crossing${removedCrossingIds.size === 1 ? "" : "s"}.`);
}

function renameCircle(index: number, oldId: string, rawId: string): void {
  const circle = workspace.diagram.circles[index];
  if (!circle) return;
  const id = sanitiseId(rawId, circle.id);
  if (workspace.diagram.circles.some((item, itemIndex) => itemIndex !== index && item.id === id)) {
    showToast(`Circle ID “${id}” is already in use.`, "error");
    renderCircleTable();
    return;
  }
  const previous = oldId || circle.id;
  circle.id = id;
  workspace.diagram.crossings.forEach((crossing) => {
    if (crossing.endpoints.lower === previous) crossing.endpoints.lower = id;
    if (crossing.endpoints.upper === previous) crossing.endpoints.upper = id;
  });
  activeExampleId = "custom";
  markChanged();
}

function addCrossing(): void {
  const lower = workspace.diagram.circles.find((circle) => circle.kind === "lower")?.id ?? "";
  const upper = workspace.diagram.circles.find((circle) => circle.kind === "upper")?.id ?? "";
  const crossing: PreparedCrossing = {
    id: nextId("x", new Set(workspace.diagram.crossings.map((item) => item.id))),
    N0: 0,
    A: Array(4 * workspace.diagram.genus).fill(0),
    endpoints: { lower, upper },
    labelsPrepared: false,
  };
  workspace.diagram.crossings.push(crossing);
  workspace.diagram.circles.find((circle) => circle.id === lower)?.order.push(crossing.id);
  workspace.diagram.circles.find((circle) => circle.id === upper)?.order.push(crossing.id);
  activeExampleId = "custom";
  markChanged();
}

function deleteCrossing(index: number): void {
  const crossing = workspace.diagram.crossings[index];
  if (!crossing) return;
  workspace.diagram.crossings.splice(index, 1);
  workspace.diagram.circles.forEach((circle) => {
    circle.order = circle.order.filter((id) => id !== crossing.id);
  });
  activeExampleId = "custom";
  markChanged();
}

function renameCrossing(index: number, oldId: string, rawId: string): void {
  const crossing = workspace.diagram.crossings[index];
  if (!crossing) return;
  const id = sanitiseId(rawId, crossing.id);
  if (workspace.diagram.crossings.some((item, itemIndex) => itemIndex !== index && item.id === id)) {
    showToast(`Crossing ID “${id}” is already in use.`, "error");
    renderCrossingTable();
    return;
  }
  const previous = oldId || crossing.id;
  crossing.id = id;
  workspace.diagram.circles.forEach((circle) => {
    circle.order = circle.order.map((item) => (item === previous ? id : item));
  });
  activeExampleId = "custom";
  markChanged();
}

function useVisualSuggestions(suggestions: VisualIntersection[]): void {
  const circlesById = new Map(workspace.diagram.circles.map((circle) => [circle.id, circle]));
  const linked = suggestions.filter((suggestion) => {
    const lower = circlesById.get(suggestion.lowerCurveId);
    const upper = circlesById.get(suggestion.upperCurveId);
    return lower?.kind === "lower" && upper?.kind === "upper";
  });
  if (!linked.length) {
    showToast("Link sketch curves by giving them the same IDs as lower and upper circles first.", "error");
    return;
  }
  const skipped = suggestions.length - linked.length;
  const message = `Replace the crossing table and circle orders with ${linked.length} visual suggestion${linked.length === 1 ? "" : "s"}?${skipped ? ` ${skipped} unlinked suggestion${skipped === 1 ? "" : "s"} will be skipped.` : ""} The suggested rows will stay blocked until you enter and confirm their numeric labels.`;
  if (!window.confirm(message)) return;

  const existingIds = new Set<string>();
  workspace.diagram.crossings = linked.map((suggestion, index) => {
    const id = nextId(`x${index}`, existingIds);
    existingIds.add(id);
    return {
      id,
      N0: 0,
      A: Array(4 * workspace.diagram.genus).fill(0),
      endpoints: { lower: suggestion.lowerCurveId, upper: suggestion.upperCurveId },
      labelsPrepared: false,
      point: { x: suggestion.point.x / 9, y: suggestion.point.y / 5.6 },
    };
  });
  workspace.diagram.circles.forEach((circle) => {
    const ordered = linked
      .map((suggestion, index) => ({
        suggestion,
        id: workspace.diagram.crossings[index].id,
        position: positionAfterSketchBasepoint(suggestion, circle),
      }))
      .filter(({ suggestion }) =>
        circle.kind === "lower" ? suggestion.lowerCurveId === circle.id : suggestion.upperCurveId === circle.id,
      )
      .sort((a, b) => a.position - b.position);
    circle.order = ordered.map((item) => item.id);
  });
  activeExampleId = "custom";
  markChanged();
  showToast(`${linked.length} suggestion${linked.length === 1 ? "" : "s"} copied into the draft table. Review N₀ and A, then mark every row ready.`, "saved");
  requiredElement("#crossing-table").scrollIntoView({ behavior: "smooth", block: "center" });
}

function collectIssues(): UiIssue[] {
  const issues = localIssues();
  try {
    const validate = firstFunction(engine, ["validateDiagram", "validatePreparedDiagram"]);
    if (validate) issues.push(...extractValidationIssues(validate(workspace.diagram)));
  } catch (error) {
    issues.push({ severity: "error", message: errorMessage(error), path: "engine validation" });
  }
  return deduplicateIssues(issues);
}

function localIssues(): UiIssue[] {
  const diagram = workspace.diagram;
  const issues: UiIssue[] = [];
  if (!Number.isInteger(workspace.level) || workspace.level < 3 || workspace.level % 2 === 0) {
    issues.push({ severity: "error", message: "Taft level ℓ must be an odd integer of at least 3.", path: "level" });
  }
  if (!Number.isInteger(diagram.genus) || diagram.genus < 1) {
    issues.push({ severity: "error", message: "Genus g must be a positive integer.", path: "diagram.genus" });
  }
  if (diagram.basis.combing.length !== 4 * diagram.genus) {
    issues.push({ severity: "error", message: `The combing needs exactly 4g = ${4 * diagram.genus} coefficients.`, path: "diagram.basis.combing" });
  }
  const lower = diagram.circles.filter((circle) => circle.kind === "lower");
  const upper = diagram.circles.filter((circle) => circle.kind === "upper");
  if (lower.length !== diagram.genus) {
    issues.push({ severity: "error", message: `A genus-${diagram.genus} input needs ${diagram.genus} lower circle${diagram.genus === 1 ? "" : "s"}; found ${lower.length}.`, path: "diagram.circles" });
  }
  if (upper.length !== diagram.genus) {
    issues.push({ severity: "error", message: `A genus-${diagram.genus} input needs ${diagram.genus} upper circle${diagram.genus === 1 ? "" : "s"}; found ${upper.length}.`, path: "diagram.circles" });
  }
  const circleIds = diagram.circles.map((circle) => circle.id);
  const crossingIds = diagram.crossings.map((crossing) => crossing.id);
  duplicateValues(circleIds).forEach((id) => issues.push({ severity: "error", message: `Circle ID “${id}” is duplicated.`, path: "diagram.circles" }));
  duplicateValues(crossingIds).forEach((id) => issues.push({ severity: "error", message: `Crossing ID “${id}” is duplicated.`, path: "diagram.crossings" }));
  const crossingSet = new Set(crossingIds);
  diagram.circles.forEach((circle) => {
    duplicateValues(circle.order).forEach((id) => issues.push({ severity: "error", message: `${circle.id} lists crossing “${id}” more than once.`, path: `${circle.id}.order` }));
    circle.order.filter((id) => !crossingSet.has(id)).forEach((id) => issues.push({ severity: "error", message: `${circle.id} refers to missing crossing “${id}”.`, path: `${circle.id}.order` }));
  });
  diagram.crossings.forEach((crossing) => {
    const lowerCircle = diagram.circles.find((circle) => circle.id === crossing.endpoints.lower);
    const upperCircle = diagram.circles.find((circle) => circle.id === crossing.endpoints.upper);
    if (lowerCircle?.kind !== "lower") issues.push({ severity: "error", message: `${crossing.id} needs an existing lower endpoint.`, path: `${crossing.id}.endpoints.lower` });
    if (upperCircle?.kind !== "upper") issues.push({ severity: "error", message: `${crossing.id} needs an existing upper endpoint.`, path: `${crossing.id}.endpoints.upper` });
    if (lowerCircle && !lowerCircle.order.includes(crossing.id)) issues.push({ severity: "warning", message: `${crossing.id} is not listed in ${lowerCircle.id}’s crossing order.`, path: `${lowerCircle.id}.order` });
    if (upperCircle && !upperCircle.order.includes(crossing.id)) issues.push({ severity: "warning", message: `${crossing.id} is not listed in ${upperCircle.id}’s crossing order.`, path: `${upperCircle.id}.order` });
  });
  return issues;
}

function extractValidationIssues(result: unknown): UiIssue[] {
  if (result == null || result === true) return [];
  if (result === false) return [{ severity: "error", message: "The engine rejected this diagram." }];
  if (Array.isArray(result)) return result.flatMap((item) => issueFromUnknown(item, "error"));
  const record = asRecord(result);
  if (!record) return [];
  const issues: UiIssue[] = [];
  for (const [key, severity] of [["errors", "error"], ["warnings", "warning"], ["issues", "error"], ["diagnostics", "error"]] as const) {
    const collection = record[key];
    if (Array.isArray(collection)) issues.push(...collection.flatMap((item) => issueFromUnknown(item, severity)));
  }
  if ((record.ok === false || record.valid === false) && !issues.length) {
    issues.push(...issueFromUnknown(record.message ?? "The engine rejected this diagram.", "error"));
  }
  return issues;
}

function issueFromUnknown(value: unknown, fallbackSeverity: "error" | "warning"): UiIssue[] {
  if (typeof value === "string") return [{ severity: fallbackSeverity, message: value }];
  const record = asRecord(value);
  if (!record) return [];
  const severity = record.severity === "warning" ? "warning" : fallbackSeverity;
  const message = String(record.message ?? record.reason ?? record.code ?? "Invalid diagram input.");
  const rawPath = record.path ?? record.field ?? record.at;
  const path = Array.isArray(rawPath) ? rawPath.join(".") : rawPath == null ? undefined : String(rawPath);
  return [{ severity, message, path }];
}

function tryDerive(diagram: PreparedDiagram): unknown {
  try {
    const fn = firstFunction(engine, ["deriveLabels"]);
    return fn ? fn(diagram) : null;
  } catch {
    return null;
  }
}

function derivedCircleValue(id: string, key: string): unknown {
  return findDerivedEntry(derived, ["circles", "circleLabels", "derivedCircles"], id)?.[key] ??
    findDerivedEntry(derived, ["circles", "circleLabels", "derivedCircles"], id)?.[key.toLowerCase()];
}

function derivedCircleTheta(id: string): unknown {
  const entry = findDerivedEntry(derived, ["circles", "circleLabels", "derivedCircles"], id);
  const numerator = entry?.thetaNumerator;
  const denominator = entry?.thetaDenominator;
  if (typeof numerator === "number" && typeof denominator === "number") {
    if (denominator === 2 && numerator % 2 !== 0) return `${numerator}/2`;
    return numerator / denominator;
  }
  return entry?.theta ?? entry?.Theta;
}

function derivedCrossingValue(id: string, key: string): unknown {
  const entry = findDerivedEntry(derived, ["crossings", "crossingLabels", "derivedCrossings"], id);
  return entry?.[key] ?? entry?.[key.toLowerCase()] ?? entry?.[key.toUpperCase()];
}

function findDerivedEntry(value: unknown, collectionKeys: string[], id: string): LooseRecord | undefined {
  const record = asRecord(value);
  if (!record) return undefined;
  for (const key of collectionKeys) {
    const collection = record[key];
    if (Array.isArray(collection)) {
      const found = collection.map(asRecord).find((entry) => entry?.id === id);
      if (found) return found;
    }
    const collectionRecord = asRecord(collection);
    const byId = collectionRecord ? asRecord(collectionRecord[id]) : undefined;
    if (byId) return byId;
  }
  return undefined;
}

function updateDerivedOutputs(): void {
  derived = tryDerive(workspace.diagram);
  document.querySelectorAll<HTMLElement>("[data-circle-row]").forEach((row) => {
    const index = Number(row.dataset.circleRow);
    const value = derivedCircleValue(workspace.diagram.circles[index]?.id ?? "", "R");
    const outputs = row.querySelectorAll("output");
    if (outputs[0]) outputs[0].innerHTML = formatDerived(value);
    if (outputs[1]) outputs[1].innerHTML = formatDerived(derivedCircleTheta(workspace.diagram.circles[index]?.id ?? ""));
  });
  document.querySelectorAll<HTMLElement>("[data-crossing-row]").forEach((row) => {
    const index = Number(row.dataset.crossingRow);
    const crossing = workspace.diagram.crossings[index];
    const outputs = row.querySelectorAll("output");
    if (outputs[0]) outputs[0].innerHTML = formatDerived(derivedCrossingValue(crossing?.id ?? "", "N"));
  });
}

function interpretEvaluation(value: unknown): {
  ok: boolean;
  statusLabel: string;
  title: string;
  message: string;
  details: string[];
  formatted: string;
  approximation: string;
  stats: Array<[string, string]>;
} {
  const record = asRecord(value);
  const status = String(record?.status ?? (record?.ok === false ? "invalid" : "ok"));
  const successful = status === "ok" || record?.ok === true || (!record?.status && record?.ok !== false);
  if (!successful) {
    const labels: Record<string, [string, string]> = {
      invalid: ["Input rejected", "The numbered diagram is not ready to evaluate."],
      unsupported: ["Outside this implementation", "This diagram uses a case the current evaluator does not support."],
      limit: ["Safety limit reached", "The state sum is larger than the browser safety limit."],
      cancelled: ["Evaluation cancelled", "No result was produced."],
    };
    const [statusLabel, title] = labels[status] ?? ["Evaluation stopped", "The invariant could not be computed."];
    const details = extractStringDetails(record?.diagnostics ?? record?.errors ?? record?.issues ?? record?.details);
    return {
      ok: false,
      statusLabel,
      title,
      message: String(record?.message ?? record?.reason ?? details[0] ?? "Review the input and try again."),
      details,
      formatted: "",
      approximation: "",
      stats: [],
    };
  }

  const exactValue = record?.value ?? value;
  let formatted = typeof record?.formatted === "string" ? record.formatted : "";
  if (!formatted) {
    const format = firstFunction(engine, ["formatExact", "formatCyclotomic"]);
    try {
      formatted = format ? String(format(exactValue)) : readableValue(exactValue);
    } catch {
      formatted = readableValue(exactValue);
    }
  }
  let approximation = readableApproximation(record?.approximation);
  if (!approximation) {
    const approximate = firstFunction(engine, ["toComplexApprox"]);
    try {
      approximation = approximate ? readableApproximation(approximate(exactValue, workspace.level)) : "";
    } catch {
      approximation = "";
    }
  }
  return {
    ok: true,
    statusLabel: "Computed",
    title: "Exact invariant",
    message: "",
    details: [],
    formatted: formatted || "0",
    approximation,
    stats: statsEntries(record?.stats),
  };
}

function loadExample(id: string): void {
  if (id === "custom") return;
  if (id === "blank") {
    workspace = blankWorkspace();
    activeExampleId = "blank";
    evaluation = null;
    evaluationIsStale = false;
    refreshAll();
    saveSoon();
    showToast("Blank genus-one workspace loaded.");
    return;
  }
  const definition = getExampleDefinition(id);
  if (!definition) {
    showToast("That example is not available in this build.", "error");
    activeExampleId = "custom";
    syncTopControls();
    return;
  }
  workspace = {
    format: "kuperberg-taft-workspace",
    version: 1,
    level: definition.level,
    sourceExample: definition.id,
    diagram: normaliseDiagram(structuredCloneSafe(definition.diagram)),
    drawing: normaliseDrawing(definition.drawing ?? exampleDrawing(definition.id, definition.diagram)),
  };
  activeExampleId = definition.id;
  evaluation = null;
  evaluationIsStale = false;
  refreshAll();
  saveSoon();
  showToast(`${definition.label} loaded.`, "saved");
}

function getExampleDefinition(id: string): ExampleDefinition | undefined {
  const getter = firstFunction(exampleLibrary, ["getExample"]);
  let candidate: unknown;
  try {
    candidate = getter?.(id);
  } catch {
    candidate = undefined;
  }
  if (!candidate) {
    const list = Array.isArray(exampleLibrary.EXAMPLES) ? exampleLibrary.EXAMPLES : [];
    candidate = list.find((item) => asRecord(item)?.id === id);
  }
  const record = asRecord(candidate);
  if (!record || !record.diagram) return undefined;
  return {
    id: String(record.id ?? id),
    label: String(record.label ?? (id === "lens-l71" ? "Lens space L(7,1)" : "3-torus T³")),
    level: finiteInteger(Number(record.level), 3),
    diagram: normaliseDiagram(record.diagram),
    note: typeof record.note === "string" ? record.note : undefined,
    drawing: record.drawing ? normaliseDrawing(record.drawing) : drawingFromPreparedDiagram(record.diagram),
  };
}

function exampleOptions(): string {
  const configured = Array.isArray(exampleLibrary.EXAMPLES)
    ? exampleLibrary.EXAMPLES
        .map(asRecord)
        .filter((entry): entry is LooseRecord => Boolean(entry?.id))
        .map((entry) => ({ id: String(entry.id), label: String(entry.label ?? entry.id) }))
    : [];
  const options = configured.length
    ? configured
    : [
        { id: "lens-l71", label: "Lens space L(7,1)" },
        { id: "three-torus", label: "3-torus T³" },
      ];
  return [
    ...options.map(({ id, label }) => `<option value="${escapeAttr(id)}">${escapeText(label)}</option>`),
    `<option value="blank">Blank genus-one diagram</option>`,
    `<option value="custom">Current / imported workspace</option>`,
  ].join("");
}

function updateExampleNote(): void {
  const note = activeExampleId === "blank"
    ? "A clean genus-one input with one lower and one upper circle."
    : activeExampleId === "custom"
      ? "Your current locally saved workspace."
      : getExampleDefinition(activeExampleId)?.note ?? "A tested example with numbered data and expected output.";
  requiredElement("#example-note").textContent = note;
}

async function importWorkspace(file: File | undefined): Promise<void> {
  if (!file) return;
  try {
    if (file.size > INPUT_LIMITS.fileBytes) {
      throw new Error(`The import is ${(file.size / 1024 / 1024).toFixed(1)} MB; the limit is ${INPUT_LIMITS.fileBytes / 1024 / 1024} MB.`);
    }
    const text = await file.text();
    if (text.length > INPUT_LIMITS.fileBytes) {
      throw new Error(`The decoded JSON is too large; the limit is ${INPUT_LIMITS.fileBytes / 1024 / 1024} MB.`);
    }
    const raw = JSON.parse(text) as unknown;
    const record = asRecord(raw);
    if (!record) throw new Error("The file does not contain a JSON object.");
    const diagramSource = record.diagram ?? (record.schemaVersion === 1 ? record : undefined);
    if (!diagramSource) throw new Error("No prepared diagram was found in this file.");
    assertWorkspaceDataLimits(record, diagramSource);
    const importedDrawing = record.drawing === undefined
      ? drawingFromPreparedDiagram(diagramSource) ?? { curves: [] }
      : normaliseDrawing(record.drawing);
    workspace = {
      format: "kuperberg-taft-workspace",
      version: 1,
      level: finiteInteger(Number(record.level ?? record.ell), 3),
      sourceExample: "custom",
      diagram: normaliseDiagram(diagramSource),
      drawing: importedDrawing,
    };
    activeExampleId = "custom";
    evaluation = null;
    evaluationIsStale = false;
    refreshAll();
    saveImmediately();
    const errors = collectIssues().filter((issue) => issue.severity === "error").length;
    showToast(errors ? `Imported with ${errors} item${errors === 1 ? "" : "s"} to review.` : "Workspace imported successfully.", errors ? "error" : "saved");
  } catch (error) {
    showToast(`Could not import: ${errorMessage(error)}`, "error");
  }
}

function exportWorkspace(): void {
  const content = JSON.stringify({ ...workspace, sourceExample: activeExampleId }, null, 2);
  const blob = new Blob([content], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `${slugify(workspace.diagram.name || "kuperberg-diagram")}.kuperberg.json`;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  showToast("Workspace JSON exported.", "saved");
}

function clearWorkspace(): void {
  if (!window.confirm("Start a new blank workspace? Your current draft has been saved locally and can also be exported first.")) return;
  workspace = blankWorkspace();
  activeExampleId = "blank";
  evaluation = null;
  evaluationIsStale = false;
  refreshAll();
  saveImmediately();
  showToast("New blank workspace ready.");
}

function markChanged(options: { refreshDerived?: boolean; render?: boolean } = {}): void {
  evaluationIsStale = evaluation !== null;
  if (options.refreshDerived !== false) derived = tryDerive(workspace.diagram);
  const saveState = requiredElement("#save-state");
  saveState.classList.add("is-saving");
  saveState.querySelector("span:last-child")!.textContent = "Saving draft…";
  if (options.render !== false) refreshAll();
  else if (evaluation !== null) renderResult();
  saveSoon();
}

function saveSoon(): void {
  window.clearTimeout(saveTimer);
  saveTimer = window.setTimeout(saveImmediately, 450);
}

function saveImmediately(): void {
  try {
    workspace.sourceExample = activeExampleId;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(workspace));
    const saveState = document.querySelector<HTMLElement>("#save-state");
    if (saveState) {
      saveState.classList.remove("is-saving");
      const label = saveState.querySelector("span:last-child");
      if (label) label.textContent = "Saved locally";
    }
  } catch {
    const saveState = document.querySelector<HTMLElement>("#save-state span:last-child");
    if (saveState) saveState.textContent = "Local save unavailable";
  }
}

function loadInitialWorkspace(): WorkspaceFile {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      if (saved.length > INPUT_LIMITS.fileBytes) throw new Error("Saved workspace exceeds the local data limit.");
      const parsed = asRecord(JSON.parse(saved));
      if (parsed?.diagram) {
        assertWorkspaceDataLimits(parsed, parsed.diagram);
        return {
          format: "kuperberg-taft-workspace",
          version: 1,
          level: finiteInteger(Number(parsed.level), 3),
          sourceExample: typeof parsed.sourceExample === "string" ? parsed.sourceExample : "custom",
          diagram: normaliseDiagram(parsed.diagram),
          drawing: normaliseDrawing(parsed.drawing),
        };
      }
    }
  } catch {
    localStorage.removeItem(STORAGE_KEY);
  }
  const example = getExampleDefinition("lens-l71");
  if (example) {
    return {
      format: "kuperberg-taft-workspace",
      version: 1,
      level: example.level,
      sourceExample: example.id,
      diagram: normaliseDiagram(example.diagram),
      drawing: normaliseDrawing(example.drawing ?? exampleDrawing(example.id, example.diagram)),
    };
  }
  return blankWorkspace();
}

function blankWorkspace(): WorkspaceFile {
  const diagram: PreparedDiagram = {
    schemaVersion: 1,
    name: "Untitled combed diagram",
    genus: 1,
    basis: {
      labels: Array.from({ length: 4 }, (_, index) => defaultBasisLabel(index, 1)),
      combing: [0, 0, 0, 0],
    },
    circles: [
      { id: "L0", kind: "lower", R0: -1, B: [0, 0, 0, 0], order: [], labelsPrepared: false },
      { id: "U0", kind: "upper", R0: 1, B: [0, 0, 0, 0], order: [], labelsPrepared: false },
    ],
    crossings: [],
  };
  return {
    format: "kuperberg-taft-workspace",
    version: 1,
    level: 3,
    sourceExample: "blank",
    diagram,
    drawing: { curves: [] },
  };
}

function assertWorkspaceDataLimits(workspaceRecord: LooseRecord, diagramValue: unknown): void {
  const diagram = asRecord(diagramValue);
  if (!diagram) throw new Error("The prepared diagram must be a JSON object.");
  if (diagram.schemaVersion !== 1) throw new Error("diagram.schemaVersion must be exactly 1.");
  if (typeof diagram.name !== "string") throw new Error("diagram.name must be a string.");

  const levelValue = workspaceRecord.level !== undefined ? workspaceRecord.level : workspaceRecord.ell;
  assertOptionalInteger(levelValue, "level");
  assertOptionalInteger(diagram.genus, "diagram.genus", false);
  if (typeof diagram.genus === "number" && diagram.genus < 1) {
    throw new Error("diagram.genus must be at least 1.");
  }
  if (typeof diagram.genus === "number" && diagram.genus > INPUT_LIMITS.genus) {
    throw new Error(`diagram.genus is ${diagram.genus}; this browser supports genus at most ${INPUT_LIMITS.genus}.`);
  }

  const basis = asRecord(diagram.basis);
  if (!basis) throw new Error("diagram.basis must be an object.");
  if (!Array.isArray(basis.labels) || !basis.labels.every((label) => typeof label === "string")) {
    throw new Error("diagram.basis.labels must be an array of strings.");
  }
  if (basis.labels.length !== 4 * Number(diagram.genus)) {
    throw new Error(`diagram.basis.labels must contain exactly 4g = ${4 * Number(diagram.genus)} entries.`);
  }
  if (basis.labels.length > INPUT_LIMITS.basisEntries) {
    throw new Error(`diagram.basis.labels has ${basis.labels.length} entries; the limit is ${INPUT_LIMITS.basisEntries}.`);
  }
  if (!Array.isArray(basis.combing) || basis.combing.length !== 4 * Number(diagram.genus)) {
    throw new Error(`diagram.basis.combing must contain exactly 4g = ${4 * Number(diagram.genus)} integers.`);
  }
  assertIntegerArray(basis.combing, "diagram.basis.combing", INPUT_LIMITS.basisEntries);

  if (!Array.isArray(diagram.circles)) throw new Error("diagram.circles must be an array.");
  const circles = diagram.circles;
  if (circles.length > INPUT_LIMITS.circles) {
    throw new Error(`diagram.circles has ${circles.length} entries; the limit is ${INPUT_LIMITS.circles}.`);
  }
  let preparedDrawingPoints = 0;
  circles.forEach((item, index) => {
    const circle = asRecord(item);
    if (!circle) throw new Error(`diagram.circles[${index}] must be an object.`);
    if (typeof circle.id !== "string") throw new Error(`diagram.circles[${index}].id must be a string.`);
    if (circle.kind !== "lower" && circle.kind !== "upper") {
      throw new Error(`diagram.circles[${index}].kind must be "lower" or "upper".`);
    }
    assertOptionalInteger(circle.R0 ?? circle.r0, `diagram.circles[${index}].R0`);
    if (!Array.isArray(circle.B ?? circle.b)) throw new Error(`diagram.circles[${index}].B must be an integer array.`);
    assertIntegerArray(circle.B ?? circle.b, `diagram.circles[${index}].B`, INPUT_LIMITS.basisEntries);
    if (circle.labelsPrepared !== undefined && typeof circle.labelsPrepared !== "boolean") {
      throw new Error(`diagram.circles[${index}].labelsPrepared must be a boolean when supplied.`);
    }
    if (!Array.isArray(circle.order) || !circle.order.every((id) => typeof id === "string")) {
      throw new Error(`diagram.circles[${index}].order must be an array of crossing IDs.`);
    }
    if (circle.order.length > INPUT_LIMITS.orderEntriesPerCircle) {
      throw new Error(`diagram.circles[${index}].order has ${circle.order.length} entries; the limit is ${INPUT_LIMITS.orderEntriesPerCircle}.`);
    }
    if (circle.drawing !== undefined) {
      const drawing = asRecord(circle.drawing);
      if (!drawing) throw new Error(`diagram.circles[${index}].drawing must be an object when supplied.`);
      if (!Array.isArray(drawing.points)) throw new Error(`diagram.circles[${index}].drawing.points must be an array.`);
      const points = drawing.points;
      assertPointArray(points, `diagram.circles[${index}].drawing.points`, INPUT_LIMITS.drawingPointsPerCurve);
      preparedDrawingPoints += points.length;
    }
  });
  if (preparedDrawingPoints > INPUT_LIMITS.drawingPointsTotal) {
    throw new Error(`Prepared circle drawings contain ${preparedDrawingPoints} points in total; the limit is ${INPUT_LIMITS.drawingPointsTotal}.`);
  }

  if (!Array.isArray(diagram.crossings)) throw new Error("diagram.crossings must be an array.");
  const crossings = diagram.crossings;
  if (crossings.length > INPUT_LIMITS.crossings) {
    throw new Error(`diagram.crossings has ${crossings.length} entries; the limit is ${INPUT_LIMITS.crossings}.`);
  }
  crossings.forEach((item, index) => {
    const crossing = asRecord(item);
    if (!crossing) throw new Error(`diagram.crossings[${index}] must be an object.`);
    if (typeof crossing.id !== "string") throw new Error(`diagram.crossings[${index}].id must be a string.`);
    assertOptionalInteger(crossing.N0 ?? crossing.n0, `diagram.crossings[${index}].N0`);
    if (!Array.isArray(crossing.A ?? crossing.a)) throw new Error(`diagram.crossings[${index}].A must be an integer array.`);
    assertIntegerArray(crossing.A ?? crossing.a, `diagram.crossings[${index}].A`, INPUT_LIMITS.basisEntries);
    if (crossing.labelsPrepared !== undefined && typeof crossing.labelsPrepared !== "boolean") {
      throw new Error(`diagram.crossings[${index}].labelsPrepared must be a boolean when supplied.`);
    }
    const endpoints = asRecord(crossing.endpoints);
    if (!endpoints || typeof endpoints.lower !== "string" || typeof endpoints.upper !== "string") {
      throw new Error(`diagram.crossings[${index}].endpoints must contain string lower and upper IDs.`);
    }
    if (crossing.point !== undefined) {
      const point = asRecord(crossing.point);
      if (!point) throw new Error(`diagram.crossings[${index}].point must be an object when supplied.`);
      assertFiniteCoordinate(point.x, `diagram.crossings[${index}].point.x`);
      assertFiniteCoordinate(point.y, `diagram.crossings[${index}].point.y`);
    }
  });

  if (workspaceRecord.drawing !== undefined) {
    const drawing = asRecord(workspaceRecord.drawing);
    if (!drawing) throw new Error("drawing must be an object when supplied.");
    if (!Array.isArray(drawing.curves)) throw new Error("drawing.curves must be an array.");
    const curves = drawing.curves;
    if (curves.length > INPUT_LIMITS.drawingCurves) {
      throw new Error(`drawing.curves has ${curves.length} entries; the limit is ${INPUT_LIMITS.drawingCurves}.`);
    }
    let pointTotal = 0;
    curves.forEach((item, index) => {
      const curve = asRecord(item);
      if (!curve) throw new Error(`drawing.curves[${index}] must be an object.`);
      if (!Array.isArray(curve.points)) throw new Error(`drawing.curves[${index}].points must be an array.`);
      const points = curve.points;
      assertPointArray(points, `drawing.curves[${index}].points`, INPUT_LIMITS.drawingPointsPerCurve);
      pointTotal += points.length;
    });
    if (pointTotal > INPUT_LIMITS.drawingPointsTotal) {
      throw new Error(`drawing contains ${pointTotal} points in total; the limit is ${INPUT_LIMITS.drawingPointsTotal}.`);
    }
  }
}

function assertIntegerArray(value: unknown, path: string, limit: number): void {
  if (!Array.isArray(value)) return;
  if (value.length > limit) throw new Error(`${path} has ${value.length} entries; the limit is ${limit}.`);
  value.forEach((entry, index) => assertOptionalInteger(entry, `${path}[${index}]`, false));
}

function assertOptionalInteger(value: unknown, path: string, optional = true): void {
  if (optional && value === undefined) return;
  if (typeof value !== "number" || !Number.isSafeInteger(value)) {
    throw new Error(`${path} must be a safe integer; invalid numeric values are not changed to zero.`);
  }
}

function assertPointArray(points: unknown[], path: string, limit: number): void {
  if (points.length > limit) throw new Error(`${path} has ${points.length} points; the limit is ${limit}.`);
  points.forEach((item, index) => {
    const point = asRecord(item);
    if (!point) throw new Error(`${path}[${index}] must be a point object.`);
    assertFiniteCoordinate(point.x, `${path}[${index}].x`);
    assertFiniteCoordinate(point.y, `${path}[${index}].y`);
  });
}

function assertFiniteCoordinate(value: unknown, path: string): void {
  if (typeof value !== "number" || !Number.isFinite(value)) {
    throw new Error(`${path} must be a finite JSON number.`);
  }
}

function normaliseDiagram(value: unknown): PreparedDiagram {
  const record = asRecord(value) ?? {};
  const genus = Math.max(1, Math.min(12, finiteInteger(Number(record.genus), 1)));
  const basisRecord = asRecord(record.basis) ?? {};
  const rawLabels = Array.isArray(basisRecord.labels) ? basisRecord.labels : [];
  const rawCombing = Array.isArray(basisRecord.combing) ? basisRecord.combing : [];
  const circles = Array.isArray(record.circles) ? record.circles.map(normaliseCircle) : [];
  const crossings = Array.isArray(record.crossings) ? record.crossings.map(normaliseCrossing) : [];
  return {
    schemaVersion: 1,
    name: String(record.name ?? "Untitled combed diagram"),
    genus,
    basis: {
      labels: Array.from({ length: 4 * genus }, (_, index) => String(rawLabels[index] ?? defaultBasisLabel(index, genus))),
      combing: Array.from(
        { length: 4 * genus },
        (_, index) => importedInteger(rawCombing[index], Number.NaN),
      ),
    },
    circles,
    crossings,
  };
}

function normaliseCircle(value: unknown, index: number): PreparedCircle {
  const record = asRecord(value) ?? {};
  return {
    id: String(record.id ?? `C${index}`),
    kind: record.kind === "upper" ? "upper" : "lower",
    R0: importedInteger(record.R0 ?? record.r0, Number.NaN),
    B: toNumberArray(record.B ?? record.b),
    order: toStringArray(record.order),
    ...(record.labelsPrepared === false ? { labelsPrepared: false } : {}),
  };
}

function normaliseCrossing(value: unknown, index: number): PreparedCrossing {
  const record = asRecord(value) ?? {};
  const endpoints = asRecord(record.endpoints) ?? {};
  const point = asRecord(record.point);
  return {
    id: String(record.id ?? `x${index}`),
    N0: importedInteger(record.N0 ?? record.n0, Number.NaN),
    A: toNumberArray(record.A ?? record.a),
    endpoints: { lower: String(endpoints.lower ?? ""), upper: String(endpoints.upper ?? "") },
    ...(record.labelsPrepared === false ? { labelsPrepared: false } : {}),
    ...(point ? { point: { x: finiteNumber(Number(point.x), 0), y: finiteNumber(Number(point.y), 0) } } : {}),
  };
}

function normaliseDrawing(value: unknown): SketchData {
  const record = asRecord(value);
  if (!record || !Array.isArray(record.curves)) return { curves: [] };
  return {
    curves: record.curves.map((item, index) => {
      const curve = asRecord(item) ?? {};
      const points = Array.isArray(curve.points)
        ? curve.points.map((rawPoint) => {
            const point = asRecord(rawPoint) ?? {};
            return { x: finiteNumber(Number(point.x), 0), y: finiteNumber(Number(point.y), 0) };
          })
        : [];
      return {
        id: String(curve.id ?? `${curve.family === "upper" ? "U" : "L"}${index}`),
        name: String(curve.name ?? curve.id ?? `curve ${index + 1}`),
        family: curve.family === "upper" ? "upper" : "lower",
        points,
        closed: Boolean(curve.closed),
        basepointIndex: Math.max(0, Math.min(points.length - 1, finiteInteger(Number(curve.basepointIndex), 0))),
      } satisfies SketchCurve;
    }),
  };
}

function exampleDrawing(id: string, diagram: PreparedDiagram): SketchData {
  if (id === "three-torus") {
    const lower = diagram.circles.filter((circle) => circle.kind === "lower");
    const upper = diagram.circles.filter((circle) => circle.kind === "upper");
    const centres = [[225, 260], [450, 280], [675, 260]];
    return {
      curves: [
        ...lower.slice(0, 3).map((circle, index) => ellipseCurve(circle.id, "lower", centres[index]?.[0] ?? 220 + 220 * index, centres[index]?.[1] ?? 280, 120, 70, 0)),
        ...upper.slice(0, 3).map((circle, index) => ellipseCurve(circle.id, "upper", centres[index]?.[0] ?? 220 + 220 * index, centres[index]?.[1] ?? 280, 80, 132, 0.35)),
      ],
    };
  }
  const lowerId = diagram.circles.find((circle) => circle.kind === "lower")?.id ?? "L0";
  const upperId = diagram.circles.find((circle) => circle.kind === "upper")?.id ?? "U0";
  const lower = ellipseCurve(lowerId, "lower", 450, 280, 285, 174, 0);
  const upperPoints = Array.from({ length: 84 }, (_, index) => {
    const t = (index / 84) * Math.PI * 2;
    const pulse = 1 + 0.16 * Math.sin(7 * t + 0.35);
    return { x: 450 + 275 * pulse * Math.cos(t + 0.16), y: 280 + 168 * pulse * Math.sin(t + 0.16) };
  });
  return {
    curves: [lower, { id: upperId, name: upperId, family: "upper", points: upperPoints, closed: true, basepointIndex: 0 }],
  };
}

function drawingFromPreparedDiagram(value: unknown): SketchData | undefined {
  const record = asRecord(value);
  if (!record || !Array.isArray(record.circles)) return undefined;
  const curves = record.circles.flatMap((item, index) => {
    const circle = asRecord(item);
    const drawing = asRecord(circle?.drawing);
    if (!circle || !drawing || !Array.isArray(drawing.points)) return [];
    const points = drawing.points.flatMap((itemPoint) => {
      const point = asRecord(itemPoint);
      if (!point || !Number.isFinite(Number(point.x)) || !Number.isFinite(Number(point.y))) return [];
      return [{ x: Number(point.x) * 9, y: Number(point.y) * 5.6 }];
    });
    if (points.length < 2) return [];
    const id = String(circle.id ?? `${circle.kind === "upper" ? "U" : "L"}${index}`);
    return [{
      id,
      name: id,
      family: circle.kind === "upper" ? "upper" as const : "lower" as const,
      points,
      closed: Boolean(drawing.closed),
      basepointIndex: 0,
    }];
  });
  return curves.length ? { curves } : undefined;
}

function ellipseCurve(id: string, family: CircleKind, cx: number, cy: number, rx: number, ry: number, rotation: number): SketchCurve {
  const points = Array.from({ length: 42 }, (_, index) => {
    const t = (index / 42) * Math.PI * 2;
    const x = rx * Math.cos(t);
    const y = ry * Math.sin(t);
    return {
      x: cx + x * Math.cos(rotation) - y * Math.sin(rotation),
      y: cy + x * Math.sin(rotation) + y * Math.cos(rotation),
    };
  });
  return { id, name: id, family, points, closed: true, basepointIndex: 0 };
}

function trustedPins(): TrustedCrossingPin[] {
  const circleMap = new Map(workspace.diagram.circles.map((circle) => [circle.id, circle]));
  return workspace.diagram.crossings.map((crossing) => ({
    id: crossing.id,
    lowerCurveId: crossing.endpoints.lower,
    upperCurveId: crossing.endpoints.upper,
    lowerEndpoint: circleMap.get(crossing.endpoints.lower)?.order.indexOf(crossing.id) ?? -1,
    upperEndpoint: circleMap.get(crossing.endpoints.upper)?.order.indexOf(crossing.id) ?? -1,
    ...(crossing.point ? { point: { x: crossing.point.x * 9, y: crossing.point.y * 5.6 } } : {}),
  }));
}

function newCircle(kind: CircleKind): PreparedCircle {
  const prefix = kind === "lower" ? "L" : "U";
  return {
    id: nextId(prefix, new Set(workspace.diagram.circles.map((circle) => circle.id))),
    kind,
    R0: kind === "lower" ? -1 : 1,
    B: Array(4 * workspace.diagram.genus).fill(0),
    order: [],
    labelsPrepared: false,
  };
}

function remapCoordinateData(previousGenus: number, nextGenus: number): void {
  if (previousGenus === nextGenus) return;
  const oldKeys = canonicalBasisKeys(previousGenus);
  const oldIndex = new Map(oldKeys.map((key, index) => [key, index]));
  const newKeys = canonicalBasisKeys(nextGenus);
  const remap = <T>(values: T[], fallback: (index: number) => T): T[] =>
    newKeys.map((key, index) => {
      const sourceIndex = oldIndex.get(key);
      return sourceIndex === undefined || values[sourceIndex] === undefined
        ? fallback(index)
        : values[sourceIndex]!;
    });

  workspace.diagram.basis.labels = remap(workspace.diagram.basis.labels, (index) => defaultBasisLabel(index, nextGenus));
  workspace.diagram.basis.combing = remap(workspace.diagram.basis.combing, () => 0);
  workspace.diagram.circles.forEach((circle) => { circle.B = remap(circle.B, () => 0); });
  workspace.diagram.crossings.forEach((crossing) => { crossing.A = remap(crossing.A, () => 0); });
}

function defaultBasisLabel(index: number, genus: number): string {
  if (index < 2 * genus) {
    const handle = Math.floor(index / 2) + 1;
    return `${index % 2 === 0 ? "x" : "y"}${subscript(handle)}`;
  }
  if (index < 3 * genus) return `ν${subscript(index - 2 * genus + 1)}`;
  if (index < 4 * genus) return `μ${subscript(index - 3 * genus + 1)}`;
  return `c${index + 1}`;
}

function canonicalBasisKeys(genus: number): string[] {
  return [
    ...Array.from({ length: genus }, (_, index) => [`x${index + 1}`, `y${index + 1}`]).flat(),
    ...Array.from({ length: genus }, (_, index) => `nu${index + 1}`),
    ...Array.from({ length: genus }, (_, index) => `mu${index + 1}`),
  ];
}

function positionAfterSketchBasepoint(suggestion: VisualIntersection, circle: PreparedCircle): number {
  const raw = circle.kind === "lower" ? suggestion.lowerPosition : suggestion.upperPosition;
  const curve = workspace.drawing.curves.find((item) => item.id === circle.id && item.family === circle.kind);
  if (!curve || curve.points.length < 2) return raw;
  const segmentCount = curve.closed ? curve.points.length : curve.points.length - 1;
  if (segmentCount <= 0) return raw;
  const baseSegment = Math.max(0, Math.min(segmentCount - 1, curve.basepointIndex));
  return ((raw - baseSegment) % segmentCount + segmentCount) % segmentCount;
}

function circleOptions(circles: PreparedCircle[], selected: string): string {
  if (!circles.length) return `<option value="">No ${selected ? "matching" : "available"} circle</option>`;
  return circles.map((circle) => `<option value="${escapeAttr(circle.id)}" ${circle.id === selected ? "selected" : ""}>${escapeText(circle.id)}</option>`).join("");
}

function updateExampleSelection(): void {
  const select = document.querySelector<HTMLSelectElement>("#example-select");
  if (select) select.value = activeExampleId;
}

function syncComputingButton(): void {
  const button = requiredElement<HTMLButtonElement>(".compute-button");
  button.disabled = isComputing;
  button.classList.toggle("is-loading", isComputing);
  button.querySelector(".button-label")!.textContent = isComputing ? "Computing…" : "Compute invariant";
}

function toggleFileMenu(button: HTMLButtonElement): void {
  const menu = requiredElement<HTMLElement>("#file-menu");
  const opening = menu.hidden;
  menu.hidden = !opening;
  button.setAttribute("aria-expanded", String(opening));
  if (opening) {
    const close = (event: MouseEvent): void => {
      if (!(event.target as HTMLElement).closest(".control-deck")) closeFileMenu();
    };
    window.setTimeout(() => document.addEventListener("click", close, { once: true }), 0);
  }
}

function closeFileMenu(): void {
  requiredElement<HTMLElement>("#file-menu").hidden = true;
  requiredElement<HTMLButtonElement>(".more-button").setAttribute("aria-expanded", "false");
}

function showToast(message: string, type: "default" | "error" | "saved" = "default"): void {
  const toast = requiredElement("#toast");
  toast.textContent = message;
  toast.className = `toast is-visible toast--${type}`;
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 4200);
}

async function copyText(value: string, button: HTMLElement): Promise<void> {
  try {
    await navigator.clipboard.writeText(value);
    const previous = button.innerHTML;
    button.innerHTML = `${iconCheck()} Copied`;
    window.setTimeout(() => (button.innerHTML = previous), 1600);
  } catch {
    showToast("Copy was blocked by the browser. Select the exact value manually.", "error");
  }
}

function firstFunction(record: LooseRecord, names: string[]): ((...args: any[]) => any) | undefined {
  for (const name of names) {
    if (typeof record[name] === "function") return record[name] as (...args: any[]) => any;
  }
  return undefined;
}

function asRecord(value: unknown): LooseRecord | undefined {
  return value !== null && typeof value === "object" ? (value as LooseRecord) : undefined;
}

function toNumberArray(value: unknown): number[] {
  if (!Array.isArray(value)) return value == null ? [] : [importedInteger(value, Number.NaN)];
  return value.map((item) => importedInteger(item, Number.NaN));
}

function toStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return typeof value === "string" ? parseIdList(value) : [];
  return value.map(String);
}

function parseNumberList(value: string): number[] {
  const trimmed = value.trim();
  if (!trimmed) return [];
  return trimmed.split(/[\s,;]+/).filter(Boolean).map((item) => parseIntegerInput(item.replace("−", "-")));
}

function parseIntegerInput(value: string): number {
  if (!value.trim()) return Number.NaN;
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) ? parsed : Number.NaN;
}

function importedInteger(value: unknown, fallback: number): number {
  if (value === undefined) return fallback;
  return typeof value === "number" && Number.isSafeInteger(value) ? value : Number.NaN;
}

function parseIdList(value: string): string[] {
  return value.split(/[\s,;]+/).map((item) => item.trim()).filter(Boolean);
}

function formatIntegerList(values: number[]): string {
  return values.join(", ");
}

function duplicateValues(values: string[]): string[] {
  const seen = new Set<string>();
  const duplicates = new Set<string>();
  values.forEach((value) => (seen.has(value) ? duplicates.add(value) : seen.add(value)));
  return [...duplicates];
}

function deduplicateIssues(issues: UiIssue[]): UiIssue[] {
  const seen = new Set<string>();
  return issues.filter((issue) => {
    const key = `${issue.severity}:${issue.path ?? ""}:${issue.message}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function formatDerived(value: unknown): string {
  if (value === undefined || value === null || (typeof value === "number" && !Number.isFinite(value))) {
    return `<span class="not-derived" title="Complete the row to derive this label">—</span>`;
  }
  if (Array.isArray(value)) return escapeText(value.join(", "));
  if (typeof value === "object") return escapeText(readableValue(value));
  return escapeText(String(value));
}

function readableValue(value: unknown): string {
  if (value == null) return "";
  if (typeof value === "string" || typeof value === "number" || typeof value === "bigint") return String(value);
  try {
    return JSON.stringify(value, (_, item) => (typeof item === "bigint" ? item.toString() : item));
  } catch {
    return String(value);
  }
}

function readableApproximation(value: unknown): string {
  if (value == null) return "";
  if (typeof value === "string" || typeof value === "number") return String(value);
  const record = asRecord(value);
  if (record) {
    const re = record.re ?? record.real;
    const im = record.im ?? record.imaginary;
    if (typeof re === "number" && typeof im === "number") return `${formatDecimal(re)} ${im < 0 ? "−" : "+"} ${formatDecimal(Math.abs(im))}i`;
  }
  return readableValue(value);
}

function statsEntries(value: unknown): Array<[string, string]> {
  const record = asRecord(value);
  if (!record) return [];
  return Object.entries(record).map(([key, item]) => [humaniseKey(key), readableValue(item)]);
}

function extractStringDetails(value: unknown): string[] {
  if (!Array.isArray(value)) return value == null ? [] : [typeof value === "string" ? value : readableValue(value)];
  return value.map((item) => {
    if (typeof item === "string") return item;
    const record = asRecord(item);
    return String(record?.message ?? record?.reason ?? readableValue(item));
  });
}

function humaniseKey(value: string): string {
  const spaced = value.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/[_-]/g, " ");
  return capitalise(spaced);
}

function capitalise(value: string): string {
  return value ? value[0].toUpperCase() + value.slice(1) : value;
}

function finiteNumber(value: number, fallback: number): number {
  return Number.isFinite(value) ? value : fallback;
}

function finiteInteger(value: number, fallback: number): number {
  return Number.isFinite(value) ? Math.trunc(value) : fallback;
}

function formatDecimal(value: number): string {
  return Math.abs(value) < 1e-12 ? "0" : Number(value.toPrecision(10)).toString();
}

function nextId(prefix: string, existing: Set<string>): string {
  if (!existing.has(prefix)) return prefix;
  const plainPrefix = prefix.replace(/\d+$/, "") || prefix;
  let index = 0;
  while (existing.has(`${plainPrefix}${index}`)) index += 1;
  return `${plainPrefix}${index}`;
}

function sanitiseId(value: string, fallback: string): string {
  return value.trim().replace(/\s+/g, "-").replace(/[^\p{L}\p{N}_.:-]/gu, "") || fallback;
}

function slugify(value: string): string {
  return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "kuperberg-diagram";
}

function subscript(value: number): string {
  const digits = "₀₁₂₃₄₅₆₇₈₉";
  return String(value).split("").map((digit) => digits[Number(digit)]).join("");
}

function structuredCloneSafe<T>(value: T): T {
  if (typeof structuredClone === "function") return structuredClone(value);
  return JSON.parse(JSON.stringify(value)) as T;
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

function nextPaint(): Promise<void> {
  return new Promise((resolve) => requestAnimationFrame(() => resolve()));
}

function requiredElement<T extends HTMLElement = HTMLElement>(selector: string): T {
  const element = document.querySelector<T>(selector);
  if (!element) throw new Error(`Required interface element not found: ${selector}`);
  return element;
}

function escapeText(value: string): string {
  return value.replace(/[&<>]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[character]!);
}

function escapeAttr(value: string): string {
  return escapeText(value).replace(/["']/g, (character) => (character === '"' ? "&quot;" : "&#39;"));
}

function iconArrow(): string { return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14m-5-5 5 5-5 5"/></svg>`; }
function iconDots(): string { return `<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/></svg>`; }
function iconTrash(): string { return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 7h15M9 7V4.5h6V7m2.5 0-.7 12H7.2L6.5 7m4 3v6m3-6v6"/></svg>`; }
function iconUpload(): string { return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 15V3m-4 4 4-4 4 4M5 13v7h14v-7"/></svg>`; }
function iconDownload(): string { return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v12m-4-4 4 4 4-4M5 14v6h14v-6"/></svg>`; }
function iconReset(): string { return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 7v5h5M6.5 11a7 7 0 1 1 .6 6.5"/></svg>`; }
function iconShield(): string { return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 5 6v5c0 4.6 2.5 7.8 7 10 4.5-2.2 7-5.4 7-10V6l-7-3Z"/><path d="m9 12 2 2 4-4"/></svg>`; }
function iconEye(): string { return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12s3.4-6 9-6 9 6 9 6-3.4 6-9 6-9-6-9-6Z"/><circle cx="12" cy="12" r="2.5"/></svg>`; }
function iconAlert(): string { return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 2.8 20h18.4L12 3Z"/><path d="M12 9v5m0 3h.01"/></svg>`; }
function iconInfo(): string { return `<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/></svg>`; }
function iconCalculator(): string { return `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8v3H8zm0 7h2m2 0h2m2 0h.01M8 17h2m2 0h2m2 0h.01"/></svg>`; }
function iconCheck(): string { return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4.5 4.5L19 7"/></svg>`; }
function iconCopy(): string { return `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="8" y="8" width="11" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h1"/></svg>`; }
