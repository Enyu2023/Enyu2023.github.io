export type CurveFamily = "lower" | "upper";

export interface SketchPoint {
  x: number;
  y: number;
}

export interface SketchCurve {
  id: string;
  name: string;
  family: CurveFamily;
  points: SketchPoint[];
  closed: boolean;
  basepointIndex: number;
}

export interface SketchData {
  curves: SketchCurve[];
}

export interface VisualIntersection {
  key: string;
  lowerCurveId: string;
  upperCurveId: string;
  point: SketchPoint;
  lowerPosition: number;
  upperPosition: number;
}

export interface TrustedCrossingPin {
  id: string;
  lowerCurveId: string;
  upperCurveId: string;
  lowerEndpoint: number;
  upperEndpoint: number;
  point?: SketchPoint;
}

interface Selection {
  curveId?: string;
  vertexIndex?: number;
  suggestionKey?: string;
}

interface DiagramEditorOptions {
  onChange: (drawing: SketchData) => void;
  onUseSuggestions: (suggestions: VisualIntersection[]) => void;
  onStatus?: (message: string) => void;
}

type ToolMode = "select" | "draw-lower" | "draw-upper" | "basepoint";

const WIDTH = 900;
const HEIGHT = 560;
export const DIAGRAM_EDITOR_LIMITS = {
  curves: 48,
  pointsPerCurve: 256,
  pointsTotal: 4096,
  segmentComparisons: 100_000,
  intersections: 1_000,
} as const;

export class DiagramEditor {
  private readonly root: HTMLElement;
  private readonly options: DiagramEditorOptions;
  private drawing: SketchData = { curves: [] };
  private trustedCrossings: TrustedCrossingPin[] = [];
  private knownCircleIds = new Set<string>();
  private selection: Selection = {};
  private mode: ToolMode = "select";
  private activeDraftId: string | null = null;
  private dragging: { curveId: string; vertexIndex: number; pointerId: number } | null = null;
  private suggestions: VisualIntersection[] = [];
  private intersectionLimitReached = false;

  constructor(root: HTMLElement, options: DiagramEditorOptions) {
    this.root = root;
    this.options = options;
    this.mount();
  }

  setData(
    drawing: SketchData | undefined,
    knownCircleIds: Iterable<string>,
    trustedCrossings: TrustedCrossingPin[] = [],
  ): void {
    const limitMessage = drawingLimitMessage(drawing);
    this.drawing = normaliseDrawing(drawing);
    this.knownCircleIds = new Set(knownCircleIds);
    this.trustedCrossings = trustedCrossings;
    if (this.selection.curveId && !this.findCurve(this.selection.curveId)) {
      this.selection = {};
    }
    this.refresh();
    if (limitMessage) this.options.onStatus?.(limitMessage);
  }

  focusCurve(curveId: string): void {
    const curve = this.findCurve(curveId);
    if (!curve) return;
    this.selection = { curveId };
    this.mode = "select";
    this.refresh();
    this.root.querySelector<SVGElement>(`[data-curve-id="${cssEscape(curveId)}"]`)?.focus();
  }

  private mount(): void {
    this.root.innerHTML = `
      <div class="sketch-toolbar" role="toolbar" aria-label="Diagram drawing tools">
        <div class="tool-cluster" aria-label="Drawing mode">
          ${toolButton("select", "Pointer", "Select and move points", iconPointer())}
          ${toolButton("draw-lower", "Lower", "Draw a lower circle", iconCurve("lower"))}
          ${toolButton("draw-upper", "Upper", "Draw an upper circle", iconCurve("upper"))}
          ${toolButton("basepoint", "Basepoint", "Put the basepoint on a vertex", iconBasepoint())}
        </div>
        <div class="tool-cluster tool-cluster--actions">
          <button class="small-button finish-drawing" type="button" hidden>Finish curve</button>
          <button class="icon-button delete-drawing" type="button" title="Delete selected curve or point" aria-label="Delete selected curve or point" disabled>${iconTrash()}</button>
          <button class="small-button use-suggestions" type="button" disabled>Use intersection suggestions</button>
        </div>
      </div>
      <div class="sketch-layout">
        <div class="canvas-wrap">
          <svg class="diagram-canvas" viewBox="0 0 ${WIDTH} ${HEIGHT}" role="img" aria-labelledby="canvas-title canvas-description" tabindex="0">
            <title id="canvas-title">Heegaard diagram sketch</title>
            <desc id="canvas-description">Draw lower circles in green and upper circles in violet. Orange points are visual intersection suggestions.</desc>
            <defs>
              <pattern id="minor-grid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 20 0 L 0 0 0 20" fill="none" stroke="currentColor" stroke-width="0.7" />
              </pattern>
              <pattern id="major-grid" width="100" height="100" patternUnits="userSpaceOnUse">
                <rect width="100" height="100" fill="url(#minor-grid)" />
                <path d="M 100 0 L 0 0 0 100" fill="none" stroke="currentColor" stroke-width="1" />
              </pattern>
              <filter id="curve-shadow" x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="2" stdDeviation="2" flood-opacity=".16" />
              </filter>
            </defs>
            <rect class="canvas-background" width="${WIDTH}" height="${HEIGHT}" rx="18" />
            <rect class="canvas-grid" width="${WIDTH}" height="${HEIGHT}" rx="18" fill="url(#major-grid)" />
            <g class="canvas-content"></g>
          </svg>
          <div class="canvas-legend" aria-hidden="true">
            <span><i class="legend-line legend-line--lower"></i>Lower</span>
            <span><i class="legend-line legend-line--upper"></i>Upper</span>
            <span><i class="legend-crossing"></i>Suggested intersection</span>
          </div>
        </div>
        <aside class="selection-inspector" aria-live="polite"></aside>
      </div>
      <div class="suggestion-note" role="note">
        ${iconSparkle()}
        <span><strong>The sketch is a visual aid.</strong> Orange intersections are geometric suggestions. Only the numbered circle and crossing tables are used in the computation.</span>
      </div>
    `;

    this.root.addEventListener("click", this.handleClick);
    this.root.addEventListener("input", this.handleInspectorInput);
    this.root.addEventListener("change", this.handleInspectorInput);

    const svg = this.svg;
    svg.addEventListener("pointerdown", this.handlePointerDown);
    svg.addEventListener("pointermove", this.handlePointerMove);
    svg.addEventListener("pointerup", this.handlePointerUp);
    svg.addEventListener("pointercancel", this.handlePointerUp);
    svg.addEventListener("dblclick", this.handleDoubleClick);
    svg.addEventListener("keydown", this.handleKeyDown);
    this.refresh();
  }

  private get svg(): SVGSVGElement {
    return this.root.querySelector<SVGSVGElement>(".diagram-canvas")!;
  }

  private handleClick = (event: Event): void => {
    const target = event.target as HTMLElement;
    const tool = target.closest<HTMLButtonElement>("[data-tool]")?.dataset.tool as ToolMode | undefined;
    if (tool) {
      this.setMode(tool);
      return;
    }
    if (target.closest(".finish-drawing")) {
      this.finishDraft();
      return;
    }
    if (target.closest(".delete-drawing")) {
      this.deleteSelection();
      return;
    }
    if (target.closest(".use-suggestions")) {
      this.options.onUseSuggestions(this.suggestions.map(copySuggestion));
      return;
    }
    if (target.closest(".toggle-curve-closed")) {
      const curve = this.selectedCurve();
      if (curve) {
        curve.closed = !curve.closed;
        this.commit("Curve closure updated.");
      }
      return;
    }
    if (target.closest(".delete-inspector-selection")) {
      this.deleteSelection();
    }
  };

  private handlePointerDown = (event: PointerEvent): void => {
    const target = event.target as SVGElement;
    const vertex = target.closest<SVGElement>("[data-vertex-index]");
    const curveElement = target.closest<SVGElement>("[data-curve-id]");
    const suggestionElement = target.closest<SVGElement>("[data-suggestion-key]");

    if (suggestionElement?.dataset.suggestionKey) {
      this.selection = { suggestionKey: suggestionElement.dataset.suggestionKey };
      this.refresh();
      return;
    }

    if (this.mode === "draw-lower" || this.mode === "draw-upper") {
      if (target.closest(".canvas-content") || target.classList.contains("canvas-background") || target.classList.contains("canvas-grid")) {
        this.addDraftPoint(this.eventPoint(event), this.mode === "draw-lower" ? "lower" : "upper");
      }
      return;
    }

    if (vertex?.dataset.curveId && vertex.dataset.vertexIndex !== undefined) {
      const curveId = vertex.dataset.curveId;
      const vertexIndex = Number(vertex.dataset.vertexIndex);
      this.selection = { curveId, vertexIndex };
      if (this.mode === "basepoint") {
        const curve = this.findCurve(curveId);
        if (curve) {
          curve.basepointIndex = vertexIndex;
          this.commit(`Basepoint set on ${curve.name}.`);
        }
        return;
      }
      this.dragging = { curveId, vertexIndex, pointerId: event.pointerId };
      this.svg.setPointerCapture(event.pointerId);
      this.refresh();
      return;
    }

    if (curveElement?.dataset.curveId) {
      this.selection = { curveId: curveElement.dataset.curveId };
      this.refresh();
      return;
    }

    if (target.classList.contains("canvas-background") || target.classList.contains("canvas-grid")) {
      this.selection = {};
      this.refresh();
    }
  };

  private handlePointerMove = (event: PointerEvent): void => {
    if (!this.dragging || event.pointerId !== this.dragging.pointerId) return;
    const curve = this.findCurve(this.dragging.curveId);
    if (!curve) return;
    curve.points[this.dragging.vertexIndex] = this.eventPoint(event);
    this.renderCanvas();
    this.renderInspector();
  };

  private handlePointerUp = (event: PointerEvent): void => {
    if (!this.dragging || event.pointerId !== this.dragging.pointerId) return;
    this.dragging = null;
    if (this.svg.hasPointerCapture(event.pointerId)) this.svg.releasePointerCapture(event.pointerId);
    this.commit("Point moved.");
  };

  private handleDoubleClick = (event: MouseEvent): void => {
    if (this.mode === "draw-lower" || this.mode === "draw-upper") {
      event.preventDefault();
      this.finishDraft();
    }
  };

  private handleKeyDown = (event: KeyboardEvent): void => {
    if (event.key === "Escape") {
      this.finishDraft();
    } else if (event.key === "Delete" || event.key === "Backspace") {
      event.preventDefault();
      this.deleteSelection();
    }
  };

  private handleInspectorInput = (event: Event): void => {
    const input = event.target as HTMLInputElement | HTMLSelectElement;
    const curve = this.selectedCurve();
    if (!curve) return;
    if (input.matches("[data-sketch-field='name']")) {
      curve.name = input.value.trimStart().slice(0, 40) || curve.id;
      this.commit("Curve label updated.", false);
    } else if (input.matches("[data-sketch-field='family']")) {
      curve.family = input.value === "upper" ? "upper" : "lower";
      this.commit("Curve family updated.");
    } else if (input.matches("[data-sketch-field='x'], [data-sketch-field='y']")) {
      const index = this.selection.vertexIndex;
      if (index === undefined || !curve.points[index]) return;
      const value = clamp(Number(input.value), 0, input.dataset.sketchField === "x" ? WIDTH : HEIGHT);
      curve.points[index][input.dataset.sketchField as "x" | "y"] = round(value, 1);
      this.commit("Point coordinates updated.", false);
    }
  };

  private setMode(mode: ToolMode): void {
    if ((this.mode === "draw-lower" || this.mode === "draw-upper") && mode !== this.mode) {
      this.finishDraft(false);
    }
    this.mode = mode;
    if (mode === "draw-lower" || mode === "draw-upper") {
      this.selection = {};
      this.options.onStatus?.(`Click to place ${mode === "draw-lower" ? "lower" : "upper"} curve points. Double-click or press Escape to finish.`);
    }
    this.refresh();
    this.svg.focus();
  }

  private addDraftPoint(point: SketchPoint, family: CurveFamily): void {
    let curve = this.activeDraftId ? this.findCurve(this.activeDraftId) : undefined;
    if (!curve || curve.family !== family) {
      if (this.drawing.curves.length >= DIAGRAM_EDITOR_LIMITS.curves) {
        this.options.onStatus?.(`The drawing is limited to ${DIAGRAM_EDITOR_LIMITS.curves} curves. Delete a curve before adding another.`);
        return;
      }
      const id = this.nextCurveId(family);
      curve = {
        id,
        name: id,
        family,
        points: [],
        closed: false,
        basepointIndex: 0,
      };
      this.drawing.curves.push(curve);
      this.activeDraftId = id;
    }
    const previous = curve.points.at(-1);
    if (!previous || distance(previous, point) > 3) {
      const pointTotal = this.drawing.curves.reduce((total, item) => total + item.points.length, 0);
      if (curve.points.length >= DIAGRAM_EDITOR_LIMITS.pointsPerCurve) {
        this.options.onStatus?.(`This curve already has the maximum ${DIAGRAM_EDITOR_LIMITS.pointsPerCurve} points. Finish it or remove points.`);
        return;
      }
      if (pointTotal >= DIAGRAM_EDITOR_LIMITS.pointsTotal) {
        this.options.onStatus?.(`The drawing is limited to ${DIAGRAM_EDITOR_LIMITS.pointsTotal} points in total.`);
        return;
      }
      curve.points.push(point);
    }
    this.selection = { curveId: curve.id, vertexIndex: curve.points.length - 1 };
    this.renderCanvas();
    this.renderInspector();
    this.renderToolbarState();
  }

  private finishDraft(commit = true): void {
    if (!this.activeDraftId) {
      if (this.mode === "draw-lower" || this.mode === "draw-upper") this.mode = "select";
      this.refresh();
      return;
    }
    const curve = this.findCurve(this.activeDraftId);
    if (curve) {
      if (curve.points.length >= 3) curve.closed = true;
      if (curve.points.length < 2) {
        this.drawing.curves = this.drawing.curves.filter((item) => item.id !== curve.id);
        this.selection = {};
      } else {
        this.selection = { curveId: curve.id };
      }
    }
    this.activeDraftId = null;
    this.mode = "select";
    if (commit) this.commit("Curve finished.");
    else this.refresh();
  }

  private deleteSelection(): void {
    const curve = this.selectedCurve();
    if (!curve) return;
    const vertexIndex = this.selection.vertexIndex;
    if (vertexIndex !== undefined && curve.points.length > 2) {
      curve.points.splice(vertexIndex, 1);
      curve.basepointIndex = clamp(curve.basepointIndex, 0, curve.points.length - 1);
      this.selection = { curveId: curve.id };
      this.commit("Point deleted.");
      return;
    }
    this.drawing.curves = this.drawing.curves.filter((item) => item.id !== curve.id);
    if (this.activeDraftId === curve.id) this.activeDraftId = null;
    this.selection = {};
    this.commit("Sketch curve deleted.");
  }

  private commit(message: string, fullRefresh = true): void {
    this.options.onChange(normaliseDrawing(this.drawing));
    this.options.onStatus?.(message);
    if (fullRefresh) this.refresh();
    else {
      this.renderCanvas();
      this.renderInspector();
    }
  }

  private refresh(): void {
    const previousLimitState = this.intersectionLimitReached;
    const search = scanVisualIntersections(this.drawing.curves);
    this.suggestions = search.intersections;
    this.intersectionLimitReached = search.limited;
    this.renderToolbarState();
    this.renderCanvas();
    this.renderInspector();
    if (search.limited && !previousLimitState) {
      this.options.onStatus?.(
        `Intersection scan stopped at its safety limit (${DIAGRAM_EDITOR_LIMITS.segmentComparisons.toLocaleString()} segment comparisons or ${DIAGRAM_EDITOR_LIMITS.intersections.toLocaleString()} suggestions). Simplify the sketch to see every intersection.`,
      );
    }
  }

  private renderToolbarState(): void {
    this.root.querySelectorAll<HTMLButtonElement>("[data-tool]").forEach((button) => {
      const active = button.dataset.tool === this.mode;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-pressed", String(active));
    });
    const finish = this.root.querySelector<HTMLButtonElement>(".finish-drawing")!;
    finish.hidden = !this.activeDraftId;
    const deleteButton = this.root.querySelector<HTMLButtonElement>(".delete-drawing")!;
    deleteButton.disabled = !this.selection.curveId;
    const suggestionsButton = this.root.querySelector<HTMLButtonElement>(".use-suggestions")!;
    suggestionsButton.disabled = this.suggestions.length === 0;
    suggestionsButton.textContent = this.suggestions.length
      ? `${this.intersectionLimitReached ? "Use first" : "Use"} ${this.suggestions.length} suggestion${this.suggestions.length === 1 ? "" : "s"}${this.intersectionLimitReached ? " · scan limited" : ""}`
      : "Use intersection suggestions";
    this.svg.classList.toggle("is-drawing", this.mode === "draw-lower" || this.mode === "draw-upper");
  }

  private renderCanvas(): void {
    const content = this.root.querySelector<SVGGElement>(".canvas-content")!;
    const curveMarkup = [...this.drawing.curves]
      .sort((a, b) => (a.family === b.family ? 0 : a.family === "lower" ? -1 : 1))
      .map((curve) => this.renderCurve(curve))
      .join("");
    const trustedMarkup = this.trustedCrossings
      .filter((crossing) => crossing.point)
      .map((crossing) => this.renderTrustedCrossing(crossing))
      .join("");
    const intersectionsMarkup = this.suggestions.map((item, index) => this.renderSuggestion(item, index)).join("");
    content.innerHTML = `${curveMarkup}<g class="trusted-crossing-layer">${trustedMarkup}</g><g class="intersection-layer">${intersectionsMarkup}</g>`;
  }

  private renderTrustedCrossing(crossing: TrustedCrossingPin): string {
    if (!crossing.point) return "";
    return `
      <g class="trusted-crossing-pin" transform="translate(${crossing.point.x} ${crossing.point.y})" pointer-events="none">
        <circle class="trusted-pin-ring" r="10" />
        <path d="M-4-4 4 4M4-4-4 4" />
        <text x="11" y="-9">${escapeText(crossing.id)}</text>
      </g>`;
  }

  private renderCurve(curve: SketchCurve): string {
    if (!curve.points.length) return "";
    const selected = this.selection.curveId === curve.id;
    const path = curvePath(curve);
    const first = curve.points[0];
    const basepoint = curve.points[clamp(curve.basepointIndex, 0, curve.points.length - 1)] ?? first;
    const vertices = selected
      ? curve.points
          .map(
            (point, index) => `
              <circle
                class="curve-vertex ${this.selection.vertexIndex === index ? "is-selected" : ""}"
                cx="${point.x}" cy="${point.y}" r="7"
                data-curve-id="${escapeAttr(curve.id)}" data-vertex-index="${index}"
                aria-label="Point ${index + 1} of ${escapeAttr(curve.name)}"
              />`,
          )
          .join("")
      : "";
    const unlinked = !this.knownCircleIds.has(curve.id);
    return `
      <g class="sketch-curve sketch-curve--${curve.family} ${selected ? "is-selected" : ""} ${unlinked ? "is-unlinked" : ""}">
        <path class="curve-hit" d="${path}" data-curve-id="${escapeAttr(curve.id)}" tabindex="0" role="button" aria-label="${escapeAttr(curve.name)}, ${curve.family} sketch curve" />
        <path class="curve-stroke" d="${path}" pointer-events="none" />
        <g class="curve-label" transform="translate(${first.x + 10} ${first.y - 12})" pointer-events="none">
          <rect x="-5" y="-15" width="${Math.max(38, curve.name.length * 8 + 16)}" height="24" rx="7" />
          <text>${escapeText(curve.name)}</text>
        </g>
        <g class="basepoint-mark" transform="translate(${basepoint.x} ${basepoint.y})" pointer-events="none" aria-label="Basepoint">
          <circle r="9" />
          <circle r="3" />
        </g>
        ${vertices}
      </g>`;
  }

  private renderSuggestion(item: VisualIntersection, index: number): string {
    const selected = this.selection.suggestionKey === item.key;
    const pin = bestPin(item, index, this.suggestions, this.trustedCrossings);
    const label = pin?.id ?? `s${index + 1}`;
    return `
      <g class="visual-intersection ${selected ? "is-selected" : ""} ${pin ? "is-linked" : ""}"
         transform="translate(${item.point.x} ${item.point.y})"
         data-suggestion-key="${escapeAttr(item.key)}" tabindex="0" role="button"
         aria-label="${pin ? `Trusted crossing ${escapeAttr(pin.id)}` : `Suggested intersection ${index + 1}`}">
        <circle class="intersection-halo" r="13" />
        <circle class="intersection-dot" r="5" />
        <text x="10" y="-10">${escapeText(label)}</text>
      </g>`;
  }

  private renderInspector(): void {
    const inspector = this.root.querySelector<HTMLElement>(".selection-inspector")!;
    const suggestion = this.suggestions.find((item) => item.key === this.selection.suggestionKey);
    if (suggestion) {
      const index = this.suggestions.indexOf(suggestion);
      inspector.innerHTML = `
        <div class="inspector-eyebrow">Visual suggestion ${index + 1}</div>
        <h3>Intersection</h3>
        <dl class="mini-data-list">
          <div><dt>Lower sketch</dt><dd>${escapeText(suggestion.lowerCurveId)}</dd></div>
          <div><dt>Upper sketch</dt><dd>${escapeText(suggestion.upperCurveId)}</dd></div>
          <div><dt>Canvas point</dt><dd>${round(suggestion.point.x, 1)}, ${round(suggestion.point.y, 1)}</dd></div>
        </dl>
        <p class="inspector-help">This point is not yet part of the trusted crossing table.</p>
        <button type="button" class="small-button use-suggestions">Review all suggestions</button>`;
      return;
    }

    const curve = this.selectedCurve();
    if (!curve) {
      inspector.innerHTML = `
        <div class="inspector-empty-icon" aria-hidden="true">${iconPointer()}</div>
        <h3>Nothing selected</h3>
        <p>Select a curve or point to edit it. Use Lower or Upper to start a new polyline.</p>
        <div class="canvas-shortcuts">
          <span><kbd>Esc</kbd> finish</span>
          <span><kbd>Del</kbd> remove</span>
        </div>`;
      return;
    }

    const vertexIndex = this.selection.vertexIndex;
    const point = vertexIndex === undefined ? undefined : curve.points[vertexIndex];
    inspector.innerHTML = `
      <div class="inspector-eyebrow">${curve.family} sketch curve</div>
      <div class="inspector-title-row">
        <h3>${escapeText(curve.name)}</h3>
        <span class="link-status ${this.knownCircleIds.has(curve.id) ? "is-linked" : ""}">
          ${this.knownCircleIds.has(curve.id) ? "Linked by ID" : "Visual only"}
        </span>
      </div>
      <label class="field compact-field">
        <span>Curve label</span>
        <input data-sketch-field="name" type="text" value="${escapeAttr(curve.name)}" maxlength="40" />
      </label>
      <label class="field compact-field">
        <span>Family</span>
        <select data-sketch-field="family">
          <option value="lower" ${curve.family === "lower" ? "selected" : ""}>Lower · green</option>
          <option value="upper" ${curve.family === "upper" ? "selected" : ""}>Upper · violet</option>
        </select>
      </label>
      <dl class="mini-data-list">
        <div><dt>Curve ID</dt><dd><code>${escapeText(curve.id)}</code></dd></div>
        <div><dt>Points</dt><dd>${curve.points.length}</dd></div>
        <div><dt>Basepoint</dt><dd>point ${curve.basepointIndex + 1}</dd></div>
      </dl>
      ${
        point
          ? `<fieldset class="coordinate-fields">
              <legend>Selected point ${vertexIndex! + 1}</legend>
              <label><span>x</span><input data-sketch-field="x" type="number" min="0" max="${WIDTH}" step="1" value="${round(point.x, 1)}" /></label>
              <label><span>y</span><input data-sketch-field="y" type="number" min="0" max="${HEIGHT}" step="1" value="${round(point.y, 1)}" /></label>
            </fieldset>`
          : `<p class="inspector-help">Select a visible point to move it or make it the basepoint.</p>`
      }
      <div class="inspector-actions">
        <button type="button" class="small-button toggle-curve-closed">${curve.closed ? "Open curve" : "Close curve"}</button>
        <button type="button" class="small-button danger-button delete-inspector-selection">Delete ${point ? "point" : "curve"}</button>
      </div>`;
  }

  private selectedCurve(): SketchCurve | undefined {
    return this.selection.curveId ? this.findCurve(this.selection.curveId) : undefined;
  }

  private findCurve(id: string): SketchCurve | undefined {
    return this.drawing.curves.find((curve) => curve.id === id);
  }

  private eventPoint(event: PointerEvent): SketchPoint {
    const rect = this.svg.getBoundingClientRect();
    return {
      x: round(clamp(((event.clientX - rect.left) / rect.width) * WIDTH, 0, WIDTH), 1),
      y: round(clamp(((event.clientY - rect.top) / rect.height) * HEIGHT, 0, HEIGHT), 1),
    };
  }

  private nextCurveId(family: CurveFamily): string {
    const prefix = family === "lower" ? "L" : "U";
    let index = 0;
    const existing = new Set(this.drawing.curves.map((curve) => curve.id));
    while (existing.has(`${prefix}${index}`)) index += 1;
    return `${prefix}${index}`;
  }
}

export function findVisualIntersections(curves: SketchCurve[]): VisualIntersection[] {
  return scanVisualIntersections(curves).intersections;
}

export interface VisualIntersectionScan {
  intersections: VisualIntersection[];
  comparisons: number;
  limited: boolean;
}

export function scanVisualIntersections(curves: SketchCurve[]): VisualIntersectionScan {
  let limited = curves.length > DIAGRAM_EDITOR_LIMITS.curves;
  let pointTotal = 0;
  const boundedCurves = curves.slice(0, DIAGRAM_EDITOR_LIMITS.curves).map((curve) => {
    pointTotal += curve.points.length;
    if (curve.points.length > DIAGRAM_EDITOR_LIMITS.pointsPerCurve) limited = true;
    return { ...curve, points: curve.points.slice(0, DIAGRAM_EDITOR_LIMITS.pointsPerCurve) };
  });
  if (pointTotal > DIAGRAM_EDITOR_LIMITS.pointsTotal) limited = true;
  const lower = boundedCurves
    .filter((curve) => curve.family === "lower" && curve.points.length > 1)
    .map((curve) => ({ curve, segments: segments(curve) }));
  const upper = boundedCurves
    .filter((curve) => curve.family === "upper" && curve.points.length > 1)
    .map((curve) => ({ curve, segments: segments(curve) }));
  const intersections: VisualIntersection[] = [];
  const seenCells = new Map<string, SketchPoint[]>();
  let comparisons = 0;

  for (const lowerEntry of lower) {
    for (const upperEntry of upper) {
      const lowerCurve = lowerEntry.curve;
      const upperCurve = upperEntry.curve;
      const pairKey = `${lowerCurve.id}\u0000${upperCurve.id}`;
      for (const lowerSegment of lowerEntry.segments) {
        for (const upperSegment of upperEntry.segments) {
          if (comparisons >= DIAGRAM_EDITOR_LIMITS.segmentComparisons) {
            return finishIntersectionScan(intersections, comparisons, true);
          }
          comparisons += 1;
          const hit = segmentIntersection(lowerSegment.a, lowerSegment.b, upperSegment.a, upperSegment.b);
          if (!hit) continue;
          if (nearSeenPoint(seenCells, pairKey, hit.point)) continue;
          if (intersections.length >= DIAGRAM_EDITOR_LIMITS.intersections) {
            return finishIntersectionScan(intersections, comparisons, true);
          }
          rememberPoint(seenCells, pairKey, hit.point);
          intersections.push({
            key: `${lowerCurve.id}:${upperCurve.id}:${lowerSegment.index}:${upperSegment.index}:${round(hit.point.x, 1)}:${round(hit.point.y, 1)}`,
            lowerCurveId: lowerCurve.id,
            upperCurveId: upperCurve.id,
            point: hit.point,
            lowerPosition: lowerSegment.index + hit.t,
            upperPosition: upperSegment.index + hit.u,
          });
        }
      }
    }
  }

  return finishIntersectionScan(intersections, comparisons, limited);
}

function finishIntersectionScan(
  intersections: VisualIntersection[],
  comparisons: number,
  limited: boolean,
): VisualIntersectionScan {
  intersections.sort((a, b) =>
    a.lowerCurveId.localeCompare(b.lowerCurveId) ||
    a.lowerPosition - b.lowerPosition ||
    a.upperCurveId.localeCompare(b.upperCurveId) ||
    a.upperPosition - b.upperPosition,
  );
  return { intersections, comparisons, limited };
}

function nearSeenPoint(cells: Map<string, SketchPoint[]>, pairKey: string, point: SketchPoint): boolean {
  const cellSize = 1.5;
  const cellX = Math.floor(point.x / cellSize);
  const cellY = Math.floor(point.y / cellSize);
  for (let offsetX = -1; offsetX <= 1; offsetX += 1) {
    for (let offsetY = -1; offsetY <= 1; offsetY += 1) {
      const points = cells.get(`${pairKey}\u0000${cellX + offsetX}:${cellY + offsetY}`) ?? [];
      if (points.some((candidate) => distance(candidate, point) < cellSize)) return true;
    }
  }
  return false;
}

function rememberPoint(cells: Map<string, SketchPoint[]>, pairKey: string, point: SketchPoint): void {
  const cellSize = 1.5;
  const key = `${pairKey}\u0000${Math.floor(point.x / cellSize)}:${Math.floor(point.y / cellSize)}`;
  const points = cells.get(key);
  if (points) points.push(point);
  else cells.set(key, [point]);
}

function segments(curve: SketchCurve): Array<{ a: SketchPoint; b: SketchPoint; index: number }> {
  const result: Array<{ a: SketchPoint; b: SketchPoint; index: number }> = [];
  for (let index = 0; index < curve.points.length - 1; index += 1) {
    result.push({ a: curve.points[index], b: curve.points[index + 1], index });
  }
  if (curve.closed && curve.points.length > 2) {
    result.push({ a: curve.points.at(-1)!, b: curve.points[0], index: curve.points.length - 1 });
  }
  return result;
}

function segmentIntersection(
  a: SketchPoint,
  b: SketchPoint,
  c: SketchPoint,
  d: SketchPoint,
): { point: SketchPoint; t: number; u: number } | null {
  const r = { x: b.x - a.x, y: b.y - a.y };
  const s = { x: d.x - c.x, y: d.y - c.y };
  const denominator = cross(r, s);
  if (Math.abs(denominator) < 1e-8) return null;
  const offset = { x: c.x - a.x, y: c.y - a.y };
  const t = cross(offset, s) / denominator;
  const u = cross(offset, r) / denominator;
  const epsilon = 1e-6;
  if (t <= epsilon || t >= 1 - epsilon || u <= epsilon || u >= 1 - epsilon) return null;
  return {
    point: { x: round(a.x + t * r.x, 2), y: round(a.y + t * r.y, 2) },
    t,
    u,
  };
}

function bestPin(
  suggestion: VisualIntersection,
  suggestionIndex: number,
  allSuggestions: VisualIntersection[],
  pins: TrustedCrossingPin[],
): TrustedCrossingPin | undefined {
  const pairSuggestions = allSuggestions.filter(
    (item) => item.lowerCurveId === suggestion.lowerCurveId && item.upperCurveId === suggestion.upperCurveId,
  );
  const pairIndex = pairSuggestions.findIndex((item) => item.key === suggestion.key);
  const pairPin = pins
    .filter(
      (pin) => !pin.point && pin.lowerCurveId === suggestion.lowerCurveId && pin.upperCurveId === suggestion.upperCurveId,
    )
    .sort((a, b) => a.lowerEndpoint - b.lowerEndpoint || a.upperEndpoint - b.upperEndpoint)[pairIndex];
  if (pairPin) return pairPin;
  const positionalPin = pins[suggestionIndex];
  return !positionalPin?.point && positionalPin?.lowerCurveId === suggestion.lowerCurveId &&
    positionalPin.upperCurveId === suggestion.upperCurveId
    ? positionalPin
    : undefined;
}

function normaliseDrawing(drawing: SketchData | undefined): SketchData {
  if (!drawing || !Array.isArray(drawing.curves)) return { curves: [] };
  let remainingPoints = DIAGRAM_EDITOR_LIMITS.pointsTotal;
  return {
    curves: drawing.curves.slice(0, DIAGRAM_EDITOR_LIMITS.curves).map((curve, curveIndex) => {
      const points = Array.isArray(curve.points)
        ? curve.points
            .slice(0, Math.min(DIAGRAM_EDITOR_LIMITS.pointsPerCurve, remainingPoints))
            .map((point) => ({
              x: round(clamp(Number(point?.x) || 0, 0, WIDTH), 2),
              y: round(clamp(Number(point?.y) || 0, 0, HEIGHT), 2),
            }))
        : [];
      remainingPoints -= points.length;
      return {
      id: String(curve.id || `${curve.family === "upper" ? "U" : "L"}${curveIndex}`),
      name: String(curve.name || curve.id || `curve ${curveIndex + 1}`),
      family: curve.family === "upper" ? "upper" : "lower",
      points,
      closed: Boolean(curve.closed),
      basepointIndex: clamp(Math.trunc(Number(curve.basepointIndex) || 0), 0, Math.max(0, points.length - 1)),
      };
    }),
  };
}

function drawingLimitMessage(drawing: SketchData | undefined): string | undefined {
  if (!drawing || !Array.isArray(drawing.curves)) return undefined;
  if (drawing.curves.length > DIAGRAM_EDITOR_LIMITS.curves) {
    return `Only the first ${DIAGRAM_EDITOR_LIMITS.curves} sketch curves can be shown.`;
  }
  let total = 0;
  for (const [index, curve] of drawing.curves.entries()) {
    const count = Array.isArray(curve?.points) ? curve.points.length : 0;
    if (count > DIAGRAM_EDITOR_LIMITS.pointsPerCurve) {
      return `Sketch curve ${index + 1} exceeds the ${DIAGRAM_EDITOR_LIMITS.pointsPerCurve}-point display limit.`;
    }
    total += count;
  }
  return total > DIAGRAM_EDITOR_LIMITS.pointsTotal
    ? `The sketch exceeds the ${DIAGRAM_EDITOR_LIMITS.pointsTotal}-point display limit.`
    : undefined;
}

function curvePath(curve: SketchCurve): string {
  if (!curve.points.length) return "";
  const commands = curve.points.map((point, index) => `${index ? "L" : "M"} ${point.x} ${point.y}`);
  if (curve.closed && curve.points.length > 2) commands.push("Z");
  return commands.join(" ");
}

function copySuggestion(suggestion: VisualIntersection): VisualIntersection {
  return { ...suggestion, point: { ...suggestion.point } };
}

function cross(a: SketchPoint, b: SketchPoint): number {
  return a.x * b.y - a.y * b.x;
}

function distance(a: SketchPoint, b: SketchPoint): number {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function clamp(value: number, minimum: number, maximum: number): number {
  return Math.min(maximum, Math.max(minimum, Number.isFinite(value) ? value : minimum));
}

function round(value: number, places: number): number {
  const scale = 10 ** places;
  return Math.round(value * scale) / scale;
}

function escapeText(value: string): string {
  return value.replace(/[&<>]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[character]!);
}

function escapeAttr(value: string): string {
  return escapeText(value).replace(/["']/g, (character) => (character === '"' ? "&quot;" : "&#39;"));
}

function cssEscape(value: string): string {
  return typeof CSS !== "undefined" && CSS.escape ? CSS.escape(value) : value.replace(/[^a-zA-Z0-9_-]/g, "\\$&");
}

function toolButton(mode: ToolMode, label: string, title: string, icon: string): string {
  return `<button class="tool-button" type="button" data-tool="${mode}" title="${title}" aria-label="${title}" aria-pressed="false">${icon}<span>${label}</span></button>`;
}

function iconPointer(): string {
  return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6.7 3.5 11.6 8.1-5.2 1.1-2.5 5.1-3.9-14.3Z"/><path d="m13 13 4.1 4.2"/></svg>`;
}

function iconCurve(family: CurveFamily): string {
  return `<svg class="icon-curve icon-curve--${family}" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 13c2.2-7 6.5-9 11-6.5 3.7 2 4.9 7.2 1.3 9.7-4.2 3-11.6 1.7-12.3-3.2Z"/></svg>`;
}

function iconBasepoint(): string {
  return `<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="7"/><circle class="fill-shape" cx="12" cy="12" r="2.5"/></svg>`;
}

function iconTrash(): string {
  return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 7h15M9 7V4.5h6V7m2.5 0-.7 12H7.2L6.5 7m4 3v6m3-6v6"/></svg>`;
}

function iconSparkle(): string {
  return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5c.8 5.6 3.3 8.2 8.8 9-5.5.8-8 3.4-8.8 9-1-5.6-3.4-8.2-8.8-9 5.4-.8 7.8-3.4 8.8-9Z"/></svg>`;
}
