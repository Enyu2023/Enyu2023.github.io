import { describe, expect, it } from "vitest";
import {
  Cyclotomic,
  cyclotomicPolynomial,
  formatCyclotomic,
} from "../src/engine/cyclotomic";

describe("exact cyclotomic arithmetic", () => {
  it("constructs Phi_7 and reduces zeta^6 exactly", () => {
    expect(cyclotomicPolynomial(7)).toEqual([1n, 1n, 1n, 1n, 1n, 1n, 1n]);
    const relation = Cyclotomic.fromTerms(7, [
      [0, 1n], [1, 1n], [2, 1n], [3, 1n], [4, 1n], [5, 1n], [6, 1n],
    ]);
    expect(relation.isZero()).toBe(true);
  });

  it("supports composite odd levels", () => {
    expect(cyclotomicPolynomial(9)).toEqual([1n, 0n, 0n, 1n, 0n, 0n, 1n]);
    const zeta = Cyclotomic.zetaPower(9, 1);
    expect(zeta.pow(9).equals(Cyclotomic.one(9))).toBe(true);
  });

  it("serializes bigint coefficients without losing precision", () => {
    const value = new Cyclotomic(5, [9_007_199_254_740_993n, -1n, 2n]);
    expect(Cyclotomic.fromJSON(value.toJSON()).equals(value)).toBe(true);
    expect(formatCyclotomic(value)).toContain("9007199254740993");
  });
});
