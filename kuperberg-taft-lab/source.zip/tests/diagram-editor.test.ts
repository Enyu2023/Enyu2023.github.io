import { describe, expect, it } from "vitest";
import {
  DIAGRAM_EDITOR_LIMITS,
  scanVisualIntersections,
  type SketchCurve,
} from "../src/ui/diagram-editor";

describe("diagram editor work limits", () => {
  it("stops geometric intersection work at the published comparison cap", () => {
    const horizontal = (id: string, y: number): SketchCurve => ({
      id,
      name: id,
      family: "lower",
      points: Array.from({ length: 256 }, (_, x) => ({ x, y })),
      closed: false,
      basepointIndex: 0,
    });
    const vertical = (id: string, x: number): SketchCurve => ({
      id,
      name: id,
      family: "upper",
      points: Array.from({ length: 256 }, (_, y) => ({ x, y })),
      closed: false,
      basepointIndex: 0,
    });

    const scan = scanVisualIntersections([
      horizontal("L0", 50),
      horizontal("L1", 150),
      vertical("U0", 75),
      vertical("U1", 175),
    ]);

    expect(scan.limited).toBe(true);
    expect(scan.comparisons).toBe(DIAGRAM_EDITOR_LIMITS.segmentComparisons);
    expect(scan.intersections.length).toBeLessThanOrEqual(DIAGRAM_EDITOR_LIMITS.intersections);
  });
});
