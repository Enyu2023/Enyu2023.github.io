import { describe, expect, it } from "vitest";
import { deriveLabels, validatePreparedDiagram } from "../src/domain/validation";
import { getExample, lensSpaceL71, threeTorus } from "../src/examples";

describe("prepared diagram schema", () => {
  it("validates both literature fixtures", () => {
    expect(validatePreparedDiagram(lensSpaceL71.diagram)).toEqual({ valid: true, diagnostics: [] });
    expect(validatePreparedDiagram(threeTorus.diagram)).toEqual({ valid: true, diagnostics: [] });
    expect(threeTorus.diagram.basis.labels).toEqual([
      "x₁", "y₁", "x₂", "y₂", "x₃", "y₃",
      "ν₁", "ν₂", "ν₃", "μ₁", "μ₂", "μ₃",
    ]);
  });

  it("derives R=R0-2B.n and N=N0-2A.n", () => {
    const diagram = getExample("lens-l71")!.diagram;
    diagram.basis.combing = [2, -1, 0, 3];
    diagram.circles[0]!.B = [1, 2, 0, -1];
    diagram.crossings[0]!.A = [-1, 0, 2, 1];
    const derived = deriveLabels(diagram);
    expect(derived.circles[0]!.R).toBe(7); // 1 - 2(2 - 2 - 3)
    expect(derived.crossings[0]!.N).toBe(-1); // 1 - 2(-2 + 3)
  });

  it("rejects incidence and 4g-vector mistakes", () => {
    const diagram = getExample("lens-l71")!.diagram;
    diagram.crossings[0]!.A = [0];
    diagram.crossings[1]!.endpoints.upper = "missing";
    const result = validatePreparedDiagram(diagram);
    expect(result.valid).toBe(false);
    expect(result.diagnostics.map((entry) => entry.code)).toContain("VECTOR_LENGTH");
    expect(result.diagnostics.map((entry) => entry.code)).toContain("UPPER_ENDPOINT");
  });

  it("blocks visually suggested rows until their numeric labels are confirmed", () => {
    const diagram = getExample("lens-l71")!.diagram;
    diagram.crossings[0]!.labelsPrepared = false;
    diagram.circles[0]!.labelsPrepared = false;
    const result = validatePreparedDiagram(diagram);
    expect(result.valid).toBe(false);
    expect(result.diagnostics).toContainEqual(
      expect.objectContaining({ code: "UNPREPARED_CROSSING_LABELS", path: "crossings[0].labelsPrepared" }),
    );
    expect(result.diagnostics).toContainEqual(
      expect.objectContaining({ code: "UNPREPARED_CIRCLE_LABELS", path: "circles[0].labelsPrepared" }),
    );
  });

  it("does not let malformed certification values bypass the preparation gate", () => {
    const diagram = getExample("lens-l71")!.diagram as unknown as Record<string, any>;
    diagram.crossings[0].labelsPrepared = "false";
    diagram.circles[0].labelsPrepared = 0;
    const result = validatePreparedDiagram(diagram);
    expect(result.valid).toBe(false);
    expect(result.diagnostics).toContainEqual(
      expect.objectContaining({ code: "BOOLEAN_REQUIRED", path: "crossings[0].labelsPrepared" }),
    );
    expect(result.diagnostics).toContainEqual(
      expect.objectContaining({ code: "BOOLEAN_REQUIRED", path: "circles[0].labelsPrepared" }),
    );
  });

  it("reports malformed optional and nested fields without throwing", () => {
    const orderString = getExample("lens-l71")!.diagram as unknown as Record<string, any>;
    orderString.circles[0].order = "p1, p2";
    orderString.circles[0].drawing = null;
    orderString.crossings[0].point = null;

    expect(() => validatePreparedDiagram(orderString)).not.toThrow();
    const result = validatePreparedDiagram(orderString);
    expect(result.valid).toBe(false);
    expect(result.diagnostics.map((entry) => entry.code)).toEqual(
      expect.arrayContaining(["CIRCLE_ORDER", "DRAWING_OBJECT", "CROSSING_POINT"]),
    );
  });

  it("caps untrusted collections while returning explicit diagnostics", () => {
    const diagram = getExample("lens-l71")!.diagram as unknown as Record<string, any>;
    diagram.crossings = Array.from({ length: 513 }, (_, index) => ({
      id: `p${index}`,
      N0: 0,
      A: [0, 0, 0, 0],
      endpoints: { lower: "L0", upper: "U0" },
    }));

    expect(() => validatePreparedDiagram(diagram)).not.toThrow();
    expect(validatePreparedDiagram(diagram).diagnostics).toEqual(
      expect.arrayContaining([expect.objectContaining({ code: "DATA_LIMIT", path: "crossings" })]),
    );
  });
});
