import { describe, expect, it } from "vitest";
import type { PreparedDiagram } from "../src/domain";
import { getExample } from "../src/examples";
import {
  createEvaluationGuard,
  evaluatePreparedDiagram,
  lensL71PublishedFormulaOracle,
  lensL71PublishedValue,
  threeTorusPublishedFormulaOracle,
} from "../src/engine";

function separatedTwoHandleDiagram(
  lowerIds: readonly [string, string],
  crossingIds: readonly [string, string],
): PreparedDiagram {
  const zeros = Array<number>(8).fill(0);
  return {
    schemaVersion: 1,
    name: "Two separated one-crossing handles",
    genus: 2,
    basis: {
      labels: ["x1", "y1", "x2", "y2", "nu1", "mu1", "nu2", "mu2"],
      combing: [...zeros],
    },
    circles: [
      { id: lowerIds[0], kind: "lower", R0: -1, B: [...zeros], order: [crossingIds[0]] },
      { id: lowerIds[1], kind: "lower", R0: -1, B: [...zeros], order: [crossingIds[1]] },
      { id: "upper-1", kind: "upper", R0: 1, B: [...zeros], order: [crossingIds[0]] },
      { id: "upper-2", kind: "upper", R0: 1, B: [...zeros], order: [crossingIds[1]] },
    ],
    crossings: [
      {
        id: crossingIds[0],
        N0: 0,
        A: [...zeros],
        endpoints: { lower: lowerIds[0], upper: "upper-1" },
      },
      {
        id: crossingIds[1],
        N0: 0,
        A: [...zeros],
        endpoints: { lower: lowerIds[1], upper: "upper-2" },
      },
    ],
  };
}

function largeOneHandleDiagram(crossingCount: number): PreparedDiagram {
  const zeros = Array<number>(4).fill(0);
  const crossingIds = Array.from({ length: crossingCount }, (_, index) => `x${index}`);
  return {
    schemaVersion: 1,
    name: `One handle with ${crossingCount} crossings`,
    genus: 1,
    basis: {
      labels: ["x1", "y1", "nu1", "mu1"],
      combing: [...zeros],
    },
    circles: [
      { id: "lower", kind: "lower", R0: -1, B: [...zeros], order: [...crossingIds] },
      { id: "upper", kind: "upper", R0: 1, B: [...zeros], order: [...crossingIds] },
    ],
    crossings: crossingIds.map((id) => ({
      id,
      N0: 0,
      A: [...zeros],
      endpoints: { lower: "lower", upper: "upper" },
    })),
  };
}

describe("prepared Chang--Cui network evaluator", () => {
  it("keeps the CNW L(7,1), f_L literature value as an exact regression", () => {
    expect(lensL71PublishedFormulaOracle().equals(lensL71PublishedValue())).toBe(true);
  });

  it("routes the L(7,1) fixture to the direct published formula", () => {
    const example = getExample("lens-l71")!;
    const result = evaluatePreparedDiagram(example.diagram, example.level);
    expect(result.status).toBe("ok");
    if (result.status !== "ok") return;
    expect(result.value.equals(lensL71PublishedFormulaOracle())).toBe(true);
    expect(result.stats.contractionStates).toBe(6_468);
  });

  it("matches the published L(7,2), f_R zero", () => {
    const example = getExample("lens-l72")!;
    const result = evaluatePreparedDiagram(example.diagram, example.level);
    expect(result.status).toBe("ok");
    if (result.status !== "ok") return;
    expect(result.value.isZero()).toBe(true);
    expect(result.stats.contractionStates).toBe(6_468);
  });

  it("matches the published T^3 formula at l=3", () => {
    const example = getExample("three-torus")!;
    const result = evaluatePreparedDiagram(example.diagram, example.level);
    expect(result.status).toBe("ok");
    if (result.status !== "ok") return;
    const oracle = threeTorusPublishedFormulaOracle(3);
    expect(result.value.equals(oracle)).toBe(true);
    expect(oracle.isZero()).toBe(true);
    expect(result.stats.contractionStates).toBe(27_000);
  });

  it("returns explicit limit/cancellation states", () => {
    const example = getExample("lens-l71")!;
    const limited = evaluatePreparedDiagram(example.diagram, example.level, { maxOperations: 1 });
    expect(limited.status).toBe("limit");

    const guard = createEvaluationGuard();
    const first = guard.begin();
    const second = guard.begin();
    expect(first.signal.aborted).toBe(true);
    expect(guard.isCurrent(first)).toBe(false);
    expect(guard.isCurrent(second)).toBe(true);
  });

  it("rejects a large live assignment map before materializing its tensor", () => {
    // At ell=3 and arity 236 the tensor has 83,898 terms, so retaining one
    // assignment map per state would require 19,799,928 Map entries.
    const result = evaluatePreparedDiagram(largeOneHandleDiagram(236), 3);
    expect(result.status).toBe("limit");
    expect(result.diagnostics).toContainEqual(
      expect.objectContaining({ code: "ASSIGNMENT_CELL_LIMIT" }),
    );
    expect(result.stats.operations).toBe(0);
  });

  it("returns exact zero for a detached lower or upper circle", () => {
    const example = getExample("lens-l71")!;
    example.diagram.crossings = [];
    example.diagram.circles.forEach((circle) => {
      circle.order = [];
    });
    const result = evaluatePreparedDiagram(example.diagram, 3);
    expect(result.status).toBe("ok");
    if (result.status === "ok") {
      expect(result.value.isZero()).toBe(true);
      expect(result.stats.contractionStates).toBe(0);
    }
  });

  it("is invariant under reserved JavaScript object-property ids", () => {
    const ordinary = evaluatePreparedDiagram(
      separatedTwoHandleDiagram(["lower-1", "lower-2"], ["crossing-1", "crossing-2"]),
      3,
    );
    const reserved = evaluatePreparedDiagram(
      separatedTwoHandleDiagram(["__proto__", "constructor"], ["__proto__", "constructor"]),
      3,
    );

    expect(ordinary.status).toBe("ok");
    expect(reserved.status).toBe("ok");
    if (ordinary.status !== "ok" || reserved.status !== "ok") return;
    expect(reserved.value.equals(ordinary.value)).toBe(true);
    expect(Object.prototype.hasOwnProperty.call(reserved.stats.lowerTensorTerms, "__proto__")).toBe(true);
    expect(Object.prototype.hasOwnProperty.call(reserved.stats.lowerTensorTerms, "constructor")).toBe(true);
  });
});
