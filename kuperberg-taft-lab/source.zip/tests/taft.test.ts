import { describe, expect, it } from "vitest";
import { Cyclotomic } from "../src/engine/cyclotomic";
import {
  TaftElement,
  antipode,
  antipodePower,
  inverseAntipode,
  multiplyTaft,
  normalizedLeftIntegral,
  rightCointegral,
  shiftedLowerIntegral,
  shiftedUpperCointegral,
} from "../src/engine/taft";

describe("odd Taft algebra", () => {
  const level = 5;
  const x = TaftElement.basis(level, 1, 0);
  const g = TaftElement.basis(level, 0, 1);

  it("uses gx = zeta xg in the x^a g^b basis", () => {
    const gx = multiplyTaft(g, x);
    const xg = multiplyTaft(x, g);
    expect(gx.coefficient(1, 1).equals(Cyclotomic.zetaPower(level, 1))).toBe(true);
    expect(xg.coefficient(1, 1).equals(Cyclotomic.one(level))).toBe(true);
  });

  it("implements Sg=g^-1 and Sx=-xg^-1", () => {
    expect(antipode(g).coefficient(0, -1).equals(Cyclotomic.one(level))).toBe(true);
    expect(antipode(x).coefficient(1, -1).equals(Cyclotomic.integer(level, -1n))).toBe(true);
    expect(inverseAntipode(antipode(x)).coefficient(1, 0).equals(Cyclotomic.one(level))).toBe(true);
    expect(antipodePower(x, 2 * level).coefficient(1, 0).equals(Cyclotomic.one(level))).toBe(true);
  });

  it("normalizes lambda(Lambda)=1", () => {
    expect(rightCointegral(normalizedLeftIntegral(level)).equals(Cyclotomic.one(level))).toBe(true);
  });

  it("uses the canonical shifted e_h and mu_h formulas for arbitrary odd R", () => {
    const shifted = shiftedLowerIntegral(level, 3); // n=(R+1)/2=2
    expect(shifted.coefficient(level - 1, 0).equals(Cyclotomic.zetaPower(level, 2))).toBe(true);
    expect(shifted.coefficient(level - 1, 2).equals(Cyclotomic.zetaPower(level, -2))).toBe(true);

    const probe = TaftElement.basis(level, level - 1, 2);
    // Upper R=-3 gives n=(1-R)/2=2 and selects b=1-n=-1, not b=2.
    expect(shiftedUpperCointegral(probe, -3).isZero()).toBe(true);
    expect(
      shiftedUpperCointegral(TaftElement.basis(level, level - 1, -1), -3)
        .equals(Cyclotomic.one(level)),
    ).toBe(true);
  });
});
